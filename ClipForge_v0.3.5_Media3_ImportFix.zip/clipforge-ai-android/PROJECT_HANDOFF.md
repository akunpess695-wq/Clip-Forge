# ClipForge PROJECT_HANDOFF — v0.3.5 (Media3 import fix)

## Source
Based directly on ClipForge_v0.3.4_GamingSplit_Export_Source.zip.

## GitHub Actions error
- `GamingSplitExporter.kt:66:13`: `getOverlaySettings overrides nothing`
- `GamingSplitExporter.kt:66:86`: unresolved `OverlaySettings`
- `GamingSplitExporter.kt:67:17`: unresolved `StaticOverlaySettings`

## Changes
- `OverlaySettings` import changed from `androidx.media3.common` to `androidx.media3.effect`.
- `StaticOverlaySettings` remains imported from `androidx.media3.effect`.
- Version bumped to `versionName=0.3.5`, `versionCode=6`; application ID unchanged.

## IMPORTANT — verification
ZIP integrity and static source checks were performed. A complete Android Gradle compile, instrumentation test and on-device MP4 export were **not** performed. The current source still requires CI compilation and runtime validation; this is a targeted API import correction, **not** a proven successful export fix.

## Next steps
1. Upload the source contents to GitHub (maintain project structure).
2. Run `./gradlew :app:testDebugUnitTest :app:assembleDebug` using the repository's configured Gradle environment (or existing GitHub workflow).
3. If errors persist, capture **all** Kotlin `e:` lines, not only `BUILD FAILED`.
4. Test export with a short 9:16 single-source video and compare resulting split, duration and audio.
5. For in-place APK updates keep the same applicationId, increment versionCode and use the same signing certificate across releases. GitHub ephemeral debug keys can prevent in-place updates.
