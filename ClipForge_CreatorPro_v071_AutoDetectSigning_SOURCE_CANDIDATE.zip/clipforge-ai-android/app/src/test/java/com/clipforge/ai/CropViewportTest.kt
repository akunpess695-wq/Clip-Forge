package com.clipforge.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class CropViewportTest {
    @Test fun fullFrameLandscapeIntoPortraitPanelCentersAndCrops() {
        val vp = CropViewport.compute(100f, 200f, NormalizedCrop(0f, 0f, 1f, 1f), 1920f, 1080f)!!
        assertEquals(200f, vp.displayHeight, 0.01f)
        assertEquals(355.56f, vp.displayWidth, 0.05f)
        assertEquals(0f, vp.offsetY, 0.01f)
        assertEquals(50f - 355.56f / 2f, vp.offsetX, 0.05f)
    }

    @Test fun bottomRightQuarterFillsPanel() {
        val vp = CropViewport.compute(100f, 100f, NormalizedCrop(0.5f, 0.5f, 0.5f, 0.5f), 1000f, 1000f)!!
        assertEquals(200f, vp.displayWidth, 0.01f)
        assertEquals(200f, vp.displayHeight, 0.01f)
        assertEquals(-100f, vp.offsetX, 0.01f)
        assertEquals(-100f, vp.offsetY, 0.01f)
    }

    @Test fun invalidSizesReturnNull() {
        assertNull(CropViewport.compute(0f, 100f, NormalizedCrop(0f, 0f, 1f, 1f), 100f, 100f))
        assertNull(CropViewport.compute(100f, 100f, NormalizedCrop(0f, 0f, 1f, 1f), 0f, 100f))
    }
}
