package com.clipforge.ai

/**
 * Pure layout math for the live split preview. Given a panel size, a normalized crop and the
 * video's display size, returns how large to draw the FULL video and where to offset it so that
 * the crop region fills the panel (center-crop, aspect ratio preserved). Units are caller-defined (dp).
 */
data class CropViewport(
    val displayWidth: Float,
    val displayHeight: Float,
    val offsetX: Float,
    val offsetY: Float
) {
    companion object {
        fun compute(panelW: Float, panelH: Float, crop: NormalizedCrop, videoW: Float, videoH: Float): CropViewport? {
            if (panelW <= 0f || panelH <= 0f || videoW <= 0f || videoH <= 0f) return null
            val cropW = crop.width * videoW
            val cropH = crop.height * videoH
            if (cropW <= 0f || cropH <= 0f) return null
            val scale = maxOf(panelW / cropW, panelH / cropH)
            val dispW = videoW * scale
            val dispH = videoH * scale
            return CropViewport(
                displayWidth = dispW,
                displayHeight = dispH,
                offsetX = panelW / 2f - (crop.left + crop.width / 2f) * dispW,
                offsetY = panelH / 2f - (crop.top + crop.height / 2f) * dispH
            )
        }
    }
}
