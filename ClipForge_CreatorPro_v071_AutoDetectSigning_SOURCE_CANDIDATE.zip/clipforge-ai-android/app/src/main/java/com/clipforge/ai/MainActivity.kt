package com.clipforge.ai

import android.content.ContentValues
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.view.TextureView
import kotlin.math.abs
import androidx.compose.ui.draw.clipToBounds
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.clickable
import androidx.compose.ui.input.pointer.pointerInput
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.Pause
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File
import java.io.FileInputStream
import java.util.Locale
import android.os.Handler
import android.os.Looper
import kotlin.concurrent.thread

private val LocalLightTheme = compositionLocalOf { false }
private val Night = Color(0xFF090E19)
private val Panel = Color(0xFF141E30)
private val Panel2 = Color(0xFF1B2A41)
private val Blue = Color(0xFF398BFF)
private val Violet = Color(0xFF58B8FF)
private val Muted = Color(0xFF9BAAC7)
private val White = Color(0xFFF4F7FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8, 13, 27)
        window.navigationBarColor = android.graphics.Color.rgb(8, 13, 27)
        setContent { ClipForgeApp() }
    }
}

@Composable
private fun ClipForgeApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember(context) { context.getSharedPreferences("clipforge_ui", android.content.Context.MODE_PRIVATE) }
    var themeChoice by remember { mutableStateOf(prefs.getString("theme", "system") ?: "system") }
    val light = when (themeChoice) { "light" -> true; "dark" -> false; else -> !isSystemInDarkTheme() }
    var themeMenuOpen by remember { mutableStateOf(false) }
    val appBg = if (light) Color(0xFFF5F7FC) else Night
    val appText = if (light) Color(0xFF111827) else White
    val appMuted = if (light) Color(0xFF59677D) else Muted
    val appPanel = if (light) Color.White else Panel

    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var videoName by remember { mutableStateOf("Belum ada video") }
    var durationMs by remember { mutableLongStateOf(0L) }
    var startMs by remember { mutableLongStateOf(0L) }
    var endMs by remember { mutableLongStateOf(0L) }
    var status by remember { mutableStateOf("Pilih video untuk mulai membuat klip.") }
    var exporting by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf(false) }
    var analyzing by remember { mutableStateOf(false) }
    var suggestions by remember { mutableStateOf<List<SilenceSuggestion>>(emptyList()) }
    var selectedSuggestion by remember { mutableIntStateOf(-1) }
    var approvedCuts by remember { mutableStateOf<Set<Int>>(emptySet()) }
    var autoCutExport by remember { mutableStateOf(false) }
    var analysisGeneration by remember { mutableIntStateOf(0) }
    var gamingSplitEnabled by remember { mutableStateOf(true) }
    var showLayoutSettings by remember { mutableStateOf(false) }
    var showSmartCut by remember { mutableStateOf(false) }
    var showAdvancedCrop by remember { mutableStateOf(false) }
    var editorPanel by remember { mutableStateOf("edit") }
    var activeTool by remember { mutableStateOf<String?>(null) }
    var fullscreenPreview by remember { mutableStateOf(false) }
    var singleVideoMode by remember { mutableStateOf(true) }
    var layoutTemplate by remember { mutableStateOf(LayoutTemplate.FACE_TOP_40) }
    var platformPreset by remember { mutableStateOf(PlatformPreset.TIKTOK) }
    var detectingFacecam by remember { mutableStateOf(false) }
    var detectionNote by remember { mutableStateOf("Pilih video, lalu jalankan Auto Detect.") }
    var detectionFrame by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    var facecamCrop by remember { mutableStateOf(NormalizedCrop.DEFAULT_FACECAM) }
    var facecamPreviewSize by remember { mutableStateOf(IntSize.Zero) }
    var gameplayPreviewSize by remember { mutableStateOf(IntSize.Zero) }
    var gameplayCrop by remember { mutableStateOf(NormalizedCrop.DEFAULT_GAMEPLAY) }
    var facecamUri by remember { mutableStateOf<Uri?>(null) }
    var facecamName by remember { mutableStateOf("Belum ada facecam") }
    var facecamDurationMs by remember { mutableLongStateOf(0L) }
    var smartHighlightEnabled by remember { mutableStateOf(true) }
    // Subtitles are intentionally off until an actual transcription pipeline exists.
    val subtitlesEnabled = false

    fun runFacecamDetect(selected: Uri) {
        detectingFacecam = true
        detectionNote = "Menganalisis frame secara lokal..."
        thread {
            val result = runCatching { SingleVideoFacecamDetector.inspect(context, selected) }
            Handler(Looper.getMainLooper()).post {
                detectingFacecam = false
                if (videoUri != selected) return@post // video changed meanwhile: drop stale result
                result.onSuccess {
                    detectionFrame = it.frame
                    it.suggestedCrop?.let { crop -> facecamCrop = crop }
                    detectionNote = it.note
                }.onFailure { detectionNote = "Analisis gagal: ${it.message ?: "format video tidak didukung"}. Gunakan crop manual." }
            }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            analysisGeneration++
            suggestions = emptyList()
            selectedSuggestion = -1
            approvedCuts = emptySet()
            autoCutExport = false
            analyzing = false
            videoUri = uri
            fullscreenPreview = false
            editorPanel = "edit"
            detectionFrame = null
            detectionNote = "Video baru dipilih."
            try {
                val retriever = MediaMetadataRetriever()
                retriever.setDataSource(context, uri)
                durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                retriever.release()
                startMs = 0L
                endMs = durationMs
                videoName = uri.lastPathSegment?.substringAfterLast('/')?.take(32) ?: "Video dipilih"
                status = "Video siap diedit. Atur rentang klip, lalu export."
                if (singleVideoMode) runFacecamDetect(uri)
            } catch (_: Exception) {
                durationMs = 0L
                endMs = 0L
                status = "Video dipilih, tetapi durasinya tidak dapat dibaca."
            }
        }
    }

    val facecamPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            facecamUri = uri
            facecamName = uri.lastPathSegment?.substringAfterLast('/')?.take(32) ?: "Facecam dipilih"
            facecamDurationMs = runCatching {
                MediaMetadataRetriever().use { retriever ->
                    retriever.setDataSource(context, uri)
                    retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                }
            }.getOrDefault(0L)
            status = "Facecam siap. Periksa sinkronisasi dengan gameplay sebelum ekspor."
        }
    }

    val facecamPlayer = remember(facecamUri, gamingSplitEnabled) {
        if (gamingSplitEnabled) facecamUri?.let { uri ->
            ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(uri)); prepare(); volume = 0f
            }
        } else null
    }
    DisposableEffect(facecamPlayer) { onDispose { facecamPlayer?.release() } }

    val player = remember(videoUri) {
        videoUri?.let {
            ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(it))
                prepare()
                playWhenReady = false
                addListener(object : Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
                })
            }
        }
    }
    DisposableEffect(player) { onDispose { player?.release() } }

    // Live split preview: the main player (audio, controls, timeline) drives the gameplay panel;
    // a second muted player on the same file drives the facecam panel. Each is rendered into a
    // TextureView sized/offset so only its crop region is visible (see CropViewport).
    var videoDispW by remember(videoUri) { mutableFloatStateOf(0f) }
    var videoDispH by remember(videoUri) { mutableFloatStateOf(0f) }
    val singleFacePlayer = remember(videoUri, gamingSplitEnabled, singleVideoMode) {
        if (gamingSplitEnabled && singleVideoMode) videoUri?.let { uri ->
            ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(uri)); prepare(); volume = 0f; playWhenReady = false
            }
        } else null
    }
    DisposableEffect(singleFacePlayer) { onDispose { singleFacePlayer?.release() } }
    // LaunchedEffect runs on the main dispatcher, which is where ExoPlayer must be accessed.
    LaunchedEffect(player, singleFacePlayer) {
        val main = player ?: return@LaunchedEffect
        while (true) {
            val vs = main.videoSize
            if (vs.width > 0 && vs.height > 0) {
                val w = vs.width * vs.pixelWidthHeightRatio
                val h = vs.height.toFloat()
                if (w != videoDispW) videoDispW = w
                if (h != videoDispH) videoDispH = h
            }
            val face = singleFacePlayer
            if (face != null) {
                if (face.playWhenReady != main.playWhenReady) face.playWhenReady = main.playWhenReady
                val drift = abs(face.currentPosition - main.currentPosition)
                if (drift > (if (main.isPlaying) 250L else 40L)) face.seekTo(main.currentPosition)
            }
            delay(if (main.isPlaying) 150L else 100L)
        }
    }

    val exportAction: () -> Unit = exportAction@{
                            val source = videoUri ?: return@exportAction
                            if (gamingSplitEnabled) {
                                if (!singleVideoMode && (facecamUri == null || facecamDurationMs < endMs)) {
                                    status = "Pilih facecam dengan durasi cukup untuk rentang ekspor."
                                    return@exportAction
                                }
                            }
                            if (ClipRangeValidator.validate(startMs, endMs, durationMs) == null) {
                                status = "Rentang klip tidak valid. Pilih durasi minimal 1 detik."
                                return@exportAction
                            }
                            exporting = true
                            status = "Menyiapkan export MP4…"
                            val output = File(context.cacheDir, "clipforge_${System.currentTimeMillis()}.mp4")
                            val keepRanges = if (!gamingSplitEnabled && autoCutExport && approvedCuts.isNotEmpty()) {
                                runCatching { AutoCutPlanner.plan(durationMs, suggestions, approvedCuts) }.getOrElse {
                                    exporting = false
                                    status = "Rencana potongan tidak valid: ${it.localizedMessage}"
                                    return@exportAction
                                }
                            } else emptyList()
                            if (!gamingSplitEnabled && autoCutExport && approvedCuts.isNotEmpty() && keepRanges.isEmpty()) {
                                exporting = false
                                status = "Tidak ada bagian video yang dapat diekspor. Batalkan beberapa potongan."
                                return@exportAction
                            }
                            val clippedItem = MediaItem.Builder()
                                .setUri(source)
                                .setClippingConfiguration(
                                    MediaItem.ClippingConfiguration.Builder()
                                        .setStartPositionMs(startMs)
                                        .setEndPositionMs(endMs)
                                        .build()
                                ).build()
                            val transformer = Transformer.Builder(context).addListener(object : Transformer.Listener {
                                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                                    try {
                                        val values = ContentValues().apply {
                                            put(MediaStore.Video.Media.DISPLAY_NAME, "ClipForge_${System.currentTimeMillis()}.mp4")
                                            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                                            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ClipForge AI")
                                            put(MediaStore.Video.Media.IS_PENDING, 1)
                                        }
                                        val dest = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                                            ?: error("Tidak dapat membuat file output.")
                                        try {
                                            context.contentResolver.openOutputStream(dest)?.use { out ->
                                                FileInputStream(output).use { input -> input.copyTo(out) }
                                            } ?: error("Tidak dapat membuka output.")
                                            context.contentResolver.update(dest, ContentValues().apply {
                                                put(MediaStore.Video.Media.IS_PENDING, 0)
                                            }, null, null)
                                        } catch (saveError: Exception) {
                                            context.contentResolver.delete(dest, null, null)
                                            throw saveError
                                        } finally {
                                            output.delete()
                                        }
                                        exporting = false
                                        status = "Export selesai. Video tersimpan di Movies/ClipForge AI."
                                    } catch (e: Exception) {
                                        exporting = false
                                        status = "Gagal menyimpan hasil: ${e.localizedMessage}"
                                    }
                                }
                                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                                    exporting = false
                                    status = "Export gagal: ${exportException.localizedMessage ?: "Kesalahan media"}"
                                    output.delete()
                                }
                            }).build()
                            try {
                                if (gamingSplitEnabled) {
                                    val composition = GamingSplitExporter.composition(
                                        source, facecamUri ?: source, singleVideoMode, layoutTemplate, platformPreset.format,
                                        facecamCrop, gameplayCrop, startMs, endMs
                                    )
                                    transformer.start(composition, output.absolutePath)
                                } else if (autoCutExport && approvedCuts.isNotEmpty()) {
                                    val items = keepRanges.map { range ->
                                        val item = MediaItem.Builder().setUri(source).setClippingConfiguration(
                                            MediaItem.ClippingConfiguration.Builder()
                                                .setStartPositionMs(range.startMs)
                                                .setEndPositionMs(range.endMs)
                                                .build()
                                        ).build()
                                        EditedMediaItem.Builder(item).build()
                                    }
                                    val sequence = EditedMediaItemSequence(items)
                                    transformer.start(Composition.Builder(sequence).build(), output.absolutePath)
                                } else transformer.start(clippedItem, output.absolutePath)
                            } catch (e: Exception) {
                                exporting = false
                                status = "Tidak dapat memulai export: ${e.localizedMessage}"
                                output.delete()
                            }

    }

    CompositionLocalProvider(LocalLightTheme provides light) {
    val White = appText
    val Muted = appMuted
    val Panel = appPanel
    val Night = appBg
    MaterialTheme(
        colorScheme = (if (light) lightColorScheme(
            primary = Color(0xFF246BE6), secondary = Color(0xFF2563EB), background = appBg,
            surface = appPanel, onPrimary = Color.White, onBackground = appText, onSurface = appText
        ) else darkColorScheme(
            primary = Blue, secondary = Violet, background = Night,
            surface = Panel, onPrimary = Color.White, onBackground = White,
            onSurface = White
        ))
    ) {
        if (themeMenuOpen) AlertDialog(
            onDismissRequest = { themeMenuOpen = false },
            title = { Text("Tema ClipForge") },
            text = { Column {
                listOf("system" to "Ikuti Sistem", "dark" to "Mode Gelap", "light" to "Mode Terang").forEach { (value, label) ->
                    Row(Modifier.fillMaxWidth().clickable {
                        themeChoice = value
                        prefs.edit().putString("theme", value).apply()
                        themeMenuOpen = false
                    }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = themeChoice == value, onClick = {
                            themeChoice = value
                            prefs.edit().putString("theme", value).apply()
                            themeMenuOpen = false
                        })
                        Spacer(Modifier.width(8.dp)); Text(label)
                    }
                }
            } },
            confirmButton = { TextButton(onClick = { themeMenuOpen = false }) { Text("Tutup") } }
        )
        if (fullscreenPreview && videoUri != null) {
            Dialog(
                onDismissRequest = { fullscreenPreview = false },
                properties = DialogProperties(usePlatformDefaultWidth = false)
            ) {
                Column(Modifier.fillMaxSize().background(Color.Black)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically) {
                        Text("Pratinjau", color = Color.White, fontWeight = FontWeight.SemiBold)
                        IconButton(onClick = { fullscreenPreview = false }) {
                            Icon(Icons.Default.FullscreenExit, "Tutup layar penuh", tint = Color.White)
                        }
                    }
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        ClipForgeVideoPreview(
                            player = player, gamingSplitEnabled = gamingSplitEnabled,
                            singleVideoMode = singleVideoMode, facePlayer = singleFacePlayer,
                        videoW = videoDispW, videoH = videoDispH,
                            facecamCrop = facecamCrop, gameplayCrop = gameplayCrop,
                            layoutTemplate = layoutTemplate, platformPreset = platformPreset
                        )
                    }
                    Row(Modifier.fillMaxWidth().padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { player?.seekTo(((player?.currentPosition ?: 0L) - 5000L).coerceAtLeast(0L)) }) {
                            Icon(Icons.Default.Undo, "Mundur 5 detik", tint = Color.White)
                        }
                        IconButton(onClick = { if (player?.isPlaying == true) player.pause() else player?.play() }) {
                            Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                                if (playing) "Jeda" else "Putar", tint = Color.White)
                        }
                        IconButton(onClick = { player?.seekTo(((player?.currentPosition ?: 0L) + 5000L).coerceAtMost(durationMs)) }) {
                            Icon(Icons.Default.Redo, "Maju 5 detik", tint = Color.White)
                        }
                    }
                }
            }
        }
        Surface(Modifier.fillMaxSize(), color = appBg) {
            Column(
                (if (videoUri == null) Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                 else Modifier.fillMaxSize()).background(appBg).padding(horizontal = 12.dp)
            ) {
                Spacer(Modifier.height(12.dp))
                if (videoUri == null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(painterResource(R.drawable.ic_clipforge_logo), contentDescription = "ClipForge", modifier = Modifier.size(48.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("ClipForge", color = White, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                            Text("CREATOR PRO  ·  v0.7.1", color = Muted, fontSize = 11.sp)
                        }
                    }
                    TextButton(onClick = { themeMenuOpen = true }, modifier = Modifier.align(Alignment.End)) {
                        Text("Tema: " + when(themeChoice) { "dark" -> "Gelap"; "light" -> "Terang"; else -> "Sistem" })
                    }
                    Spacer(Modifier.height(16.dp))
                    Text("Mulai berkarya.", color = White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(7.dp))
                    Text("Edit video jadi lebih mudah.", color = Muted, fontSize = 14.sp)
                    Spacer(Modifier.height(28.dp))
                    Button(
                        onClick = { picker.launch("video/*") },
                        modifier = Modifier.fillMaxWidth().height(100.dp),
                        shape = RoundedCornerShape(22.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Blue)
                    ) {
                        Icon(Icons.Default.Add, null, modifier = Modifier.size(32.dp))
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text("Proyek Baru", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Text("Pilih video dari galeri", fontSize = 12.sp)
                        }
                    }
                    Spacer(Modifier.height(30.dp))
                    Text("Mulai dengan", color = White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        StudioQuickCard("Gaming Split", "Facecam + gameplay", Modifier.weight(1f)) {
                            gamingSplitEnabled = true
                            picker.launch("video/*")
                        }
                        StudioQuickCard("Video Biasa", "Potong & edit", Modifier.weight(1f)) {
                            gamingSplitEnabled = false
                            picker.launch("video/*")
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("Smart Auto Cut tersedia setelah video dipilih.", color = Muted, fontSize = 12.sp)
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { player?.pause(); facecamPlayer?.pause(); activeTool = null; videoUri = null }) {
                            Text("‹  Beranda", color = White, fontSize = 14.sp)
                        }
                        Spacer(Modifier.weight(1f))
                        Text("Editor", color = White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        TextButton(onClick = { themeMenuOpen = true }) { Text("◐", fontSize = 18.sp) }
                        Spacer(Modifier.weight(1f))
                        Button(onClick = exportAction,
                            enabled = !exporting && (!gamingSplitEnabled || singleVideoMode || facecamUri != null),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 3.dp),
                            shape = RoundedCornerShape(9.dp)) {
                            Text(if (exporting) "Proses…" else "Ekspor", fontSize = 13.sp)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                Box(
                    Modifier.fillMaxWidth().weight(1f).heightIn(min = 160.dp).background(Color(0xFF05070B)),
                    contentAlignment = Alignment.Center
                ) {
                    // Only one preview owns the video surfaces at a time (the fullscreen dialog has its own).
                    if (!fullscreenPreview) ClipForgeVideoPreview(
                        player = player, gamingSplitEnabled = gamingSplitEnabled,
                        singleVideoMode = singleVideoMode, facePlayer = singleFacePlayer,
                        videoW = videoDispW, videoH = videoDispH,
                        facecamCrop = facecamCrop, gameplayCrop = gameplayCrop,
                        layoutTemplate = layoutTemplate, platformPreset = platformPreset
                    )
                    IconButton(
                        onClick = { fullscreenPreview = true },
                        modifier = Modifier.align(Alignment.BottomEnd)
                            .background(Color(0x99000000), RoundedCornerShape(8.dp))
                    ) { Icon(Icons.Default.Fullscreen, "Layar penuh", tint = Color.White) }
                }
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(onClick = { picker.launch("video/*") }) {
                        Icon(Icons.Default.FolderOpen, null, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(5.dp))
                        Text("Ganti", fontSize = 12.sp)
                    }
                    IconButton(onClick = { player?.seekTo(((player?.currentPosition ?: 0L) - 5000L).coerceAtLeast(0L)) }) {
                        Icon(Icons.Default.Undo, "Mundur 5 detik", tint = White)
                    }
                    IconButton(onClick = { if (player?.isPlaying == true) player.pause() else player?.play() }) {
                        Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                            if (playing) "Jeda" else "Putar", tint = White, modifier = Modifier.size(30.dp))
                    }
                    IconButton(onClick = { player?.seekTo(((player?.currentPosition ?: 0L) + 5000L).coerceAtMost(durationMs)) }) {
                        Icon(Icons.Default.Redo, "Maju 5 detik", tint = White)
                    }
                    Text(platformPreset.format.label, color = Muted, fontSize = 11.sp)
                }
                ClipTimeline(videoUri = videoUri, durationMs = durationMs, player = player,
                    startMs = startMs, endMs = endMs)
                Spacer(Modifier.height(4.dp))
                // CapCut-style dock: a toolbar of icons; tapping one opens a compact panel (back arrow returns).
                // The page itself never scrolls; only a long panel (e.g. Auto Cut list) scrolls inside the dock.
                BackHandler(enabled = activeTool != null) { activeTool = null }
                if (exporting || status.contains("gagal", ignoreCase = true) || status.contains("selesai", ignoreCase = true)) {
                    Text(status, color = if (status.contains("gagal", ignoreCase = true)) Color(0xFFFFB4A8) else Muted,
                        fontSize = 12.sp, maxLines = 2, modifier = Modifier.padding(vertical = 4.dp))
                }
                val tool = activeTool
                if (tool == null) {
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        ToolItem(Icons.Default.ContentCut, "Potong") { activeTool = "trim" }
                        ToolItem(Icons.Default.ViewAgenda, "Layout") { activeTool = "layout" }
                        ToolItem(Icons.Default.AspectRatio, "Format") { activeTool = "format" }
                        ToolItem(Icons.Default.Face, "Facecam") { activeTool = "facecam" }
                        ToolItem(Icons.Default.AutoAwesome, "Auto Cut") { activeTool = "auto" }
                    }
                } else {
                    Column(Modifier.fillMaxWidth().heightIn(max = 280.dp)) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { activeTool = null }) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Kembali", tint = White)
                            }
                            Text(
                                when (tool) {
                                    "trim" -> "Potong"
                                    "layout" -> "Layout"
                                    "format" -> "Format konten"
                                    "facecam" -> "Facecam"
                                    else -> "Auto Cut"
                                },
                                color = White, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = { activeTool = null }) { Icon(Icons.Default.Check, "Selesai", tint = Blue) }
                        }
                        Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()).padding(horizontal = 6.dp)) {
                            when (tool) {
                                "trim" -> {
                                    if (durationMs >= 1000L) {
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("MULAI  ${formatTime(startMs)}", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                            Text("SELESAI  ${formatTime(endMs)}", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                        }
                                        RangeSlider(
                                            value = startMs.toFloat()..endMs.toFloat(),
                                            onValueChange = { range ->
                                                val a = range.start.toLong().coerceIn(0L, (durationMs - 1000L).coerceAtLeast(0L))
                                                val b = range.endInclusive.toLong().coerceIn(a + 1000L, durationMs)
                                                startMs = a
                                                endMs = b
                                            },
                                            valueRange = 0f..durationMs.toFloat()
                                        )
                                        Text("Durasi klip: ${formatTime((endMs - startMs).coerceAtLeast(0L))}", color = White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    } else {
                                        Text("Import video untuk mengaktifkan kontrol pemotongan.", color = Muted, fontSize = 13.sp)
                                    }
                                }
                                "layout" -> {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        FilterChip(selected = gamingSplitEnabled, onClick = { gamingSplitEnabled = true }, label = { Text("Gaming Split") })
                                        FilterChip(selected = !gamingSplitEnabled, onClick = { gamingSplitEnabled = false }, label = { Text("Video Biasa") })
                                    }
                                    if (gamingSplitEnabled) {
                                        Spacer(Modifier.height(8.dp))
                                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            LayoutTemplate.values().forEach { option ->
                                                val selected = layoutTemplate == option
                                                Column(
                                                    Modifier.width(96.dp).clip(RoundedCornerShape(12.dp))
                                                        .border(if (selected) 2.dp else 1.dp, if (selected) Blue else Muted.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                                        .clickable { layoutTemplate = option }.padding(8.dp),
                                                    horizontalAlignment = Alignment.CenterHorizontally
                                                ) {
                                                    LayoutThumb(option, platformPreset.format,
                                                        Modifier.height(64.dp).aspectRatio(platformPreset.format.width.toFloat() / platformPreset.format.height))
                                                    Spacer(Modifier.height(4.dp))
                                                    Text(option.label, color = White, fontSize = 10.sp, maxLines = 2,
                                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                                }
                                            }
                                        }
                                        Text(layoutTemplate.description, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
                                    } else {
                                        Text("Mode video biasa: framing asli, tanpa split facecam.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
                                    }
                                }
                                "format" -> {
                                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        PlatformPreset.values().forEach { preset ->
                                            FilterChip(selected = preset == platformPreset, onClick = { platformPreset = preset },
                                                label = { Text("${preset.label} · ${preset.format.label}", fontSize = 11.sp) })
                                        }
                                    }
                                    Text("Output ${platformPreset.format.sizeLabel} px. Berlaku untuk export Gaming Split.", color = Muted, fontSize = 11.sp,
                                        modifier = Modifier.padding(top = 8.dp))
                                }
                                "facecam" -> {
                                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically) {
                                        FilterChip(selected = singleVideoMode, onClick = { singleVideoMode = true }, label = { Text("Satu video") })
                                        FilterChip(selected = !singleVideoMode, onClick = { singleVideoMode = false }, label = { Text("Dua video") })
                                        if (singleVideoMode) OutlinedButton(onClick = {
                                            videoUri?.let { runFacecamDetect(it) }
                                        }, enabled = videoUri != null && !detectingFacecam, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) {
                                            Text(if (detectingFacecam) "Mendeteksi..." else "Auto Detect", fontSize = 12.sp)
                                        }
                                    }
                                    if (!gamingSplitEnabled) {
                                        Text("Aktifkan Gaming Split di menu Layout untuk memakai facecam.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
                                    } else if (singleVideoMode) {
                                        Text(detectionNote, color = Muted, fontSize = 11.sp, maxLines = 2, modifier = Modifier.padding(top = 4.dp))
                                        var cropTab by remember { mutableIntStateOf(0) }
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            FilterChip(selected = cropTab == 0, onClick = { cropTab = 0 }, label = { Text("Crop facecam") })
                                            FilterChip(selected = cropTab == 1, onClick = { cropTab = 1 }, label = { Text("Crop gameplay") })
                                        }
                                        if (cropTab == 0) {
                                            CropSliderRow("Horizontal ${(facecamCrop.left * 100).toInt()}%", facecamCrop.left, 0f..(1f - facecamCrop.width)) {
                                                facecamCrop = facecamCrop.shifted(it, facecamCrop.top)
                                            }
                                            CropSliderRow("Vertikal ${(facecamCrop.top * 100).toInt()}%", facecamCrop.top, 0f..(1f - facecamCrop.height)) {
                                                facecamCrop = facecamCrop.shifted(facecamCrop.left, it)
                                            }
                                            CropSliderRow("Ukuran ${(facecamCrop.width * 100).toInt()}%", facecamCrop.width, 0.15f..0.65f) {
                                                val side = it.coerceIn(0.15f, 0.65f)
                                                facecamCrop = NormalizedCrop(facecamCrop.left.coerceAtMost(1f - side), facecamCrop.top.coerceAtMost(1f - side), side, side)
                                            }
                                        } else {
                                            CropSliderRow("Horizontal ${(gameplayCrop.left * 100).toInt()}%", gameplayCrop.left, 0f..(1f - gameplayCrop.width)) {
                                                gameplayCrop = gameplayCrop.shifted(it, gameplayCrop.top)
                                            }
                                            CropSliderRow("Zoom ${(100f / gameplayCrop.width).toInt()}%", gameplayCrop.width, 0.5f..1f) {
                                                val size = it.coerceIn(0.5f, 1f)
                                                gameplayCrop = NormalizedCrop(gameplayCrop.left.coerceAtMost(1f - size), gameplayCrop.top.coerceAtMost(1f - size), size, size)
                                            }
                                        }
                                    } else {
                                        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                            Box(Modifier.width(96.dp).aspectRatio(1f).clip(RoundedCornerShape(10.dp)).background(Color(0xFF24344E)),
                                                contentAlignment = Alignment.Center) {
                                                if (facecamPlayer != null) AndroidView(
                                                    modifier = Modifier.fillMaxSize(),
                                                    factory = { ctx -> PlayerView(ctx).apply { useController = false; this.player = facecamPlayer } },
                                                    update = { it.player = facecamPlayer }
                                                ) else Text("FACECAM", color = White, fontSize = 11.sp)
                                            }
                                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                OutlinedButton(onClick = { facecamPicker.launch("video/*") }, modifier = Modifier.fillMaxWidth(),
                                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)) {
                                                    Icon(Icons.Default.FolderOpen, null, modifier = Modifier.size(16.dp))
                                                    Spacer(Modifier.width(6.dp))
                                                    Text("Pilih video facecam", fontSize = 12.sp)
                                                }
                                                Text(facecamName, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                OutlinedButton(onClick = {
                                                    if (player?.isPlaying == true) { player.pause(); facecamPlayer?.pause() }
                                                    else { facecamPlayer?.seekTo(player?.currentPosition ?: 0L); player?.play(); facecamPlayer?.play() }
                                                }, enabled = videoUri != null && facecamUri != null, modifier = Modifier.fillMaxWidth(),
                                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)) {
                                                    Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(16.dp))
                                                    Spacer(Modifier.width(6.dp))
                                                    Text("Play / Pause kedua video", fontSize = 12.sp)
                                                }
                                            }
                                        }
                                        val overlap = GamingSplitTemplate.overlapDuration(durationMs, facecamDurationMs)
                                        Text("Durasi bersama: ${formatTime(overlap)} · sinkron dari 00:00. Pastikan kedua video sinkron dari awal.",
                                            color = Color(0xFFFFC47C), fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
                                    }
                                }
                                else -> {
                                    Text("Deteksi bagian hening secara offline. Periksa setiap saran sebelum memotong.", color = Muted, fontSize = 12.sp)
                                    Spacer(Modifier.height(8.dp))
                                    Button(
                                        onClick = {
                                            val source = videoUri ?: return@Button
                                            val generation = ++analysisGeneration
                                            analyzing = true
                                            suggestions = emptyList()
                                            selectedSuggestion = -1
                                            approvedCuts = emptySet()
                                            autoCutExport = false
                                            status = "Menganalisis audio video di perangkat…"
                                            thread(name = "clipforge-silence-analysis") {
                                                val result = runCatching { VideoSilenceAnalyzer.analyze(context.applicationContext, source) }
                                                Handler(Looper.getMainLooper()).post {
                                                    if (generation == analysisGeneration) {
                                                        analyzing = false
                                                        result.onSuccess {
                                                            suggestions = it
                                                            status = if (it.isEmpty()) "Tidak ditemukan keheningan panjang." else "${it.size} saran keheningan ditemukan. Pilih untuk meninjau."
                                                        }.onFailure { status = "Analisis gagal: ${it.localizedMessage ?: "Audio tidak didukung"}" }
                                                    }
                                                }
                                            }
                                        },
                                        enabled = videoUri != null && !analyzing && !exporting,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        if (analyzing) CircularProgressIndicator(Modifier.size(17.dp), strokeWidth = 2.dp)
                                        else Icon(Icons.Default.AutoAwesome, null)
                                        Spacer(Modifier.width(8.dp))
                                        Text(if (analyzing) "Analyzing…" else "Analyze Silence")
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Checkbox(checked = smartHighlightEnabled, onCheckedChange = { smartHighlightEnabled = it })
                                        Text("Smart Highlight (kandidat berbasis audio)", color = White, fontSize = 12.sp)
                                    }
                                    Text("Subtitle otomatis: NONAKTIF", color = Muted, fontSize = 11.sp)
                                    if (gamingSplitEnabled && smartHighlightEnabled) {
                                        Text("Smart Highlight: kandidat bagian bersuara di antara keheningan (bukan deteksi kill/gameplay).", color = Muted, fontSize = 11.sp)
                                        val highlights = GamingHighlightPlanner.candidates(durationMs, suggestions)
                                        highlights.take(5).forEachIndexed { index, range ->
                                            OutlinedButton(onClick = {
                                                player?.seekTo(range.startMs)
                                                facecamPlayer?.seekTo(range.startMs)
                                                status = "Kandidat highlight ${index + 1} siap ditinjau."
                                            }, modifier = Modifier.fillMaxWidth()) {
                                                Text("Highlight ${index + 1}: ${formatTime(range.startMs)} – ${formatTime(range.endMs)}")
                                            }
                                        }
                                    }
                                    if (suggestions.isNotEmpty()) {
                                        Text("Centang hanya bagian hening yang ingin dihapus. Preview tetap dapat ditinjau sebelum export.", color = Muted, fontSize = 11.sp)
                                    }
                                    suggestions.forEachIndexed { index, suggestion ->
                                        val chosen = selectedSuggestion == index
                                        Spacer(Modifier.height(8.dp))
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Checkbox(
                                                checked = index in approvedCuts,
                                                onCheckedChange = { checked ->
                                                    approvedCuts = if (checked) approvedCuts + index else approvedCuts - index
                                                    autoCutExport = false
                                                }
                                            )
                                            OutlinedButton(
                                                onClick = {
                                                    selectedSuggestion = index
                                                    player?.seekTo(suggestion.startMs)
                                                    status = "Hening ${formatTime(suggestion.startMs)}–${formatTime(suggestion.endMs)}. Ini hanya rekomendasi; video asli aman."
                                                }, modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Text("${if (chosen) "▶ " else ""}Hening ${formatTime(suggestion.startMs)} – ${formatTime(suggestion.endMs)}")
                                            }
                                        }
                                    }
                                    if (approvedCuts.isNotEmpty()) {
                                        val planned = runCatching { AutoCutPlanner.plan(durationMs, suggestions, approvedCuts) }.getOrDefault(emptyList())
                                        Text("${approvedCuts.size} bagian disetujui untuk dihapus · ${planned.size} segmen dipertahankan", color = White, fontSize = 12.sp)
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Checkbox(checked = autoCutExport, onCheckedChange = { autoCutExport = it && planned.isNotEmpty() }, enabled = planned.isNotEmpty())
                                            Text("Gunakan Smart Auto Cut saat export", color = White, fontSize = 12.sp)
                                        }
                                        if (autoCutExport) Text("Tombol Ekspor akan menggabungkan segmen yang dipertahankan. Rentang manual diabaikan dalam mode ini.", color = Muted, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
                } // end editor
            }
        }
    }
}
}

@Composable
private fun ToolItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Column(
        Modifier.width(72.dp).clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.onBackground, modifier = Modifier.size(26.dp))
        Spacer(Modifier.height(4.dp))
        Text(label, color = MaterialTheme.colorScheme.onBackground, fontSize = 11.sp, maxLines = 1)
    }
}

@Composable
private fun CropSliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = MaterialTheme.colorScheme.onBackground, fontSize = 11.sp, modifier = Modifier.width(104.dp), maxLines = 1)
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun StudioQuickCard(title: String, description: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(onClick = onClick, modifier = modifier.height(112.dp), color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.Center) {
            Text(title, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(Modifier.height(7.dp))
            Text(description, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f), fontSize = 11.sp)
        }
    }
}

@Composable
private fun StudioCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(23.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(23.dp))
            .padding(17.dp),
        content = content
    )
}

private fun formatTime(ms: Long): String {
    val total = (ms / 1000L).coerceAtLeast(0L)
    return String.format(Locale.US, "%02d:%02d", total / 60L, total % 60L)
}


/** Small schematic of a layout: shows where facecam and gameplay go. */
@Composable
fun LayoutThumb(template: LayoutTemplate, format: OutputFormat, modifier: Modifier = Modifier) {
    BoxWithConstraints(modifier.clip(RoundedCornerShape(4.dp)).background(Color.Black)) {
        template.layers(format).forEach { l ->
            val face = l.source == LayerSource.FACECAM
            Box(
                Modifier
                    .offset(x = maxWidth * (l.x.toFloat() / format.width), y = maxHeight * (l.y.toFloat() / format.height))
                    .size(maxWidth * (l.width.toFloat() / format.width), maxHeight * (l.height.toFloat() / format.height))
                    .background(if (face) Color(0xFF3B6FD4) else Color(0xFF1E8F6A))
                    .border(0.5.dp, Color.Black)
            )
        }
    }
}

/** A source-backed timeline: thumbnails are extracted off the UI thread.
 * Tapping a frame or dragging the seek bar moves the actual Media3 player. */
@Composable
private fun ClipTimeline(
    videoUri: Uri?, durationMs: Long, player: ExoPlayer?,
    startMs: Long, endMs: Long
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var frames by remember(videoUri) { mutableStateOf<List<android.graphics.Bitmap?>>(emptyList()) }
    var positionMs by remember(videoUri) { mutableLongStateOf(0L) }
    LaunchedEffect(videoUri, durationMs) {
        frames = emptyList()
        val uri = videoUri ?: return@LaunchedEffect
        if (durationMs <= 0L) return@LaunchedEffect
        frames = withContext(Dispatchers.IO) {
            runCatching {
                MediaMetadataRetriever().use { retriever ->
                    retriever.setDataSource(context, uri)
                    (0 until 12).map { index ->
                        val timeUs = (durationMs * index / 12L) * 1000L
                        retriever.getScaledFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 112, 112)
                    }
                }
            }.getOrDefault(emptyList())
        }
    }
    LaunchedEffect(player) {
        while (true) {
            positionMs = player?.currentPosition?.coerceAtLeast(0L) ?: 0L
            delay(150)
        }
    }
    Column(Modifier.fillMaxWidth().background(Color(0xFF11151E)).padding(vertical = 8.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("${formatTime(positionMs)} / ${formatTime(durationMs)}", color = White, fontSize = 12.sp)
            Text("TIMELINE", color = Muted, fontSize = 10.sp)
        }
        Spacer(Modifier.height(7.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp)) {
            val count = 12
            repeat(count) { index ->
                val t = (durationMs * index / count).coerceAtLeast(0L)
                val frame = frames.getOrNull(index)
                Box(
                    Modifier.width(52.dp).height(54.dp)
                        .border(if (positionMs in t..(durationMs * (index + 1) / count)) 2.dp else 0.dp,
                            if (positionMs in t..(durationMs * (index + 1) / count)) Blue else Color.Transparent)
                        .background(Panel2)
                        .clickable { player?.seekTo(t) },
                    contentAlignment = Alignment.Center
                ) {
                    if (frame != null) Image(frame.asImageBitmap(), "Frame ${index + 1}", Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    else Icon(Icons.Default.VideoLibrary, null, tint = Muted, modifier = Modifier.size(18.dp))
                }
                Spacer(Modifier.width(2.dp))
            }
        }
        if (durationMs > 0L) {
            Slider(
                value = positionMs.coerceIn(0L, durationMs).toFloat(),
                onValueChange = { player?.seekTo(it.toLong()) },
                valueRange = 0f..durationMs.toFloat(),
                modifier = Modifier.fillMaxWidth().height(30.dp).padding(horizontal = 8.dp)
            )
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Mulai ${formatTime(startMs)}", color = Muted, fontSize = 10.sp)
            Text("Selesai ${formatTime(endMs)}", color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun ClipForgeVideoPreview(
    player: ExoPlayer?, gamingSplitEnabled: Boolean, singleVideoMode: Boolean,
    facePlayer: ExoPlayer?, videoW: Float, videoH: Float,
    facecamCrop: NormalizedCrop,
    gameplayCrop: NormalizedCrop, layoutTemplate: LayoutTemplate,
    platformPreset: PlatformPreset
) {
    Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        if (gamingSplitEnabled && singleVideoMode && player != null && facePlayer != null && videoW > 0f && videoH > 0f) {
            Box(Modifier.fillMaxHeight().aspectRatio(platformPreset.format.width.toFloat() / platformPreset.format.height).background(Color.Black)) {
                when (layoutTemplate) {
                    LayoutTemplate.PIP_TOP_LEFT, LayoutTemplate.PIP_TOP_RIGHT -> {
                        CroppedVideo(player, gameplayCrop, videoW, videoH, Modifier.fillMaxSize())
                        CroppedVideo(
                            facePlayer, facecamCrop, videoW, videoH,
                            Modifier.align(if (layoutTemplate == LayoutTemplate.PIP_TOP_LEFT) Alignment.TopStart else Alignment.TopEnd)
                                .padding(9.dp).fillMaxWidth(0.34f).aspectRatio(1f)
                        )
                    }
                    else -> {
                        val faceFirst = layoutTemplate != LayoutTemplate.FACE_BOTTOM_40
                        val faceWeight = if (layoutTemplate == LayoutTemplate.FACE_TOP_50) 0.5f else 0.4f
                        Column(Modifier.fillMaxSize()) {
                            if (faceFirst) {
                                CroppedVideo(facePlayer, facecamCrop, videoW, videoH, Modifier.fillMaxWidth().weight(faceWeight))
                                CroppedVideo(player, gameplayCrop, videoW, videoH, Modifier.fillMaxWidth().weight(1f - faceWeight))
                            } else {
                                CroppedVideo(player, gameplayCrop, videoW, videoH, Modifier.fillMaxWidth().weight(1f - faceWeight))
                                CroppedVideo(facePlayer, facecamCrop, videoW, videoH, Modifier.fillMaxWidth().weight(faceWeight))
                            }
                        }
                    }
                }
            }
        } else AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx -> PlayerView(ctx).apply {
                useController = false
                resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                this.player = player
            } },
            update = { it.player = player }
        )
    }
}

/** Shows only [crop] of the player's video, scaled to fill (center-crop) this composable's bounds. */
@Composable
private fun CroppedVideo(player: ExoPlayer, crop: NormalizedCrop, videoW: Float, videoH: Float, modifier: Modifier) {
    BoxWithConstraints(modifier.clipToBounds().background(Color.Black)) {
        val vp = CropViewport.compute(maxWidth.value, maxHeight.value, crop, videoW, videoH)
            ?: return@BoxWithConstraints
        key(player) {
            AndroidView(
                modifier = Modifier
                    .wrapContentSize(Alignment.TopStart, unbounded = true)
                    .size(vp.displayWidth.dp, vp.displayHeight.dp)
                    .offset(vp.offsetX.dp, vp.offsetY.dp),
                factory = { ctx -> TextureView(ctx).also { player.setVideoTextureView(it) } },
                onRelease = { view -> player.clearVideoTextureView(view) }
            )
        }
    }
}
