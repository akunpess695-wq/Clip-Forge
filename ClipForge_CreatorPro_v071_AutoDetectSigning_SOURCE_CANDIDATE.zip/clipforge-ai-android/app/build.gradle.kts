plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.clipforge.ai"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.clipforge.ai"
        minSdk = 29
        targetSdk = 35
        versionCode = 25
        versionName = "0.7.1"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    // Stable signing: when CI provides a keystore (see docs/APK_UPDATE_AND_SIGNING.md) the debug APK
    // is signed with it, so every build carries the same certificate and updates in place.
    // Without the env vars the default per-machine debug key is used (updates may conflict).
    val ksPath = System.getenv("CLIPFORGE_KEYSTORE_PATH")
    if (!ksPath.isNullOrBlank() && file(ksPath).exists()) {
        signingConfigs {
            create("ci") {
                storeFile = file(ksPath)
                storePassword = System.getenv("CLIPFORGE_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("CLIPFORGE_KEY_ALIAS")
                keyPassword = System.getenv("CLIPFORGE_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        debug {
            signingConfigs.findByName("ci")?.let { signingConfig = it }
        }
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-ui:1.5.1")
    implementation("androidx.media3:media3-transformer:1.5.1")

    debugImplementation("androidx.compose.ui:ui-tooling")
    testImplementation("junit:junit:4.13.2")
}
