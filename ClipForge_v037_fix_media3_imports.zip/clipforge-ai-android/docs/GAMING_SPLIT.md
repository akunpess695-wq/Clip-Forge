# Gaming Split v0.3.4

Facecam 40% top, gameplay 60% bottom, 9:16 (720x1280), subtitle OFF, Smart Highlight audio heuristic ON. Single-source and dual-source modes now have an **experimental Media3 composition export path** in `GamingSplitExporter.kt`. Export is NOT yet device-verified; crop-to-slot aspect mismatch may letterbox. Audio comes from gameplay only. See `PROJECT_HANDOFF.md` for verification and known limitations.
