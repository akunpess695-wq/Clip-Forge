# GitHub Actions Kotlin build fix

Screenshot: `:app:compileDebugKotlin` fails, mentions `SingleVideoFacecamDetector.kt:43:34` and `times` overload candidates. Full first compiler error was not shown.

Changes in `SingleVideoFacecamDetector.kt`:
- `Array(8) { FaceDetector.Face() }` -> `arrayOfNulls<FaceDetector.Face>(8)`; platform detector fills face array.
- Skip null face slots.
- Use explicitly typed `Triple<Float, Float, Float>` and `faceSize: Float` before arithmetic.

**Verification pending:** No Android SDK/Gradle in authoring environment. On GitHub Actions run `./gradlew testDebugUnitTest assembleDebug --stacktrace`; inspect first `e: file:///` line if failure persists. Do not treat this as verified fixed until green.
