# Memperbarui ClipForge tanpa uninstall

## Aturan Android

- Pertahankan `applicationId = "com.clipforge.ai"`.
- Tingkatkan `versionCode` setiap rilis; versi ini `4`, `versionName = "0.3.3"`.
- APK baru **harus ditandatangani dengan sertifikat yang sama** dengan APK yang sudah terpasang. Nomor versi saja tidak cukup.
- Debug APK dari GitHub Actions runner yang membuat debug keystore baru dapat memiliki sertifikat berbeda setiap run. Akibatnya, update in-place gagal walau versionCode meningkat.

## Solusi signing stabil (untuk rilis berikutnya)

1. Buat keystore pribadi di mesin tepercaya (`keytool -genkeypair ...`), simpan di tempat aman, jangan commit ke repository.
2. Simpan keystore sebagai secret GitHub Actions (misalnya base64) dan password/alias sebagai secrets terpisah.
3. Konfigurasikan `signingConfigs` untuk build **release** menggunakan secrets tersebut.
4. Gunakan keystore yang sama pada setiap build dan tingkatkan `versionCode` setiap rilis.
5. Untuk memperbarui APK debug yang sudah terpasang, sertifikat debug lama harus cocok. APK release dengan kunci baru tidak dapat menggantikan APK debug lama secara langsung. Migrasi pertama mungkin memerlukan uninstall, kecuali keystore lama dapat digunakan kembali. Backup data sebelum migrasi.

## Pemeriksaan

- `./gradlew :app:assembleDebug` untuk kompilasi, bila wrapper dan SDK tersedia.
- `apksigner verify --print-certs path/to/app.apk` untuk membandingkan fingerprint sertifikat APK lama dan baru.
- `adb shell dumpsys package com.clipforge.ai` untuk melihat versionCode terpasang.
- `adb install -r path/to/app.apk` untuk mencoba update tanpa uninstall.

## Status export Gaming Split

Masih belum diimplementasikan dalam source ini. Media3 Transformer yang tersedia saat ini hanya mengekspor video biasa / hasil Auto Cut; membuat komposisi dua crop dari satu sumber dengan audio sinkron membutuhkan renderer komposit yang belum dibuat. Jangan mengaktifkan tombol export split sebelum output diuji.
