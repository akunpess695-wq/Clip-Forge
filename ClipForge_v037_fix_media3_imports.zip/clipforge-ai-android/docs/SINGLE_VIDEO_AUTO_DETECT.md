# Single-video Auto Detect + Manual Crop

One-video mode defaults ON. Import source video, tap Auto Detect Facecam. The local platform detector samples one frame and estimates a face-centered square crop. Move/resize the crop manually using sliders. Gameplay is cropped independently; the static preview illustrates the 40/60 output. If no face is detected, use manual fallback. No source modification and no split export. Do not claim AI gameplay understanding.
