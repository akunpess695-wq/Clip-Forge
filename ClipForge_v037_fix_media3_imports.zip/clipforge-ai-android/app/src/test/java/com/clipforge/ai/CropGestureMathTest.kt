package com.clipforge.ai

import org.junit.Assert.assertEquals
import org.junit.Test

class CropGestureMathTest {
    @Test fun horizontalDragDoesNotMoveVerticalCrop() {
        val c = NormalizedCrop(0.2f, 0.3f, 0.4f, 0.4f)
        val moved = CropGestureMath.update(c, 10f, 0f, 1f, 100f, 100f, 0.15f, 0.65f)
        assertEquals(0.3f, moved.top, 0.0001f)
        assertEquals(0.16f, moved.left, 0.0001f)
    }
    @Test fun verticalDragDoesNotMoveHorizontalCrop() {
        val c = NormalizedCrop(0.2f, 0.3f, 0.4f, 0.4f)
        val moved = CropGestureMath.update(c, 0f, 10f, 1f, 100f, 100f, 0.15f, 0.65f)
        assertEquals(0.2f, moved.left, 0.0001f)
    }
    @Test fun pinchKeepsCropInsideBounds() {
        val c = NormalizedCrop.DEFAULT_FACECAM
        val moved = CropGestureMath.update(c, 100f, -100f, 5f, 100f, 100f, 0.15f, 0.65f)
        assertEquals(0.15f, moved.width, 0.0001f)
        assert(moved.left >= 0f && moved.top >= 0f && moved.left + moved.width <= 1f)
    }
}
