package com.clipforge.ai

import org.junit.Assert.*
import org.junit.Test

class SingleVideoCropTest {
    @Test fun centeredCropClampsToImage() {
        val crop = NormalizedCrop.centeredOn(0.99f, 0.01f, 0.3f, 0.3f)
        assertEquals(0.7f, crop.left, 0.0001f)
        assertEquals(0f, crop.top, 0.0001f)
    }
    @Test fun shiftedCropCannotEscape() {
        val crop = NormalizedCrop.DEFAULT_FACECAM.shifted(10f, -10f)
        assertTrue(crop.left + crop.width <= 1.0001f)
        assertEquals(0f, crop.top, 0.0001f)
    }
    @Test(expected = IllegalArgumentException::class) fun invalidCropRejected() {
        NormalizedCrop(0.9f, 0f, 0.5f, 0.2f)
    }
}
