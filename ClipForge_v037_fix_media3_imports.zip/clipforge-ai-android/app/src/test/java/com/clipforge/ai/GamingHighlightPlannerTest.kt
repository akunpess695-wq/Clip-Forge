package com.clipforge.ai

import org.junit.Assert.assertEquals
import org.junit.Test

class GamingHighlightPlannerTest {
    @Test fun noSilenceMeansWholeVideoCandidate() {
        assertEquals(listOf(KeepRange(0, 10_000)), GamingHighlightPlanner.candidates(10_000, emptyList()))
    }
    @Test fun tooShortCandidatesExcluded() {
        assertEquals(emptyList<KeepRange>(), GamingHighlightPlanner.candidates(1_000, emptyList()))
    }
}
