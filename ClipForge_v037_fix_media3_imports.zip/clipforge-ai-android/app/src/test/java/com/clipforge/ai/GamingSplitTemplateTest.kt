package com.clipforge.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GamingSplitTemplateTest {
    @Test fun defaultsMatchReference() {
        val template = GamingSplitTemplate()
        assertEquals(40, template.facecamPercent)
        assertEquals(60, template.gameplayPercent)
        assertEquals(9, template.aspectWidth)
        assertEquals(16, template.aspectHeight)
        assertFalse(template.subtitlesEnabled)
        assertTrue(template.smartHighlightEnabled)
    }

    @Test fun overlapUsesShorterSource() {
        assertEquals(14_000L, GamingSplitTemplate.overlapDuration(60_000L, 14_000L))
        assertEquals(0L, GamingSplitTemplate.overlapDuration(60_000L, -1L))
    }

    @Test(expected = IllegalArgumentException::class)
    fun invalidSplitRejected() { GamingSplitTemplate(facecamPercent = 45, gameplayPercent = 60) }
}
