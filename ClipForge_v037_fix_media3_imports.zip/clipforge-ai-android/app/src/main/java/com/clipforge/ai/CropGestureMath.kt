package com.clipforge.ai

/** Pure math for drag/pinch in normalized source coordinates. No shared X/Y state. */
object CropGestureMath {
    fun update(crop: NormalizedCrop, panX: Float, panY: Float, zoom: Float, viewWidth: Float, viewHeight: Float, minSize: Float, maxSize: Float): NormalizedCrop {
        if (viewWidth <= 0f || viewHeight <= 0f || !zoom.isFinite() || zoom <= 0f) return crop
        val side = (crop.width / zoom).coerceIn(minSize, maxSize)
        val centerX = crop.left + crop.width / 2f - panX / viewWidth * crop.width
        val centerY = crop.top + crop.height / 2f - panY / viewHeight * crop.height
        return NormalizedCrop.centeredOn(centerX, centerY, side, side)
    }
}
