package com.clipforge.ai

/** Configuration contract for the Gaming Split editor. Rendering/export is a separate capability. */
data class GamingSplitTemplate(
    val facecamPercent: Int = 40,
    val gameplayPercent: Int = 60,
    val aspectWidth: Int = 9,
    val aspectHeight: Int = 16,
    val subtitlesEnabled: Boolean = false,
    val smartHighlightEnabled: Boolean = true
) {
    init {
        require(facecamPercent in 1..99 && gameplayPercent in 1..99)
        require(facecamPercent + gameplayPercent == 100)
        require(aspectWidth > 0 && aspectHeight > 0)
    }

    companion object {
        fun overlapDuration(gameplayDurationMs: Long, facecamDurationMs: Long): Long =
            minOf(gameplayDurationMs.coerceAtLeast(0L), facecamDurationMs.coerceAtLeast(0L))
    }
}
