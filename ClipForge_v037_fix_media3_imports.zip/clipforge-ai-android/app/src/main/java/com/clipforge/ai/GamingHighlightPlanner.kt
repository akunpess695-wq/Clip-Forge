package com.clipforge.ai

/** Heuristic review candidates: audible stretches between silence suggestions. Not semantic AI. */
object GamingHighlightPlanner {
    fun candidates(durationMs: Long, silence: List<SilenceSuggestion>, minLengthMs: Long = 2_000L): List<KeepRange> {
        if (durationMs <= 0L || minLengthMs <= 0L) return emptyList()
        val valid = silence.filter { it.startMs >= 0L && it.endMs > it.startMs && it.endMs <= durationMs }
            .sortedBy { it.startMs }
        var cursor = 0L
        val result = mutableListOf<KeepRange>()
        for (cut in valid) {
            if (cut.startMs > cursor && cut.startMs - cursor >= minLengthMs) result.add(KeepRange(cursor, cut.startMs))
            cursor = maxOf(cursor, cut.endMs)
        }
        if (durationMs - cursor >= minLengthMs) result.add(KeepRange(cursor, durationMs))
        return result.sortedByDescending { it.endMs - it.startMs }
    }
}
