package com.clipforge.ai

/** Normalized source-space crop. Pure Kotlin so bounds can be unit tested. */
data class NormalizedCrop(val left: Float, val top: Float, val width: Float, val height: Float) {
    init { require(left in 0f..1f && top in 0f..1f && width > 0f && height > 0f && left + width <= 1.0001f && top + height <= 1.0001f) }
    fun shifted(x: Float, y: Float): NormalizedCrop = copy(left = x.coerceIn(0f, 1f - width), top = y.coerceIn(0f, 1f - height))
    companion object {
        val DEFAULT_FACECAM = NormalizedCrop(0.68f, 0.02f, 0.30f, 0.30f)
        val DEFAULT_GAMEPLAY = NormalizedCrop(0f, 0f, 1f, 1f)
        fun centeredOn(x: Float, y: Float, width: Float, height: Float): NormalizedCrop =
            NormalizedCrop((x - width / 2).coerceIn(0f, 1f - width), (y - height / 2).coerceIn(0f, 1f - height), width, height)
    }
}
