# ClipForge AI Studio — Creator Pro v0.3.8

## Baseline
Source: `ClipForge_v037_fix_media3_imports.zip` (Claude patch). This revision changes Compose UI and version metadata only; no exporter implementation was modified.

## UI changes
- Dark charcoal / blue Creator Pro palette.
- Simplified header and 3-step language: Preview, Trim, Export.
- Gaming Split defaults to enabled; its full existing controls are behind an explicit `Gaming Split 40:60 · Atur layout` disclosure.
- Smart Auto Cut remains available in a separate optional disclosure.
- Existing preview, import, gesture crop, facecam auto detect, Smart Highlight, trim, export, and status logic retained.
- versionCode 9, versionName 0.3.8; applicationId unchanged.

## Verification evidence
- ZIP archive validated by Python `zipfile.testzip()`.
- Static checks for balanced delimiters, key existing code paths, dependency/version, and UI disclosure controls passed.
- Android Gradle compile: SKIPPED — Gradle/Android SDK not available in this environment.
- APK installation and video export on Android: SKIPPED — device unavailable.
- This source is a test candidate, NOT a verified successful APK build.

## Next verification
1. Upload project source to GitHub repository and run existing Actions workflow.
2. If compile fails, send the complete Actions log.
3. On device, import video, expand Gaming Split settings, adjust crop, export MP4, check playback/audio and gallery, and test Smart Auto Cut.
4. Confirm signing certificate remains stable before attempting in-place APK update.

## Known UI behavior
Gaming Split is enabled by default, while layout settings are collapsed initially. Open the layout settings to switch to standard editor or two-video mode. Smart Auto Cut is collapsed initially; existing autoCutExport state is preserved.
