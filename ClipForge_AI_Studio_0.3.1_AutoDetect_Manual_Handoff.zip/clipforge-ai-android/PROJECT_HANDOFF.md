# ClipForge AI Studio — PROJECT_HANDOFF.md

Date: 2026-11-05. Source prototype; NOT a verified Android APK.

## Product requirements
- Hybrid AI architecture; local features first, cloud optional with user consent.
- Gaming Split template: 9:16, upper facecam 40%, lower gameplay 60%.
- **Single-video mode** is now the default: detect probable facecam position from one imported video, allow manual crop correction. Legacy two-video mode remains available.
- Automatic subtitles OFF. Smart Highlight ON by default, but currently audio-activity heuristic only; it cannot detect kills or understand gameplay.
- Keep original media unchanged. Standard editor, silence analysis, Auto Cut, and manual export remain available outside Gaming Split.

## New implementation
- `app/src/main/java/com/clipforge/ai/SingleVideoCrop.kt`: normalized source-space crop with bounds validation, clamped movement, and defaults.
- `app/src/main/java/com/clipforge/ai/SingleVideoFacecamDetector.kt`: offline `MediaMetadataRetriever` samples a frame at ~one third duration; Android platform `FaceDetector` searches for faces; a heuristic suggests a square crop near a plausible small edge face. **This does not recognize webcam rectangle boundaries, identify a streamer, or reliably distinguish game characters from real faces.**
- `MainActivity.kt`: one-video/two-video switch, Auto Detect action running on background thread, fallback manual crop sliders (facecam X/Y/size; gameplay zoom/X), static split preview using a sampled frame. User can correct suggestions. Default 40:60 split and subtitle-off retained.
- `app/src/test/java/com/clipforge/ai/SingleVideoCropTest.kt`: JUnit cases for crop clamping and invalid bounds.

## Honest limitations
- **No live split preview for single-video mode**: only static sampled frame, shown after Auto Detect. The video playback elsewhere remains the original video.
- **No split MP4 export**: Gaming Split export remains disabled until an actual crop/compositing pipeline exists. Do not claim this feature works yet.
- Detection uses one representative frame, so misses moving facecam overlays or difficult lighting. Android's legacy `FaceDetector` is a simple offline baseline, not modern ML Kit. For production, evaluate ML Kit on-device face detection plus overlay boundary detection and multi-frame sampling.
- Gameplay crop is an independent user-adjustable rectangle, not a semantic detection of game HUD.
- Detection may fail for some codecs, rotations, or unsupported frames; manual adjustment remains available after a successful frame sample.
- Preview bitmap cropping is only for UI; source video is not modified.
- A/V sync and compositing for two-video mode are still unverified.

## Verification executed
- `kotlinc SingleVideoCrop.kt GamingSplitTemplate.kt GamingHighlightPlanner.kt SilenceSuggestionEngine.kt AutoCutPlanner.kt -d /tmp/clipforge_autodetect_pure.jar` — PASS.
- ZIP integrity and included paths — PASS during packaging.
- Android Gradle assemble / JUnit / device tests — NOT RUN (no Android SDK or Gradle available in environment).
- No cloud AI integration, no APK generated.

## Next milestone (highest priority)
1. Implement **real-time single-source split preview** by cropping the same decoded video into two surfaces with synchronized presentation timestamps, or via an OpenGL compositor.
2. Implement actual 9:16 MP4 export from a single source: render top 40% facecam crop and bottom 60% gameplay crop, preserve source rotation, choose a single audio stream, ensure timestamps, and write to MediaStore. Keep export disabled until verified.
3. Add visible draggable crop handles on a frame and multi-frame facecam detection; use a reliable modern on-device face model and check facecam boundary rather than only face location.
4. Run Gradle `testDebugUnitTest assembleDebug` with Android SDK, then test real phone videos (landscape/portrait, facecam each corner, no face, animated characters, rotations, long videos, low memory).
5. Update docs, run Anti-Slop UI review, keep privacy and honest AI labels.

## Development guidance
JRHagents, Superpowers, Caveman, Anti-Slop, Agency Agents are development workflows, not Android runtime libraries. Read AGENTS.md, DESIGN.md, docs/HYBRID_AI_PLAN.md, docs/GAMING_SPLIT.md before changing architecture. Keep mutations minimal and evidence-based.

## Ready-to-paste handoff prompt
Continue ClipForge from this ZIP. Read PROJECT_HANDOFF.md and inspect source. Complete and verify one-video Gaming Split 9:16 rendering/export with facecam 40%, gameplay 60%, automatic subtitles OFF, Smart Highlight ON (audio heuristic until genuine gameplay detection exists). Preserve Auto Detect + Manual Crop, existing editor, and original video. Run Android build and device tests where possible. Produce new ZIP and updated PROJECT_HANDOFF.md, explicitly reporting untested items.
