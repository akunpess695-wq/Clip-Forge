package com.clipforge.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.media.FaceDetector
import android.media.MediaMetadataRetriever
import android.net.Uri

/** Experimental offline face suggestion. FaceDetector detects faces, NOT webcam borders. */
object SingleVideoFacecamDetector {
    data class Result(val frame: Bitmap, val suggestedCrop: NormalizedCrop?, val note: String)

    fun inspect(context: Context, uri: Uri): Result {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val sampleUs = (durationMs / 3L).coerceAtLeast(0L) * 1000L
            val raw = retriever.getFrameAtTime(sampleUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: throw IllegalStateException("Frame video tidak dapat dibaca")
            val w = 480
            val h = (raw.height.toFloat() * w / raw.width).toInt().coerceAtLeast(2) and -2
            val scaled = Bitmap.createScaledBitmap(raw, w, h, true)
            val rgb565 = Bitmap.createBitmap(w, h, Bitmap.Config.RGB_565)
            Canvas(rgb565).drawBitmap(scaled, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG))
            val faces = Array(8) { FaceDetector.Face() }
            val count = FaceDetector(w, h, faces.size).findFaces(rgb565, faces)
            val candidates = (0 until count).mapNotNull { i ->
                val face = faces[i]
                if (face.confidence() < 0.4f) return@mapNotNull null
                val midpoint = android.graphics.PointF()
                face.getMidPoint(midpoint)
                val x = midpoint.x / w
                val y = midpoint.y / h
                val size = face.eyesDistance() / w
                Triple(x, y, size)
            }.filter { (x, y, size) -> size in 0.015f..0.20f && (x < 0.38f || x > 0.62f || y < 0.35f) }
            val candidate = candidates.minByOrNull { it.third }
            val crop = candidate?.let { (x, y, size) ->
                val side = (size * 5.5f).coerceIn(0.22f, 0.48f)
                NormalizedCrop.centeredOn(x, y, side, side)
            }
            return Result(scaled, crop, if (crop == null) "Wajah tidak terdeteksi dengan yakin. Atur crop manual." else "Perkiraan posisi wajah ditemukan; batas facecam perlu diperiksa manual.")
        } finally { retriever.release() }
    }

    fun cropBitmap(source: Bitmap, crop: NormalizedCrop): Bitmap {
        val x = (source.width * crop.left).toInt().coerceIn(0, source.width - 1)
        val y = (source.height * crop.top).toInt().coerceIn(0, source.height - 1)
        val width = (source.width * crop.width).toInt().coerceIn(1, source.width - x)
        val height = (source.height * crop.height).toInt().coerceIn(1, source.height - y)
        return Bitmap.createBitmap(source, x, y, width, height)
    }
}
