# ClipForge PROJECT_HANDOFF — v0.3.2 gesture patch

## Project
Android Kotlin + Jetpack Compose, minSdk 29, Media3 1.5.1. Latest source is in this ZIP under `clipforge-ai-android/`.

## User requirements
- Single imported video with facecam + gameplay, offline face position suggestion and manual crop.
- 9:16 output layout: facecam 40% top, gameplay 60% bottom.
- Subtitle auto OFF; Smart Highlight ON (currently audio heuristic, not game event AI).
- Drag to reposition facecam/gameplay and pinch to zoom.
- Save finished split video as MP4.

## Actual implementation
- `SingleVideoFacecamDetector.kt`: frame sampling and Android FaceDetector; only estimates face position, not facecam boundaries.
- `SingleVideoCrop.kt`: normalized source rectangles.
- `CropGestureMath.kt` **NEW**: pure crop pan/zoom math, independent X/Y, clamps bounds.
- `MainActivity.kt`: direct drag/pinch on the two static crop previews; existing sliders remain. Both crop areas are separate.
- `CropGestureMathTest.kt` **NEW**: horizontal-only, vertical-only, and pinch boundary tests.
- `MainActivity.kt`: standard clip export via Media3 exists when Gaming Split is OFF.

## IMPORTANT — unfinished functionality
- **Gaming Split MP4 export is NOT implemented**. Its button is intentionally disabled, rather than silently exporting a wrong video. This patch does not claim to fix video saving for Gaming Split.
- Static-frame preview is not live video playback; gestures update crop of sampled bitmap.
- No Android SDK/Gradle available in this execution environment; **full Android compilation and on-device testing NOT performed**.

## Verification performed
- Kotlin CLI compile of `SingleVideoCrop.kt` + `CropGestureMath.kt`: PASS.
- Kotlin CLI assertions for horizontal/vertical independent motion and zoom bounds: PASS.
- ZIP integrity check: PASS.
- JUnit source written, not executed via Gradle.

## Next engineering milestone (critical)
1. Implement reliable Android 9:16 video composition: decode the source video once, render two source crops into top 40% and bottom 60% output surfaces, encode H.264 MP4 with original audio synchronized. Research supported Media3 Transformer `VideoCompositorSettings` / `Effects` APIs for the pinned version, or use MediaCodec + EGL with proper audio muxing. **Do not pretend bitmap preview equals encoded video.**
2. Test on GitHub Actions with Android SDK, run `:app:testDebugUnitTest :app:assembleDebug` and verify installed APK on a device with source video and audio.
3. Add progress/cancel/error handling and MediaStore save with IS_PENDING transaction safety.
4. Add live video crop preview matching actual export, account for rotation and source aspect ratio.
5. Keep ZIP root stable (`clipforge-ai-android/`) and workflow source path aligned.

## Continuation prompt
Continue ClipForge from this source and handoff. Prioritize actual 9:16 Gaming Split MP4 export, preserving source audio and precise crops. Verify API compatibility with Media3 1.5.1, run Android CI, and never claim successful build without a real Gradle build. Update PROJECT_HANDOFF.md and package a tested ZIP.
