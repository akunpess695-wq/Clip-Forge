# PROJECT_HANDOFF — ClipForge v0.3.3

## Tujuan
Android Kotlin/Compose, Gaming Split satu video, auto face detect + crop gesture, facecam 40% / gameplay 60%, Smart Highlight audio, subtitle otomatis off.

## Kondisi aktual
- Gesture pinch/drag dilaporkan bekerja di perangkat pengguna pada v0.3.2.
- Export Gaming Split belum ada dan tombol sengaja disabled; jangan klaim sudah bisa simpan.
- Export standar (Gaming Split nonaktif) memakai Media3 Transformer, menyimpan ke `Movies/ClipForge AI`.
- Auto detect adalah estimasi posisi wajah dari frame, bukan deteksi batas webcam.

## Perubahan v0.3.3
- `app/build.gradle.kts`: `versionCode = 4`, `versionName = "0.3.3"`.
- UI menampilkan v0.3.3.
- Dokumentasi `docs/APK_UPDATE_AND_SIGNING.md` menjelaskan update APK tanpa uninstall, keystore yang stabil, dan verifikasi sertifikat.
- Tidak ada klaim fitur ekspor split sudah selesai.

## Prioritas teknis
1. Implementasikan kompositor video 9:16 dengan dua crop sumber yang sama, facecam atas 40%, gameplay bawah 60%, tanpa duplikasi audio; sinkronisasi timestamp, durasi, orientasi, dan hardware encoder.
2. Uji hasil pada beberapa video Android (portrait, landscape, fps berbeda, video tanpa audio).
3. Simpan hasil dengan MediaStore `IS_PENDING` dan penanganan error/cleanup yang aman.
4. Buat release signing stabil dengan GitHub secrets, tanpa commit kunci. Bandingkan fingerprint sertifikat APK terpasang dan baru sebelum menjanjikan update tanpa uninstall.
5. Build `:app:testDebugUnitTest :app:assembleDebug` di GitHub Actions; lakukan uji perangkat.

## Batas pengujian
Pemeriksaan paket dan versi dilakukan secara statis; build Android penuh tidak tersedia di lingkungan pembuat ZIP.
