# Gaming Split template

Facecam top 40%, gameplay bottom 60%, 9:16. Automatic subtitles off. Smart Highlight enabled as audio activity candidates, not event recognition. Two-player preview only; split-screen export is NOT implemented. See PROJECT_HANDOFF.md.
