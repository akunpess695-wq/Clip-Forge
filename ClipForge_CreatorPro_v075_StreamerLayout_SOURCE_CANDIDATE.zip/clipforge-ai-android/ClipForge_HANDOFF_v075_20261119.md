# ClipForge handoff v0.7.5 (draft) — 2026-11-19

Supersedes `ClipForge_HANDOFF_v074_20261119.md` (port #1 is carried over unchanged below).

## Changes
Source of both ports: ClipForge web by mallexibra, MIT. One shared notice file covers both: `app/src/main/assets/licenses/clipforge-web-MIT.txt` (from v0.7.4; keep it).

Port #1 (v0.7.4, unchanged): `TranscriptClipScorer.kt` + `TranscriptClipScorerTest.kt` — transcript-based clip scoring.

Port #2 (new): streamer layout.
- NEW `WebcamLayout.kt` (pure Kotlin): `CamCorner`, `FaceBox`, `WebcamCornerVote.vote`, `StreamerStackLayout.compute` -> `StreamerStack` (pixel rects + `NormalizedCrop` via `camCrop` / `gameCrop`).
- NEW `StreamerWebcamDetector.kt` (Android): samples 4 frames at 20/40/60/80% of the clip range with `FaceDetector`, feeds the vote. Returns `Result(corner?, videoWidth, videoHeight, facesFound)`; `cornerOrDefault` = BR like the original.
- NEW `WebcamLayoutTest.kt` — 18 tests.
- Existing files untouched (`SingleVideoFacecamDetector`, `NormalizedCrop`, `GamingSplitTemplate`, ...). Nothing wired into the UI.

## Evidence
- Layout golden values (8 source sizes / corners / panel heights) and vote golden values (tie order, zero area, centre line, weighting) come from running the ORIGINAL Python `streamer_stack_filter` and the original scoring loop. Python reference run: OK. Python rounds half-to-even; the Kotlin port uses `Math.rint` to match.

## Verified vs NOT verified
- VERIFIED: Python reference produces the expected values.
- NOT VERIFIED: Kotlin not compiled, tests not run (no Kotlin toolchain in the sandbox). Run `./gradlew testDebugUnitTest`.
- NOT VERIFIED on device: `StreamerWebcamDetector` (FaceDetector accuracy, frame extraction speed, rotation handling) has NO test coverage; needs a real phone and real gameplay videos.

## Deviations from the original
- OpenCV Haar cascade -> `android.media.FaceDetector`. Face box approximated as a square of 2x eye distance (original: real bounding box). Votes use unit coordinates (area scale is uniform, so the result is the same).
- No ffmpeg filter string; crop rectangles only (Media3 does the rendering).
- Panel heights are parameters. Original = 640/1280 (≈33/67). The app's `GamingSplitTemplate` default is 40/60, so pass `camPanelHeight = 768` for 1080x1920 output.
- Frames use `OPTION_CLOSEST_SYNC` (nearest keyframe), the original seeks by time.

## Limitations
- `FaceDetector` finds frontal human faces only: VTuber/avatar webcams, side views, small or dark facecams are missed -> null -> default BR -> user must adjust. It detects faces, not webcam borders; keep the manual crop UI.
- A big face in the middle of the game (a character) votes like a real webcam; the original has the same weakness.
- `detect` is blocking (4 frame decodes); call it off the main thread.
- Crop ratios are for 1080x1920 output only.

## Next steps
1. Upload the new source ZIP to the repo root, REPLACING the old one (the workflow fails unless exactly one `*.zip` is in the root). The Actions run `gradle testDebugUnitTest assembleDebug`, so a green run = compiled + all unit tests (including the 28 new ones) pass; a red run shows the compile/test error in the log.
2. Try `detect` on 3-5 real gaming videos (webcam in each corner, no webcam, avatar webcam); record hit rate in this file.
3. Wire into single-video mode: `StreamerStackLayout.compute(...)` -> `camCrop` / `gameCrop` as the initial crops, then manual adjust.
4. Port next: person-focus tracking (`detect_person_focus_x`, backlog item 4), or caption style / subtitle wrapping.
