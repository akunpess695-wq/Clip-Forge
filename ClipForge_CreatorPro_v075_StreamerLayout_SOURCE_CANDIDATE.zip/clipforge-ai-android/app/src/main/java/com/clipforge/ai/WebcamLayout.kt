package com.clipforge.ai

/*
 * Port of the streamer-layout logic from ClipForge (web) by mallexibra, MIT License.
 * Original: backend/clipper.py -> corner scoring loop of detect_webcam_corner,
 * clamp_even, streamer_stack_filter (crop geometry only).
 * License text: app/src/main/assets/licenses/clipforge-web-MIT.txt (must stay with this file).
 *
 * Deviations from the original:
 * - No ffmpeg filter string (this app renders with Media3). Only the crop rectangles are
 *   ported, as pixel rects plus NormalizedCrop for the existing crop UI.
 * - Panel heights are parameters (original: fixed 640 / 1280 of 1920).
 * - Pure Kotlin, no I/O, never touches source footage.
 */

/** Webcam corner. Declaration order (BR, BL, TR, TL) is the tie-break order of the original. */
enum class CamCorner(val code: String, val isLeft: Boolean, val isTop: Boolean) {
    BR("br", false, false),
    BL("bl", true, false),
    TR("tr", false, true),
    TL("tl", true, true),
}

/** A detected face; centre and size in any consistent unit (pixels, or 0..1 of the frame). */
data class FaceBox(val centerX: Double, val centerY: Double, val width: Double, val height: Double)

object WebcamCornerVote {
    /**
     * Each face votes for the quadrant its centre falls in, weighted by its area.
     * Returns null when nothing has positive weight. Ties go to the first of BR, BL, TR, TL.
     * A centre exactly on the middle line counts as top / left (same as the original).
     */
    fun vote(faces: List<FaceBox>, frameWidth: Double, frameHeight: Double): CamCorner? {
        require(frameWidth > 0.0 && frameHeight > 0.0)
        val all = CamCorner.values()
        val scores = DoubleArray(all.size)
        for (f in faces) {
            val top = f.centerY <= frameHeight / 2
            val left = f.centerX <= frameWidth / 2
            val corner = all.first { it.isTop == top && it.isLeft == left }
            scores[corner.ordinal] += f.width * f.height
        }
        var best = CamCorner.BR
        for (c in all) if (scores[c.ordinal] > scores[best.ordinal]) best = c
        return if (scores[best.ordinal] <= 0.0) null else best
    }
}

data class PixelRect(val x: Int, val y: Int, val width: Int, val height: Int) {
    fun toNormalized(sourceWidth: Int, sourceHeight: Int): NormalizedCrop = NormalizedCrop(
        x.toFloat() / sourceWidth, y.toFloat() / sourceHeight,
        width.toFloat() / sourceWidth, height.toFloat() / sourceHeight,
    )
}

/** Two crop regions of the source: the webcam (top panel) and the gameplay (bottom panel). */
data class StreamerStack(
    val corner: CamCorner,
    val sourceWidth: Int,
    val sourceHeight: Int,
    val cam: PixelRect,
    val game: PixelRect,
) {
    val camCrop: NormalizedCrop get() = cam.toNormalized(sourceWidth, sourceHeight)
    val gameCrop: NormalizedCrop get() = game.toNormalized(sourceWidth, sourceHeight)
}

object StreamerStackLayout {
    const val DEFAULT_OUTPUT_WIDTH = 1080
    const val DEFAULT_OUTPUT_HEIGHT = 1920
    /** Original split: 640 of 1920 for the webcam (~1/3). Pass 768 for the app's 40/60 split. */
    const val DEFAULT_CAM_PANEL_HEIGHT = 640

    private const val MIN_SIDE = 16
    private const val CAM_MAX_WIDTH_FRACTION = 0.32
    private const val CAM_MAX_HEIGHT_FRACTION = 0.5

    fun compute(
        sourceWidth: Int,
        sourceHeight: Int,
        corner: CamCorner,
        camPanelHeight: Int = DEFAULT_CAM_PANEL_HEIGHT,
        outputWidth: Int = DEFAULT_OUTPUT_WIDTH,
        outputHeight: Int = DEFAULT_OUTPUT_HEIGHT,
    ): StreamerStack {
        require(sourceWidth >= MIN_SIDE && sourceHeight >= MIN_SIDE)
        require(outputWidth > 0 && outputHeight > 0 && camPanelHeight in 1 until outputHeight)
        val gamePanelHeight = outputHeight - camPanelHeight
        val camAspect = outputWidth.toDouble() / camPanelHeight
        val gameAspect = outputWidth.toDouble() / gamePanelHeight

        // Webcam box: up to ~1/3 of the width, never more than half the height, panel aspect.
        var camW = minOf(sourceWidth * CAM_MAX_WIDTH_FRACTION, sourceHeight * CAM_MAX_HEIGHT_FRACTION * camAspect)
        var camH = camW / camAspect
        if (camH > sourceHeight * CAM_MAX_HEIGHT_FRACTION) {
            camH = sourceHeight * CAM_MAX_HEIGHT_FRACTION
            camW = camH * camAspect
        }
        val cw = clampEven(camW, MIN_SIDE, sourceWidth)
        val ch = clampEven(camH, MIN_SIDE, sourceHeight)
        val cx = if (corner.isLeft) 0 else sourceWidth - cw
        val cy = if (corner.isTop) 0 else sourceHeight - ch

        // Gameplay box: centred, bottom-panel aspect.
        var gameH = sourceHeight.toDouble()
        var gameW = gameH * gameAspect
        if (gameW > sourceWidth) {
            gameW = sourceWidth.toDouble()
            gameH = gameW / gameAspect
        }
        val gw = clampEven(gameW, MIN_SIDE, sourceWidth)
        val gh = clampEven(gameH, MIN_SIDE, sourceHeight)
        val gx = clampEven((sourceWidth - gw) / 2.0, 0, sourceWidth - gw)
        val gy = clampEven((sourceHeight - gh) / 2.0, 0, sourceHeight - gh)

        return StreamerStack(corner, sourceWidth, sourceHeight, PixelRect(cx, cy, cw, ch), PixelRect(gx, gy, gw, gh))
    }

    /** Round half-to-even (like Python's round), clamp, then force an even number. */
    private fun clampEven(value: Double, min: Int, max: Int): Int {
        var bounded = maxOf(min, minOf(max, Math.rint(value).toInt()))
        if (bounded % 2 != 0) bounded -= 1
        return maxOf(min, minOf(max, bounded))
    }
}
