package com.clipforge.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PointF
import android.media.FaceDetector
import android.media.MediaMetadataRetriever
import android.net.Uri

/*
 * Android counterpart of detect_webcam_corner from ClipForge (web) by mallexibra, MIT License
 * (see assets/licenses/clipforge-web-MIT.txt). The original samples 4 frames of the clip and
 * runs an OpenCV Haar cascade; here the same sampling uses android.media.FaceDetector, and the
 * voting is the pure, unit-tested WebcamCornerVote.
 *
 * UNVERIFIED on device. Limits: FaceDetector finds frontal, human faces only (avatars, VTuber
 * models, side views are missed) and approximates the face box as a square of 2x eye distance.
 * When nothing is found, `corner` is null and callers should fall back to cornerOrDefault (BR)
 * and let the user adjust manually. Detects faces, not webcam borders.
 */
object StreamerWebcamDetector {
    data class Result(val corner: CamCorner?, val videoWidth: Int, val videoHeight: Int, val facesFound: Int) {
        /** The original falls back to bottom-right when no webcam is detected. */
        val cornerOrDefault: CamCorner get() = corner ?: CamCorner.BR
    }

    private val sampleFractions = doubleArrayOf(0.2, 0.4, 0.6, 0.8)
    private const val ANALYSIS_WIDTH = 480
    private const val MAX_FACES = 8
    private const val MIN_CONFIDENCE = 0.4f
    private const val FACE_SIDE_PER_EYE_DISTANCE = 2.0

    /** Blocking: call from a background dispatcher. Reads frames only; never modifies the video. */
    fun detect(context: Context, uri: Uri, startMs: Long, endMs: Long): Result {
        require(startMs >= 0L && endMs > startMs)
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            val rawW = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull()
            val rawH = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull()
            if (rawW == null || rawH == null || rawW <= 0 || rawH <= 0) {
                throw IllegalStateException("Ukuran video tidak dapat dibaca")
            }
            val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            val swap = rotation == 90 || rotation == 270
            val videoW = if (swap) rawH else rawW
            val videoH = if (swap) rawW else rawH

            val clipMs = maxOf(100L, endMs - startMs)
            val boxes = mutableListOf<FaceBox>()
            for (fraction in sampleFractions) {
                val timeUs = (startMs + (clipMs * fraction).toLong()) * 1000L
                val raw = retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: continue
                try {
                    boxes += faceBoxes(raw)
                } finally {
                    raw.recycle()
                }
            }
            // Boxes are in unit coordinates (0..1 of the frame), so the frame is 1.0 x 1.0.
            return Result(WebcamCornerVote.vote(boxes, 1.0, 1.0), videoW, videoH, boxes.size)
        } finally {
            retriever.release()
        }
    }

    private fun faceBoxes(raw: Bitmap): List<FaceBox> {
        val w = ANALYSIS_WIDTH
        val h = (raw.height.toFloat() * w / raw.width).toInt().coerceAtLeast(2) and -2
        val scaled = Bitmap.createScaledBitmap(raw, w, h, true)
        val rgb565 = Bitmap.createBitmap(w, h, Bitmap.Config.RGB_565)
        try {
            Canvas(rgb565).drawBitmap(scaled, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG))
            val faces = arrayOfNulls<FaceDetector.Face>(MAX_FACES)
            val count = FaceDetector(w, h, MAX_FACES).findFaces(rgb565, faces)
            return (0 until count).mapNotNull { i ->
                val face = faces[i] ?: return@mapNotNull null
                if (face.confidence() < MIN_CONFIDENCE) return@mapNotNull null
                val mid = PointF()
                face.getMidPoint(mid)
                val side = face.eyesDistance() * FACE_SIDE_PER_EYE_DISTANCE
                if (side <= 0.0) return@mapNotNull null
                FaceBox(mid.x / w.toDouble(), mid.y / h.toDouble(), side / w.toDouble(), side / h.toDouble())
            }
        } finally {
            if (scaled !== raw) scaled.recycle()
            rgb565.recycle()
        }
    }
}
