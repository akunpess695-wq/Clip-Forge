package com.clipforge.ai

import kotlin.math.abs

/*
 * Port of the clip-scoring logic from ClipForge (web) by mallexibra, MIT License.
 * Original: backend/clipper.py -> score_window, build_candidate_pool,
 * select_candidates, first_sentence.
 * License text: app/src/main/assets/licenses/clipforge-web-MIT.txt (must stay with this file).
 *
 * Deviations from the original:
 * - Times are Long milliseconds (original: Double seconds).
 * - buildCandidatePool can clamp the padded range to the video length (optional).
 * - Pure Kotlin, no I/O: it only ranks suggestions and never touches source footage.
 */

data class TranscriptSegment(val startMs: Long, val endMs: Long, val text: String)

data class ClipCandidate(
    val index: Int,
    val startMs: Long,
    val endMs: Long,
    val durationMs: Long,
    val score: Int,
    val title: String,
    val reason: String,
    val text: String,
)

data class WindowScore(val score: Int, val reasons: List<String>)

object TranscriptClipScorer {
    private val hookWords = setOf(
        "intinya", "ternyata", "masalahnya", "kenapa", "gimana", "bagaimana", "cara",
        "jangan", "harus", "penting", "rahasia", "bedanya", "salah", "benar", "tips",
        "trik", "jadi", "kalau", "misalnya",
    )
    private val weakStarts = setOf("dan", "terus", "lalu", "nah", "jadi", "itu", "ini", "em", "eh", "ya")
    private val wordRegex = Regex("[\\p{L}\\p{N}_']+")
    private val whitespace = Regex("\\s+")

    private const val PAD_BEFORE_MS = 350L
    private const val PAD_AFTER_MS = 250L
    private const val TARGET_DURATION_S = 85.0
    private const val DIVERSITY_GAP_MS = 18_000L

    fun scoreWindow(items: List<TranscriptSegment>, durationSeconds: Double): WindowScore {
        val text = items.joinToString(" ") { it.text }
        val words = wordRegex.findAll(text.lowercase()).map { it.value }.toList()
        val firstWord = words.firstOrNull().orEmpty()
        val hookHits = hookWords.intersect(words.toSet()).sorted()

        var score = 35
        val reasons = mutableListOf<String>()

        if (durationSeconds in 45.0..120.0) {
            score += 18; reasons += "durasi pas"
        } else if (durationSeconds in 35.0..180.0) {
            score += 12; reasons += "durasi masih oke"
        }

        if (hookHits.isNotEmpty()) {
            score += minOf(24, hookHits.size * 6)
            reasons += "ada keyword hook: " + hookHits.take(4).joinToString(", ")
        }

        val wordCount = words.size
        val density = wordCount / maxOf(durationSeconds, 1.0)
        if (density >= 1.8) {
            score += 12; reasons += "speech padat"
        } else if (density >= 1.1) {
            score += 6; reasons += "speech cukup padat"
        }

        val trimmed = text.trimEnd()
        if (trimmed.isNotEmpty() && trimmed.last() in ".!?") {
            score += 5; reasons += "ending terasa selesai"
        }
        if (firstWord in weakStarts) {
            score -= 10; reasons += "awal agak menggantung"
        }
        if (wordCount < 55) {
            score -= 12; reasons += "terlalu sedikit konteks"
        }
        return WindowScore(score.coerceIn(1, 100), reasons)
    }

    fun firstSentence(text: String, maxWords: Int = 8): String {
        val cleaned = text.replace(whitespace, " ").trim(' ', '.', ',', '!', '?', ':', ';', '-')
        val joined = cleaned.split(' ').filter { it.isNotEmpty() }.take(maxWords).joinToString(" ")
        if (joined.isEmpty()) return "Auto clip"
        return joined.lowercase().replaceFirstChar { it.uppercase() }
    }

    /** Every contiguous run of segments whose length falls in [minDurationMs, maxDurationMs]. */
    fun buildCandidatePool(
        segments: List<TranscriptSegment>,
        minDurationMs: Long = 45_000L,
        maxDurationMs: Long = 120_000L,
        videoDurationMs: Long? = null,
    ): List<ClipCandidate> {
        require(minDurationMs > 0 && maxDurationMs >= minDurationMs)
        val pool = mutableListOf<ClipCandidate>()
        for (startIdx in segments.indices) {
            val first = segments[startIdx]
            for (endIdx in startIdx until segments.size) {
                val last = segments[endIdx]
                val durationMs = last.endMs - first.startMs
                if (durationMs < minDurationMs) continue
                if (durationMs > maxDurationMs) break
                val window = segments.subList(startIdx, endIdx + 1)
                val text = window.joinToString(" ") { it.text }
                val scored = scoreWindow(window, durationMs / 1000.0)
                val start = maxOf(0L, first.startMs - PAD_BEFORE_MS)
                val rawEnd = last.endMs + PAD_AFTER_MS
                val end = if (videoDurationMs != null) minOf(rawEnd, videoDurationMs) else rawEnd
                pool += ClipCandidate(
                    index = 0,
                    startMs = start,
                    endMs = end,
                    durationMs = durationMs,
                    score = scored.score,
                    title = firstSentence(text),
                    reason = scored.reasons.joinToString(", ").ifEmpty { "segmen stabil" },
                    text = text,
                )
            }
        }
        return pool
    }

    private fun base(c: ClipCandidate): Double =
        c.score - abs(c.durationMs / 1000.0 - TARGET_DURATION_S) * 0.04

    /** Greedy pick: best adjusted score, no overlap, small bonus for varied lengths. Returned in time order. */
    fun selectCandidates(candidates: List<ClipCandidate>, limit: Int): List<ClipCandidate> {
        if (limit <= 0) return emptyList()
        val remaining = candidates.sortedByDescending { base(it) }.toMutableList()
        val picked = mutableListOf<ClipCandidate>()
        while (remaining.isNotEmpty() && picked.size < limit) {
            var best: ClipCandidate? = null
            var bestAdjusted = -1_000.0
            for (c in remaining) {
                val overlaps = picked.any { !(c.endMs < it.startMs || c.startMs > it.endMs) }
                if (overlaps) continue
                val gap = picked.minOfOrNull { abs(c.durationMs - it.durationMs) } ?: Long.MAX_VALUE
                val adjusted = base(c) + if (gap > DIVERSITY_GAP_MS) 8 else 0
                if (adjusted > bestAdjusted) {
                    best = c
                    bestAdjusted = adjusted
                }
            }
            val chosen = best ?: break
            picked += chosen
            remaining.removeAt(remaining.indexOfFirst { it === chosen })
        }
        return picked.sortedBy { it.startMs }.mapIndexed { i, c -> c.copy(index = i + 1) }
    }
}
