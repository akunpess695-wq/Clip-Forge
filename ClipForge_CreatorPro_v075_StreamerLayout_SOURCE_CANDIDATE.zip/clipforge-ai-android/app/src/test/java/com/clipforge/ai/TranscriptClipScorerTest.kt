package com.clipforge.ai

import org.junit.Assert.*
import org.junit.Test

/**
 * Golden values were produced by running the ORIGINAL Python functions
 * (clipper.py score_window / build_candidate_pool / select_candidates) on the same input.
 */
class TranscriptClipScorerTest {
    private val sentences = listOf(
        "Jadi kenapa banyak orang gagal mengatur uang padahal gajinya sudah besar sekali.",
        "Ternyata masalahnya bukan di penghasilan tapi di cara kita memakai uang setiap hari.",
        "Nah kalau kamu mau mulai, caranya sederhana dan tidak butuh banyak waktu sama sekali.",
        "Misalnya kamu catat semua pengeluaran kecil seperti kopi dan jajan selama satu bulan penuh.",
        "Rahasia utamanya adalah konsisten, jangan menyerah di minggu kedua karena itu paling berat.",
        "Itu saja dulu.",
    )
    private val segs = List(24) { i ->
        TranscriptSegment(i * 10_000L, (i + 1) * 10_000L, sentences[i % sentences.size])
    }

    @Test fun scoreWindowMatchesReference60s() {
        val r = TranscriptClipScorer.scoreWindow(segs.subList(0, 6), 60.0)
        assertEquals(78, r.score)
        assertEquals(
            listOf("durasi pas", "ada keyword hook: cara, jadi, jangan, kalau", "speech cukup padat",
                "ending terasa selesai", "awal agak menggantung"),
            r.reasons,
        )
    }

    @Test fun scoreWindowPenalisesWeakStartAndLittleContext() {
        val r = TranscriptClipScorer.scoreWindow(
            listOf(TranscriptSegment(0, 40_000, "nah ini cuma sedikit kata saja")), 40.0)
        assertEquals(25, r.score)
        assertEquals(listOf("durasi masih oke", "awal agak menggantung", "terlalu sedikit konteks"), r.reasons)
    }

    @Test fun scoreWindowMatchesReferenceDense40s() {
        val r = TranscriptClipScorer.scoreWindow(segs.subList(1, 5), 40.0)
        assertEquals(70, r.score)
        assertEquals("ada keyword hook: cara, jangan, kalau, masalahnya", r.reasons[1])
    }

    @Test fun firstSentenceMatchesReference() {
        assertEquals("Jadi kenapa banyak orang gagal mengatur uang padahal",
            TranscriptClipScorer.firstSentence("  jadi KENAPA banyak orang gagal mengatur uang padahal gajinya besar.  "))
        assertEquals("Auto clip", TranscriptClipScorer.firstSentence("  ... !! "))
    }

    @Test fun poolSizeMatchesReference() =
        assertEquals(132, TranscriptClipScorer.buildCandidatePool(segs).size)

    @Test fun selectionMatchesReference() {
        val picked = TranscriptClipScorer.selectCandidates(TranscriptClipScorer.buildCandidatePool(segs), 3)
        assertEquals(2, picked.size)
        with(picked[0]) {
            assertEquals(1, index); assertEquals(9_650L, startMs); assertEquals(90_250L, endMs)
            assertEquals(80_000L, durationMs); assertEquals(88, score)
            assertEquals("Ternyata masalahnya bukan di penghasilan tapi di cara", title)
        }
        with(picked[1]) {
            assertEquals(2, index); assertEquals(99_650L, startMs); assertEquals(200_250L, endMs)
            assertEquals(100_000L, durationMs); assertEquals(88, score)
            assertEquals("Rahasia utamanya adalah konsisten, jangan menyerah di minggu", title)
        }
    }

    @Test fun selectedClipsNeverOverlapAndAreTimeOrdered() {
        val picked = TranscriptClipScorer.selectCandidates(TranscriptClipScorer.buildCandidatePool(segs), 5)
        picked.zipWithNext().forEach { (a, b) -> assertTrue(a.endMs < b.startMs) }
        assertEquals((1..picked.size).toList(), picked.map { it.index })
    }

    @Test fun emptyInputsAndZeroLimitGiveNothing() {
        assertTrue(TranscriptClipScorer.buildCandidatePool(emptyList()).isEmpty())
        assertTrue(TranscriptClipScorer.selectCandidates(TranscriptClipScorer.buildCandidatePool(segs), 0).isEmpty())
    }

    @Test fun paddedRangeIsClampedToVideoLength() {
        val pool = TranscriptClipScorer.buildCandidatePool(segs, videoDurationMs = 240_000L)
        assertTrue(pool.all { it.startMs >= 0 && it.endMs <= 240_000L })
    }

    @Test(expected = IllegalArgumentException::class) fun invalidRangeRejected() {
        TranscriptClipScorer.buildCandidatePool(segs, minDurationMs = 90_000, maxDurationMs = 45_000)
    }
}
