package com.clipforge.ai

import org.junit.Assert.*
import org.junit.Test

/**
 * Golden values come from the ORIGINAL Python (clipper.py streamer_stack_filter, and the
 * scoring loop of detect_webcam_corner) run on the same input.
 */
class WebcamLayoutTest {
    // Faces are given as top-left x, y and size, like OpenCV boxes.
    private fun box(x: Int, y: Int, w: Int, h: Int) = FaceBox(x + w / 2.0, y + h / 2.0, w.toDouble(), h.toDouble())
    private fun vote(vararg b: FaceBox) = WebcamCornerVote.vote(b.toList(), 1920.0, 1080.0)

    @Test fun biggestFaceDecidesCorner() = assertEquals(CamCorner.BR, vote(box(1700, 900, 200, 200), box(200, 100, 50, 50)))
    @Test fun noFacesGivesNull() = assertNull(vote())
    @Test fun zeroAreaGivesNull() = assertNull(vote(box(1700, 900, 0, 0)))
    @Test fun tieGoesToFirstInOriginalOrder() {
        assertEquals(CamCorner.BL, vote(box(100, 800, 100, 100), box(1700, 100, 100, 100)))
        assertEquals(CamCorner.BR, vote(box(1700, 900, 100, 100), box(100, 900, 100, 100),
            box(1700, 100, 100, 100), box(100, 100, 100, 100)))
    }
    @Test fun centreOnMiddleLineCountsAsTopAndRightOfLeft() = assertEquals(CamCorner.TR, vote(box(940, 490, 100, 100)))
    @Test fun oneBigFaceBeatsSeveralSmall() =
        assertEquals(CamCorner.TL, vote(box(100, 100, 300, 300), box(1700, 900, 100, 100), box(1650, 950, 100, 100), box(1750, 950, 100, 100)))
    @Test fun unitCoordinatesVoteTheSame() =
        assertEquals(CamCorner.BR, WebcamCornerVote.vote(listOf(FaceBox(0.9, 0.9, 0.1, 0.18)), 1.0, 1.0))

    private fun assertLayout(sw: Int, sh: Int, c: CamCorner, camPanel: Int, cam: PixelRect, game: PixelRect) {
        val s = StreamerStackLayout.compute(sw, sh, c, camPanelHeight = camPanel)
        assertEquals("cam $sw x $sh $c", cam, s.cam)
        assertEquals("game $sw x $sh $c", game, s.game)
    }

    // PixelRect(x, y, width, height)
    @Test fun layout1920x1080BottomRight() = assertLayout(1920, 1080, CamCorner.BR, 640, PixelRect(1306, 716, 614, 364), PixelRect(504, 0, 910, 1080))
    @Test fun layout1920x1080TopLeft() = assertLayout(1920, 1080, CamCorner.TL, 640, PixelRect(0, 0, 614, 364), PixelRect(504, 0, 910, 1080))
    @Test fun layout1280x720TopRight() = assertLayout(1280, 720, CamCorner.TR, 640, PixelRect(870, 0, 410, 242), PixelRect(336, 0, 608, 720))
    @Test fun layout2560x1440BottomLeft() = assertLayout(2560, 1440, CamCorner.BL, 640, PixelRect(0, 956, 818, 484), PixelRect(672, 0, 1214, 1440))
    @Test fun layoutPortraitSource() = assertLayout(1080, 1920, CamCorner.BR, 640, PixelRect(734, 1716, 346, 204), PixelRect(0, 320, 1080, 1280))
    @Test fun layoutWithFortyPercentCamPanel() = assertLayout(1920, 1080, CamCorner.BR, 768, PixelRect(1306, 644, 614, 436), PixelRect(454, 0, 1012, 1080))
    @Test fun layoutOddSourceSize1000x563() = assertLayout(1000, 563, CamCorner.TL, 640, PixelRect(0, 0, 320, 190), PixelRect(262, 0, 474, 562))
    @Test fun layoutOddSourceSize1366x768() = assertLayout(1366, 768, CamCorner.BL, 640, PixelRect(0, 510, 436, 258), PixelRect(358, 0, 648, 768))

    @Test fun everyLayoutIsEvenInsideSourceAndConvertsToValidCrops() {
        val sizes = listOf(1920 to 1080, 1280 to 720, 2560 to 1440, 1080 to 1920, 1000 to 563, 1366 to 768, 640 to 360)
        for ((sw, sh) in sizes) for (c in CamCorner.values()) for (panel in listOf(640, 768)) {
            val s = StreamerStackLayout.compute(sw, sh, c, camPanelHeight = panel)
            for (r in listOf(s.cam, s.game)) {
                assertTrue(r.width % 2 == 0 && r.height % 2 == 0)
                assertTrue(r.x >= 0 && r.y >= 0 && r.x + r.width <= sw && r.y + r.height <= sh)
            }
            assertEquals(c.isLeft, s.cam.x == 0)
            assertEquals(c.isTop, s.cam.y == 0)
            s.camCrop; s.gameCrop // NormalizedCrop's init validates bounds; must not throw
        }
    }

    @Test(expected = IllegalArgumentException::class) fun tinySourceRejected() { StreamerStackLayout.compute(8, 8, CamCorner.BR) }
    @Test(expected = IllegalArgumentException::class) fun badPanelHeightRejected() { StreamerStackLayout.compute(1920, 1080, CamCorner.BR, camPanelHeight = 1920) }
}
