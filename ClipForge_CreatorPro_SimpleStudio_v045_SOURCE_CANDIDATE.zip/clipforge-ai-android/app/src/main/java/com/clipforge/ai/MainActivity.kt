package com.clipforge.ai

import android.content.ContentValues
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File
import java.io.FileInputStream
import java.util.Locale
import android.os.Handler
import android.os.Looper
import kotlin.concurrent.thread

private val Night = Color(0xFF090E19)
private val Panel = Color(0xFF141E30)
private val Panel2 = Color(0xFF1B2A41)
private val Blue = Color(0xFF398BFF)
private val Violet = Color(0xFF58B8FF)
private val Muted = Color(0xFF9BAAC7)
private val White = Color(0xFFF4F7FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8, 13, 27)
        window.navigationBarColor = android.graphics.Color.rgb(8, 13, 27)
        setContent { ClipForgeApp() }
    }
}

@Composable
private fun ClipForgeApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var videoName by remember { mutableStateOf("Belum ada video") }
    var durationMs by remember { mutableLongStateOf(0L) }
    var startMs by remember { mutableLongStateOf(0L) }
    var endMs by remember { mutableLongStateOf(0L) }
    var status by remember { mutableStateOf("Pilih video untuk mulai membuat klip.") }
    var exporting by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf(false) }
    var analyzing by remember { mutableStateOf(false) }
    var suggestions by remember { mutableStateOf<List<SilenceSuggestion>>(emptyList()) }
    var selectedSuggestion by remember { mutableIntStateOf(-1) }
    var approvedCuts by remember { mutableStateOf<Set<Int>>(emptySet()) }
    var autoCutExport by remember { mutableStateOf(false) }
    var analysisGeneration by remember { mutableIntStateOf(0) }
    var gamingSplitEnabled by remember { mutableStateOf(true) }
    var showLayoutSettings by remember { mutableStateOf(false) }
    var showSmartCut by remember { mutableStateOf(false) }
    var showAdvancedCrop by remember { mutableStateOf(false) }
    var editorPanel by remember { mutableStateOf("edit") }
    var singleVideoMode by remember { mutableStateOf(true) }
    var layoutTemplate by remember { mutableStateOf(LayoutTemplate.FACE_TOP_40) }
    var platformPreset by remember { mutableStateOf(PlatformPreset.TIKTOK) }
    var detectingFacecam by remember { mutableStateOf(false) }
    var detectionNote by remember { mutableStateOf("Pilih video, lalu jalankan Auto Detect.") }
    var detectionFrame by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    var facecamCrop by remember { mutableStateOf(NormalizedCrop.DEFAULT_FACECAM) }
    var facecamPreviewSize by remember { mutableStateOf(IntSize.Zero) }
    var gameplayPreviewSize by remember { mutableStateOf(IntSize.Zero) }
    var gameplayCrop by remember { mutableStateOf(NormalizedCrop.DEFAULT_GAMEPLAY) }
    var facecamUri by remember { mutableStateOf<Uri?>(null) }
    var facecamName by remember { mutableStateOf("Belum ada facecam") }
    var facecamDurationMs by remember { mutableLongStateOf(0L) }
    var smartHighlightEnabled by remember { mutableStateOf(true) }
    // Subtitles are intentionally off until an actual transcription pipeline exists.
    val subtitlesEnabled = false

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            analysisGeneration++
            suggestions = emptyList()
            selectedSuggestion = -1
            approvedCuts = emptySet()
            autoCutExport = false
            analyzing = false
            videoUri = uri
            editorPanel = "edit"
            detectionFrame = null
            detectionNote = "Video baru dipilih. Jalankan Auto Detect untuk saran facecam."
            try {
                val retriever = MediaMetadataRetriever()
                retriever.setDataSource(context, uri)
                durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                retriever.release()
                startMs = 0L
                endMs = durationMs
                videoName = uri.lastPathSegment?.substringAfterLast('/')?.take(32) ?: "Video dipilih"
                status = "Video siap diedit. Atur rentang klip, lalu export."
            } catch (_: Exception) {
                durationMs = 0L
                endMs = 0L
                status = "Video dipilih, tetapi durasinya tidak dapat dibaca."
            }
        }
    }

    val facecamPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            facecamUri = uri
            facecamName = uri.lastPathSegment?.substringAfterLast('/')?.take(32) ?: "Facecam dipilih"
            facecamDurationMs = runCatching {
                MediaMetadataRetriever().use { retriever ->
                    retriever.setDataSource(context, uri)
                    retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                }
            }.getOrDefault(0L)
            status = "Facecam siap. Periksa sinkronisasi dengan gameplay sebelum ekspor."
        }
    }

    val facecamPlayer = remember(facecamUri, gamingSplitEnabled) {
        if (gamingSplitEnabled) facecamUri?.let { uri ->
            ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(uri)); prepare(); volume = 0f
            }
        } else null
    }
    DisposableEffect(facecamPlayer) { onDispose { facecamPlayer?.release() } }

    val player = remember(videoUri) {
        videoUri?.let {
            ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(it))
                prepare()
                playWhenReady = false
                addListener(object : Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
                })
            }
        }
    }
    DisposableEffect(player) { onDispose { player?.release() } }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Blue, secondary = Violet, background = Night,
            surface = Panel, onPrimary = Color.White, onBackground = White,
            onSurface = White
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Night) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).background(
                    Brush.verticalGradient(listOf(Color(0xFF101A2B), Night, Color(0xFF101A2B)))
                ).padding(horizontal = 18.dp)
            ) {
                Spacer(Modifier.height(12.dp))
                if (videoUri == null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(painterResource(R.drawable.ic_clipforge_logo), contentDescription = "ClipForge", modifier = Modifier.size(48.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("ClipForge", color = White, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                            Text("CREATOR PRO  ·  v0.4.5", color = Muted, fontSize = 11.sp)
                        }
                    }
                    Spacer(Modifier.height(40.dp))
                    Text("Mulai berkarya.", color = White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(7.dp))
                    Text("Edit video jadi lebih mudah.", color = Muted, fontSize = 14.sp)
                    Spacer(Modifier.height(28.dp))
                    Button(
                        onClick = { picker.launch("video/*") },
                        modifier = Modifier.fillMaxWidth().height(100.dp),
                        shape = RoundedCornerShape(22.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Blue)
                    ) {
                        Icon(Icons.Default.Add, null, modifier = Modifier.size(32.dp))
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text("Proyek Baru", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Text("Pilih video dari galeri", fontSize = 12.sp)
                        }
                    }
                    Spacer(Modifier.height(30.dp))
                    Text("Mulai dengan", color = White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        StudioQuickCard("Gaming Split", "Facecam + gameplay", Modifier.weight(1f)) {
                            gamingSplitEnabled = true
                            picker.launch("video/*")
                        }
                        StudioQuickCard("Video Biasa", "Potong & edit", Modifier.weight(1f)) {
                            gamingSplitEnabled = false
                            picker.launch("video/*")
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("Smart Auto Cut tersedia setelah video dipilih.", color = Muted, fontSize = 12.sp)
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { player?.pause(); facecamPlayer?.pause(); videoUri = null }) {
                            Text("‹  Beranda", color = White, fontSize = 14.sp)
                        }
                        Spacer(Modifier.weight(1f))
                        Text("Editor", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        Text(platformPreset.format.label, color = Blue, fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(12.dp))
                StudioCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.VideoLibrary, null, tint = Blue)
                        Spacer(Modifier.width(9.dp))
                        Text("01  VIDEO", color = White, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Spacer(Modifier.weight(1f))
                        Text(if (videoUri == null) "NO MEDIA" else "MEDIA READY", color = if (videoUri == null) Muted else Color(0xFF71E0BF), fontSize = 10.sp)
                    }
                    Spacer(Modifier.height(14.dp))
                    Box(
                        Modifier.fillMaxWidth().height(205.dp).clip(RoundedCornerShape(18.dp))
                            .background(Color(0xFF070C18)).border(1.dp, Color(0xFF263657), RoundedCornerShape(18.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (player != null) {
                            AndroidView(
                                modifier = Modifier.fillMaxSize(),
                                factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } },
                                update = { it.player = player }
                            )
                        } else {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    Modifier.size(62.dp).clip(CircleShape)
                                        .background(Brush.linearGradient(listOf(Color(0xFF203D70), Color(0xFF38265F)))),
                                    contentAlignment = Alignment.Center
                                ) { Icon(Icons.Default.PlayArrow, null, tint = White, modifier = Modifier.size(34.dp)) }
                                Spacer(Modifier.height(12.dp))
                                Text("Mulai proyek video", color = White, fontWeight = FontWeight.SemiBold)
                                Text("MP4 • MOV • M4V", color = Muted, fontSize = 11.sp)
                            }
                        }
                    }
                    if (gamingSplitEnabled && videoUri != null) {
                        Spacer(Modifier.height(8.dp))
                        Text("Preview video sumber · lihat komposisi split di Atur layout", color = Muted, fontSize = 11.sp)
                    }
                    Spacer(Modifier.height(13.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(videoName, color = White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(if (durationMs > 0) "${formatTime(durationMs)} total duration" else "Belum ada media", color = Muted, fontSize = 10.sp)
                        }
                        Button(
                            onClick = { picker.launch("video/*") },
                            colors = ButtonDefaults.buttonColors(containerColor = Blue),
                            shape = RoundedCornerShape(13.dp),
                            contentPadding = PaddingValues(horizontal = 15.dp, vertical = 11.dp)
                        ) {
                            Icon(Icons.Default.FolderOpen, null, modifier = Modifier.size(17.dp))
                            Spacer(Modifier.width(7.dp))
                            Text("Import video", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf("edit" to "Potong", "layout" to "Layout", "auto" to "Auto Cut").forEach { (key, label) ->
                        if (editorPanel == key) Button(
                            onClick = { editorPanel = key; showLayoutSettings = key == "layout"; showSmartCut = key == "auto" },
                            modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) { Text(label, fontSize = 12.sp) }
                        else OutlinedButton(
                            onClick = { editorPanel = key; showLayoutSettings = key == "layout"; showSmartCut = key == "auto" },
                            modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) { Text(label, fontSize = 12.sp) }
                    }
                }
                Spacer(Modifier.height(14.dp))
                if (editorPanel == "layout") {
                StudioCard {
                    Text("MODE EDIT", color = White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (gamingSplitEnabled) {
                            Button(onClick = { gamingSplitEnabled = true }, modifier = Modifier.weight(1f)) { Text("Gaming Split", fontSize = 12.sp) }
                            OutlinedButton(onClick = { gamingSplitEnabled = false }, modifier = Modifier.weight(1f)) { Text("Video Biasa", fontSize = 12.sp) }
                        } else {
                            OutlinedButton(onClick = { gamingSplitEnabled = true }, modifier = Modifier.weight(1f)) { Text("Gaming Split", fontSize = 12.sp) }
                            Button(onClick = { gamingSplitEnabled = false }, modifier = Modifier.weight(1f)) { Text("Video Biasa", fontSize = 12.sp) }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                OutlinedButton(
                    onClick = { showLayoutSettings = !showLayoutSettings },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(15.dp)
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null)
                    Spacer(Modifier.width(9.dp))
                    Text(if (showLayoutSettings) "Tutup pengaturan layout" else "Atur layout · ${layoutTemplate.label}", fontSize = 12.sp)
                }
                if (showLayoutSettings) StudioCard {
                    Text("Atur tampilan video", color = White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Spacer(Modifier.height(5.dp))
                    Text("Gaming Split · ${layoutTemplate.label} · ${platformPreset.format.label}", color = Muted, fontSize = 12.sp)
                    if (gamingSplitEnabled) {
                        Text("Format konten", color = White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            PlatformPreset.values().forEach { preset ->
                                val label = "${preset.label} · ${preset.format.label}"
                                if (preset == platformPreset) Button(onClick = { platformPreset = preset }) { Text(label, fontSize = 11.sp) }
                                else OutlinedButton(onClick = { platformPreset = preset }) { Text(label, fontSize = 11.sp) }
                            }
                        }
                        Text("Output ${platformPreset.format.sizeLabel} px. Berlaku untuk export Gaming Split.", color = Muted, fontSize = 10.sp)
                        Spacer(Modifier.height(6.dp))
                        Text("Pilih komposisi", color = White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        LayoutTemplate.values().forEach { option ->
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).padding(vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(selected = layoutTemplate == option, onClick = { layoutTemplate = option })
                                LayoutThumb(option, platformPreset.format, Modifier.width(44.dp).aspectRatio(platformPreset.format.width.toFloat() / platformPreset.format.height))
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(option.label, color = White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    Text(option.description, color = Muted, fontSize = 10.sp)
                                }
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Switch(checked = singleVideoMode, onCheckedChange = { singleVideoMode = it })
                            Spacer(Modifier.width(8.dp))
                            Text(if (singleVideoMode) "Satu video · Auto Detect + Manual" else "Dua video terpisah", color = White, fontSize = 12.sp)
                        }
                        if (singleVideoMode) {
                            OutlinedButton(onClick = {
                                val selected = videoUri ?: return@OutlinedButton
                                detectingFacecam = true
                                detectionNote = "Menganalisis frame secara lokal..."
                                thread {
                                    val result = runCatching { SingleVideoFacecamDetector.inspect(context, selected) }
                                    Handler(Looper.getMainLooper()).post {
                                        detectingFacecam = false
                                        result.onSuccess {
                                            detectionFrame = it.frame
                                            it.suggestedCrop?.let { crop -> facecamCrop = crop }
                                            detectionNote = it.note
                                        }.onFailure { detectionNote = "Analisis gagal: ${it.message ?: "format video tidak didukung"}. Gunakan crop manual." }
                                    }
                                }
                            }, enabled = videoUri != null && !detectingFacecam, modifier = Modifier.fillMaxWidth()) {
                                Text(if (detectingFacecam) "Mendeteksi..." else "Auto Detect Facecam (offline)")
                            }
                            Text(detectionNote, color = Muted, fontSize = 11.sp)
                            val frame = detectionFrame
                            if (frame != null) {
                                Text("Pratinjau crop · geser untuk memindahkan, cubit untuk zoom", color = Muted, fontSize = 12.sp)
                                Column(Modifier.width(216.dp).aspectRatio(9f / 16f).align(Alignment.CenterHorizontally).background(Color.Black)) {
                                    Image(bitmap = remember(frame, facecamCrop) { SingleVideoFacecamDetector.cropBitmap(frame, facecamCrop).asImageBitmap() }, contentDescription = "Preview crop facecam", modifier = Modifier.fillMaxWidth().weight(0.4f)
                                        .onSizeChanged { facecamPreviewSize = it }
                                        .pointerInput(Unit) {
                                            detectTransformGestures { _, pan, zoom, _ ->
                                                facecamCrop = CropGestureMath.update(facecamCrop, pan.x, pan.y, zoom,
                                                    facecamPreviewSize.width.toFloat(), facecamPreviewSize.height.toFloat(), 0.15f, 0.65f)
                                            }
                                        }, contentScale = ContentScale.Crop)
                                    Image(bitmap = remember(frame, gameplayCrop) { SingleVideoFacecamDetector.cropBitmap(frame, gameplayCrop).asImageBitmap() }, contentDescription = "Preview crop gameplay", modifier = Modifier.fillMaxWidth().weight(0.6f)
                                        .onSizeChanged { gameplayPreviewSize = it }
                                        .pointerInput(Unit) {
                                            detectTransformGestures { _, pan, zoom, _ ->
                                                gameplayCrop = CropGestureMath.update(gameplayCrop, pan.x, pan.y, zoom,
                                                    gameplayPreviewSize.width.toFloat(), gameplayPreviewSize.height.toFloat(), 0.5f, 1f)
                                            }
                                        }, contentScale = ContentScale.Crop)
                                }
                            }
                            Spacer(Modifier.height(12.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("Penyetelan presisi", color = White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    Text("Opsional · posisi dan zoom manual", color = Muted, fontSize = 11.sp)
                                }
                                Switch(checked = showAdvancedCrop, onCheckedChange = { showAdvancedCrop = it })
                            }
                            if (showAdvancedCrop) {
                            Text("Manual crop facecam · geser area", color = White, fontSize = 11.sp)
                            Text("Horizontal: ${(facecamCrop.left * 100).toInt()}%", color = Muted, fontSize = 10.sp)
                            Slider(value = facecamCrop.left, onValueChange = { facecamCrop = facecamCrop.shifted(it, facecamCrop.top) }, valueRange = 0f..(1f - facecamCrop.width))
                            Text("Vertikal: ${(facecamCrop.top * 100).toInt()}%", color = Muted, fontSize = 10.sp)
                            Slider(value = facecamCrop.top, onValueChange = { facecamCrop = facecamCrop.shifted(facecamCrop.left, it) }, valueRange = 0f..(1f - facecamCrop.height))
                            Text("Ukuran area: ${(facecamCrop.width * 100).toInt()}%", color = Muted, fontSize = 10.sp)
                            Slider(value = facecamCrop.width, onValueChange = {
                                val side = it.coerceIn(0.15f, 0.65f)
                                facecamCrop = NormalizedCrop(facecamCrop.left.coerceAtMost(1f - side), facecamCrop.top.coerceAtMost(1f - side), side, side)
                            }, valueRange = 0.15f..0.65f)
                            Text("Crop gameplay · horizontal ${(gameplayCrop.left * 100).toInt()}%", color = Muted, fontSize = 10.sp)
                            Slider(value = gameplayCrop.left, onValueChange = { gameplayCrop = gameplayCrop.shifted(it, gameplayCrop.top) }, valueRange = 0f..(1f - gameplayCrop.width))
                            Text("Crop gameplay · zoom ${(100f / gameplayCrop.width).toInt()}%", color = Muted, fontSize = 10.sp)
                            Slider(value = gameplayCrop.width, onValueChange = {
                                val size = it.coerceIn(0.5f, 1f)
                                gameplayCrop = NormalizedCrop(gameplayCrop.left.coerceAtMost(1f - size), gameplayCrop.top.coerceAtMost(1f - size), size, size)
                            }, valueRange = 0.5f..1f)
                            }
                            Text("Hasil akhir bisa diperiksa setelah ekspor ke galeri.", color = Muted, fontSize = 11.sp)
                        } else {
                        OutlinedButton(onClick = { facecamPicker.launch("video/*") }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.FolderOpen, null, modifier = Modifier.size(17.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Pilih video facecam")
                        }
                        Text(facecamName, color = Muted, fontSize = 11.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("PREVIEW LAYOUT · 9:16", color = White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        Box(Modifier.width(216.dp).aspectRatio(9f / 16f).align(Alignment.CenterHorizontally)
                            .clip(RoundedCornerShape(14.dp)).background(Color.Black)) {
                            Column(Modifier.fillMaxSize()) {
                                Box(Modifier.fillMaxWidth().weight(0.4f).background(Color(0xFF24344E)), contentAlignment = Alignment.Center) {
                                    if (facecamPlayer != null) AndroidView(
                                        modifier = Modifier.fillMaxSize(),
                                        factory = { ctx -> PlayerView(ctx).apply { useController = false; this.player = facecamPlayer } },
                                        update = { it.player = facecamPlayer }
                                    ) else Text("FACE CAM · 40%", color = White, fontSize = 12.sp)
                                }
                                Box(Modifier.fillMaxWidth().weight(0.6f).background(Color(0xFF122B37)), contentAlignment = Alignment.Center) {
                                    if (player != null) AndroidView(
                                        modifier = Modifier.fillMaxSize(),
                                        factory = { ctx -> PlayerView(ctx).apply { useController = false; this.player = player } },
                                        update = { it.player = player }
                                    ) else Text("GAMEPLAY · 60%", color = White, fontSize = 12.sp)
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = {
                            val target = if (player?.isPlaying == true) false else true
                            if (target) {
                                facecamPlayer?.seekTo(player?.currentPosition ?: 0L)
                                player?.play(); facecamPlayer?.play()
                            } else { player?.pause(); facecamPlayer?.pause() }
                        }, enabled = videoUri != null && facecamUri != null, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.PlayArrow, null)
                            Spacer(Modifier.width(6.dp))
                            Text("Play / Pause kedua video")
                        }
                        } // end two-video mode
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = smartHighlightEnabled, onCheckedChange = { smartHighlightEnabled = it })
                            Text("Smart Highlight (kandidat berbasis audio)", color = White, fontSize = 11.sp)
                        }
                        Text("Subtitle otomatis: NONAKTIF", color = Muted, fontSize = 11.sp)
                        if (!singleVideoMode) {
                            val overlap = GamingSplitTemplate.overlapDuration(durationMs, facecamDurationMs)
                            Text("Durasi bersama: ${formatTime(overlap)} · Sinkronisasi dimulai dari 00:00", color = Muted, fontSize = 11.sp)
                            Text("Ekspor dua video memakai Media3; pastikan kedua video sinkron dari awal.", color = Color(0xFFFFC47C), fontSize = 11.sp)
                        }
                    }
                }

                } // end layout panel
                if (editorPanel == "edit") {
                Spacer(Modifier.height(16.dp))
                StudioCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Potong & Export", color = White, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Text("Atur awal dan akhir klip", color = Muted, fontSize = 11.sp)
                        }
                        Surface(color = Color(0xFF1A3157), shape = CircleShape) {
                            Text("MANUAL", Modifier.padding(horizontal = 13.dp, vertical = 7.dp), color = Blue, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.height(13.dp))
                    if (durationMs > 0L) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("START  ${formatTime(startMs)}", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            Text("END  ${formatTime(endMs)}", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Slider(
                            value = startMs.toFloat(),
                            onValueChange = { startMs = it.toLong().coerceIn(0L, (endMs - 1000L).coerceAtLeast(0L)) },
                            valueRange = 0f..durationMs.toFloat(),
                            colors = SliderDefaults.colors(thumbColor = Blue, activeTrackColor = Blue, inactiveTrackColor = Panel2)
                        )
                        Slider(
                            value = endMs.toFloat(),
                            onValueChange = { endMs = it.toLong().coerceIn((startMs + 1000L).coerceAtMost(durationMs), durationMs) },
                            valueRange = 0f..durationMs.toFloat(),
                            colors = SliderDefaults.colors(thumbColor = Violet, activeTrackColor = Violet, inactiveTrackColor = Panel2)
                        )
                        Text("Durasi klip: ${formatTime((endMs - startMs).coerceAtLeast(0L))}", color = White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    } else {
                        Text("Import video untuk mengaktifkan kontrol pemotongan.", color = Muted, fontSize = 13.sp)
                    }
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val source = videoUri ?: return@Button
                            if (gamingSplitEnabled) {
                                if (!singleVideoMode && (facecamUri == null || facecamDurationMs < endMs)) {
                                    status = "Pilih facecam dengan durasi cukup untuk rentang ekspor."
                                    return@Button
                                }
                            }
                            if (ClipRangeValidator.validate(startMs, endMs, durationMs) == null) {
                                status = "Rentang klip tidak valid. Pilih durasi minimal 1 detik."
                                return@Button
                            }
                            exporting = true
                            status = "Menyiapkan export MP4…"
                            val output = File(context.cacheDir, "clipforge_${System.currentTimeMillis()}.mp4")
                            val keepRanges = if (!gamingSplitEnabled && autoCutExport && approvedCuts.isNotEmpty()) {
                                runCatching { AutoCutPlanner.plan(durationMs, suggestions, approvedCuts) }.getOrElse {
                                    exporting = false
                                    status = "Rencana potongan tidak valid: ${it.localizedMessage}"
                                    return@Button
                                }
                            } else emptyList()
                            if (!gamingSplitEnabled && autoCutExport && approvedCuts.isNotEmpty() && keepRanges.isEmpty()) {
                                exporting = false
                                status = "Tidak ada bagian video yang dapat diekspor. Batalkan beberapa potongan."
                                return@Button
                            }
                            val clippedItem = MediaItem.Builder()
                                .setUri(source)
                                .setClippingConfiguration(
                                    MediaItem.ClippingConfiguration.Builder()
                                        .setStartPositionMs(startMs)
                                        .setEndPositionMs(endMs)
                                        .build()
                                ).build()
                            val transformer = Transformer.Builder(context).addListener(object : Transformer.Listener {
                                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                                    try {
                                        val values = ContentValues().apply {
                                            put(MediaStore.Video.Media.DISPLAY_NAME, "ClipForge_${System.currentTimeMillis()}.mp4")
                                            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                                            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ClipForge AI")
                                            put(MediaStore.Video.Media.IS_PENDING, 1)
                                        }
                                        val dest = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                                            ?: error("Tidak dapat membuat file output.")
                                        try {
                                            context.contentResolver.openOutputStream(dest)?.use { out ->
                                                FileInputStream(output).use { input -> input.copyTo(out) }
                                            } ?: error("Tidak dapat membuka output.")
                                            context.contentResolver.update(dest, ContentValues().apply {
                                                put(MediaStore.Video.Media.IS_PENDING, 0)
                                            }, null, null)
                                        } catch (saveError: Exception) {
                                            context.contentResolver.delete(dest, null, null)
                                            throw saveError
                                        } finally {
                                            output.delete()
                                        }
                                        exporting = false
                                        status = "Export selesai. Video tersimpan di Movies/ClipForge AI."
                                    } catch (e: Exception) {
                                        exporting = false
                                        status = "Gagal menyimpan hasil: ${e.localizedMessage}"
                                    }
                                }
                                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                                    exporting = false
                                    status = "Export gagal: ${exportException.localizedMessage ?: "Kesalahan media"}"
                                    output.delete()
                                }
                            }).build()
                            try {
                                if (gamingSplitEnabled) {
                                    val composition = GamingSplitExporter.composition(
                                        source, facecamUri ?: source, singleVideoMode, layoutTemplate, platformPreset.format,
                                        facecamCrop, gameplayCrop, startMs, endMs
                                    )
                                    transformer.start(composition, output.absolutePath)
                                } else if (autoCutExport && approvedCuts.isNotEmpty()) {
                                    val items = keepRanges.map { range ->
                                        val item = MediaItem.Builder().setUri(source).setClippingConfiguration(
                                            MediaItem.ClippingConfiguration.Builder()
                                                .setStartPositionMs(range.startMs)
                                                .setEndPositionMs(range.endMs)
                                                .build()
                                        ).build()
                                        EditedMediaItem.Builder(item).build()
                                    }
                                    val sequence = EditedMediaItemSequence(items)
                                    transformer.start(Composition.Builder(sequence).build(), output.absolutePath)
                                } else transformer.start(clippedItem, output.absolutePath)
                            } catch (e: Exception) {
                                exporting = false
                                status = "Tidak dapat memulai export: ${e.localizedMessage}"
                                output.delete()
                            }
                        },
                        enabled = videoUri != null && !exporting && (!gamingSplitEnabled || singleVideoMode || facecamUri != null),
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = RoundedCornerShape(15.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Blue,
                            disabledContainerColor = Color(0xFF29344A),
                            contentColor = Color.White,
                            disabledContentColor = Muted
                        )
                    ) {
                        if (exporting) CircularProgressIndicator(Modifier.size(19.dp), color = White, strokeWidth = 2.dp)
                        else Icon(Icons.Default.SaveAlt, null)
                        Spacer(Modifier.width(9.dp))
                        Text(if (exporting) "Mengekspor…" else "Export Video", fontWeight = FontWeight.Bold)
                    }
                }

                } // end edit panel
                if (editorPanel == "auto") {
                Spacer(Modifier.height(15.dp))
                OutlinedButton(
                    onClick = { showSmartCut = !showSmartCut },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(15.dp)
                ) {
                    Icon(Icons.Default.ContentCut, contentDescription = null)
                    Spacer(Modifier.width(9.dp))
                    Text(if (showSmartCut) "Tutup Smart Auto Cut" else "Smart Auto Cut  ·  Opsional")
                }
                if (showSmartCut) StudioCard {
                    Text("SMART AUTO CUT", color = White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("Deteksi bagian hening secara offline. Periksa setiap saran sebelum memotong.", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val source = videoUri ?: return@Button
                            val generation = ++analysisGeneration
                            analyzing = true
                            suggestions = emptyList()
                            selectedSuggestion = -1
                            approvedCuts = emptySet()
                            autoCutExport = false
                            status = "Menganalisis audio video di perangkat…"
                            thread(name = "clipforge-silence-analysis") {
                                val result = runCatching { VideoSilenceAnalyzer.analyze(context.applicationContext, source) }
                                Handler(Looper.getMainLooper()).post {
                                    if (generation == analysisGeneration) {
                                        analyzing = false
                                        result.onSuccess {
                                            suggestions = it
                                            status = if (it.isEmpty()) "Tidak ditemukan keheningan panjang." else "${it.size} saran keheningan ditemukan. Pilih untuk meninjau."
                                        }.onFailure { status = "Analisis gagal: ${it.localizedMessage ?: "Audio tidak didukung"}" }
                                    }
                                }
                            }
                        },
                        enabled = videoUri != null && !analyzing && !exporting,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (analyzing) CircularProgressIndicator(Modifier.size(17.dp), strokeWidth = 2.dp)
                        else Icon(Icons.Default.AutoAwesome, null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (analyzing) "Analyzing…" else "Analyze Silence")
                    }
                    if (gamingSplitEnabled && smartHighlightEnabled) {
                        Text("Smart Highlight: kandidat bagian bersuara di antara keheningan (bukan deteksi kill/gameplay).", color = Muted, fontSize = 11.sp)
                        val highlights = GamingHighlightPlanner.candidates(durationMs, suggestions)
                        highlights.take(5).forEachIndexed { index, range ->
                            OutlinedButton(onClick = {
                                player?.seekTo(range.startMs)
                                facecamPlayer?.seekTo(range.startMs)
                                status = "Kandidat highlight ${index + 1} siap ditinjau."
                            }, modifier = Modifier.fillMaxWidth()) {
                                Text("Highlight ${index + 1}: ${formatTime(range.startMs)} – ${formatTime(range.endMs)}")
                            }
                        }
                    }
                    if (suggestions.isNotEmpty()) {
                        Text("Centang hanya bagian hening yang ingin dihapus. Preview tetap dapat ditinjau sebelum export.", color = Muted, fontSize = 11.sp)
                    }
                    suggestions.forEachIndexed { index, suggestion ->
                        val chosen = selectedSuggestion == index
                        Spacer(Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = index in approvedCuts,
                                onCheckedChange = { checked ->
                                    approvedCuts = if (checked) approvedCuts + index else approvedCuts - index
                                    autoCutExport = false
                                }
                            )
                            OutlinedButton(
                            onClick = {
                                selectedSuggestion = index
                                player?.seekTo(suggestion.startMs)
                                status = "Hening ${formatTime(suggestion.startMs)}–${formatTime(suggestion.endMs)}. Ini hanya rekomendasi; video asli aman."
                            }, modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("${if (chosen) "▶ " else ""}Hening ${formatTime(suggestion.startMs)} – ${formatTime(suggestion.endMs)}")
                            }
                        }
                    }
                    if (approvedCuts.isNotEmpty()) {
                        val planned = runCatching { AutoCutPlanner.plan(durationMs, suggestions, approvedCuts) }.getOrDefault(emptyList())
                        Text("${approvedCuts.size} bagian disetujui untuk dihapus · ${planned.size} segmen dipertahankan", color = White, fontSize = 12.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = autoCutExport, onCheckedChange = { autoCutExport = it && planned.isNotEmpty() }, enabled = planned.isNotEmpty())
                            Text("Gunakan Smart Auto Cut saat export", color = White, fontSize = 12.sp)
                        }
                        if (autoCutExport) Text("Tombol Export clip as MP4 di atas akan menggabungkan segmen yang dipertahankan. Rentang manual diabaikan dalam mode ini.", color = Muted, fontSize = 11.sp)
                    }
                    if (selectedSuggestion in suggestions.indices) {
                        Text("Saran terpilih untuk preview. Centang bagian yang ingin dihapus.", color = Muted, fontSize = 11.sp)
                    }
                }

                } // end auto cut panel
                Spacer(Modifier.height(15.dp))
                StudioCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AutoAwesome, null, tint = Violet)
                        Spacer(Modifier.width(8.dp))
                        Text("STATUS", color = White, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(status, color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
                }
                Spacer(Modifier.height(20.dp))
                } // end editor
            }
        }
    }
}

@Composable
private fun StudioQuickCard(title: String, description: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(onClick = onClick, modifier = modifier.height(112.dp), color = Panel, shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.Center) {
            Text(title, color = White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(Modifier.height(7.dp))
            Text(description, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun StudioCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(23.dp))
            .background(Brush.linearGradient(listOf(Panel, Color(0xFF111A2A))))
            .border(1.dp, Color(0xFF243453), RoundedCornerShape(23.dp))
            .padding(17.dp),
        content = content
    )
}

private fun formatTime(ms: Long): String {
    val total = (ms / 1000L).coerceAtLeast(0L)
    return String.format(Locale.US, "%02d:%02d", total / 60L, total % 60L)
}


/** Small schematic of a layout: shows where facecam and gameplay go. */
@Composable
fun LayoutThumb(template: LayoutTemplate, format: OutputFormat, modifier: Modifier = Modifier) {
    BoxWithConstraints(modifier.clip(RoundedCornerShape(4.dp)).background(Color.Black)) {
        template.layers(format).forEach { l ->
            val face = l.source == LayerSource.FACECAM
            Box(
                Modifier
                    .offset(x = maxWidth * (l.x.toFloat() / format.width), y = maxHeight * (l.y.toFloat() / format.height))
                    .size(maxWidth * (l.width.toFloat() / format.width), maxHeight * (l.height.toFloat() / format.height))
                    .background(if (face) Color(0xFF3B6FD4) else Color(0xFF1E8F6A))
                    .border(0.5.dp, Color.Black)
            )
        }
    }
}
