# ClipForge AI Roadmap

## MVP 0.1.0 — Android manual clipping
- [x] Android project scaffold
- [x] Compose dark UI
- [x] Local video picker
- [x] Media3 preview
- [x] Start/end range controls
- [x] Media3 Transformer export pipeline
- [x] MediaStore save destination
- [x] Pure Kotlin range validator tests
- [ ] Android Studio Gradle build verification
- [ ] Physical-device codec/export tests

## MVP 0.2.0 — Editing usability
- [ ] Thumbnail timeline
- [ ] Numeric time input
- [ ] Scrub-to-selection controls
- [ ] Export cancellation and progress polling
- [ ] Multiple clips from one source
- [ ] Persist project metadata

## 0.3.0 — YouTube timestamp workflow
- [ ] URL validation
- [ ] Official embedded player workflow
- [ ] Timestamp bookmarks and share links
- [ ] Explicit separation between timestamping and file export

## 0.4.0 — AI features
- [ ] Speech-to-text
- [ ] Transcript segments with timestamps
- [ ] Highlight suggestions
- [ ] User review and manual adjustment
- [ ] Subtitle editor

## Later
- [ ] Web app
- [ ] Shared API/backend
- [ ] Cloud job queue and storage
- [ ] Subject-aware reframing
- [ ] Accounts, sync, and optional paid tiers
