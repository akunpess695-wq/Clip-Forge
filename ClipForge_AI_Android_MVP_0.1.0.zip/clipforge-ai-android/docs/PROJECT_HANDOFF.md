# ClipForge AI — Development Handoff

Current state: Android native MVP scaffold 0.1.0 generated.

## User decisions
- Fresh project (no existing source repository).
- Android is the first priority.
- Long-term product still targets Android + website.
- Both local video and YouTube URL workflows are desired.
- Both manual clipping and AI-assisted clipping are desired.

## Implemented in source scaffold
- Kotlin Android app using Jetpack Compose.
- Local video selection.
- Media3 ExoPlayer preview.
- Manual start/end sliders.
- Media3 Transformer MP4 export.
- Save output to Movies/ClipForge AI via MediaStore.
- Pure Kotlin clip-range validation and JUnit tests.

## Not yet verified
No Gradle build or APK has been produced in this generation environment. Open the project in Android Studio, sync Gradle, build, and test on a physical Android device. Resolve any API/version compilation issues before adding features.

## Next actions
1. Run Gradle sync and `testDebugUnitTest`.
2. Fix any compile/API issues.
3. Build and install debug APK.
4. Test export with multiple source codecs and durations.
5. Add export cancellation/progress polling.
6. Add thumbnail timeline and precise numeric time entry.
7. Only then begin YouTube timestamp integration and AI transcription/highlight work.

## Safety/legal constraint
Do not implement arbitrary YouTube downloading or DRM/access-control bypass. Use official embedded playback and timestamp links. Export only files the user owns or is authorized to download and process.
