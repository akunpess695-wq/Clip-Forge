# MVP Test Plan

## Static / unit checks
- [x] Clip range accepts a valid range.
- [x] Negative start rejected.
- [x] Zero duration rejected.
- [x] End before start rejected.
- [x] End beyond source duration rejected.

## Android Studio / device checks (not yet executed)
- [ ] Gradle sync succeeds.
- [ ] App launches on API 29+.
- [ ] OpenDocument picker returns a video URI.
- [ ] Selected video preview plays and seeks.
- [ ] Duration appears after Media3 reaches STATE_READY.
- [ ] Start/end sliders cannot create an invalid range.
- [ ] Export produces an MP4 file.
- [ ] Exported file appears in Movies/ClipForge AI.
- [ ] Exported video plays with audio/video sync.
- [ ] Test H.264/AAC MP4, HEVC MP4, and at least one large/long video.
- [ ] Unsupported/corrupt input shows a useful error.
- [ ] Repeated export does not leak temporary files.
