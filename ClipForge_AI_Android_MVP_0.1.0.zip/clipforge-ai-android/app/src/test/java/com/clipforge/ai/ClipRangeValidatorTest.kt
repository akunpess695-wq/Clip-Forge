package com.clipforge.ai

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ClipRangeValidatorTest {
    @Test fun acceptsValidRange() {
        assertTrue(ClipRangeValidator.isValid(1_000, 5_000, 10_000))
    }

    @Test fun rejectsNegativeStart() {
        assertFalse(ClipRangeValidator.isValid(-1, 5_000, 10_000))
    }

    @Test fun rejectsZeroOrNegativeDuration() {
        assertFalse(ClipRangeValidator.isValid(0, 0, 0))
    }

    @Test fun rejectsEndBeforeStart() {
        assertFalse(ClipRangeValidator.isValid(5_000, 4_000, 10_000))
    }

    @Test fun rejectsEndBeyondSourceDuration() {
        assertFalse(ClipRangeValidator.isValid(1_000, 10_001, 10_000))
    }
}
