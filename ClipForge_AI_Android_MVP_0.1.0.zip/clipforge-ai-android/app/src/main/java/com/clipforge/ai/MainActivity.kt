package com.clipforge.ai

import android.content.ContentValues
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Locale

private val Ink = Color(0xFF0B1020)
private val Panel = Color(0xFF151D31)
private val Accent = Color(0xFF58A6FF)
private val Muted = Color(0xFF9AA8C2)

@OptIn(UnstableApi::class)
class MainActivity : ComponentActivity() {
    private var activeTransformer: Transformer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(11, 16, 32)
        window.navigationBarColor = android.graphics.Color.rgb(11, 16, 32)
        setContent {
            ClipForgeTheme {
                ClipForgeScreen(
                    onExport = { uri, startMs, endMs, onStatus, onDone ->
                        exportClip(uri, startMs, endMs, onStatus, onDone)
                    }
                )
            }
        }
    }

    private fun exportClip(
        source: Uri,
        startMs: Long,
        endMs: Long,
        onStatus: (String) -> Unit,
        onDone: (Uri?) -> Unit
    ) {
        // The UI validates against the complete source duration before calling.
        // Keep a defensive check here so an invalid range never reaches Transformer.
        if (startMs < 0L || endMs <= startMs) {
            onStatus("Rentang klip tidak valid.")
            onDone(null)
            return
        }

        val outputFile = File(cacheDir, "clipforge_${System.currentTimeMillis()}.mp4")
        onStatus("Menyiapkan export…")

        try {
            val clipping = MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(startMs)
                .setEndPositionMs(endMs)
                .build()
            val mediaItem = MediaItem.Builder()
                .setUri(source)
                .setClippingConfiguration(clipping)
                .build()
            val editedMediaItem = EditedMediaItem.Builder(mediaItem).build()

            val transformer = Transformer.Builder(this)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: ExportResult) {
                        onStatus("Menyimpan hasil ke galeri…")
                        lifecycleScope.launch {
                            val saved = withContext(Dispatchers.IO) { copyToMovies(outputFile) }
                            outputFile.delete()
                            onStatus(if (saved != null) "Selesai! Video tersimpan di Movies/ClipForge AI." else "Export selesai, tetapi penyimpanan ke galeri gagal.")
                            onDone(saved)
                            activeTransformer = null
                        }
                    }

                    override fun onError(
                        composition: androidx.media3.transformer.Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        outputFile.delete()
                        onStatus("Export gagal: ${exportException.message ?: "format video tidak didukung"}")
                        onDone(null)
                        activeTransformer = null
                    }
                })
                .build()
            activeTransformer = transformer
            transformer.start(editedMediaItem, outputFile.absolutePath)
        } catch (error: Exception) {
            outputFile.delete()
            onStatus("Tidak dapat memulai export: ${error.message ?: "kesalahan tidak diketahui"}")
            onDone(null)
        }
    }

    private fun copyToMovies(source: File): Uri? {
        if (!source.exists() || source.length() == 0L) return null
        val name = "ClipForge_${System.currentTimeMillis()}.mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/ClipForge AI")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val resolver = contentResolver
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        return try {
            resolver.openOutputStream(uri)?.use { output ->
                FileInputStream(source).use { input -> input.copyTo(output) }
            } ?: throw IllegalStateException("Tidak bisa membuka tujuan penyimpanan")
            val publish = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            resolver.update(uri, publish, null, null)
            uri
        } catch (error: Exception) {
            resolver.delete(uri, null, null)
            null
        }
    }
}

@Composable
private fun ClipForgeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Ink,
            surface = Panel,
            onPrimary = Ink,
            onBackground = Color.White,
            onSurface = Color.White
        ),
        content = content
    )
}

@OptIn(UnstableApi::class)
@Composable
private fun ClipForgeScreen(
    onExport: (Uri, Long, Long, (String) -> Unit, (Uri?) -> Unit) -> Unit
) {
    val context = LocalContext.current
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var startMs by remember { mutableLongStateOf(0L) }
    var endMs by remember { mutableLongStateOf(0L) }
    var status by remember { mutableStateOf("Pilih video untuk mulai membuat klip.") }
    var exporting by remember { mutableStateOf(false) }
    var exportedUri by remember { mutableStateOf<Uri?>(null) }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) { /* Some providers do not grant persistable access. */ }
            videoUri = uri
            durationMs = 0L
            startMs = 0L
            endMs = 0L
            exportedUri = null
            status = "Video dipilih. Memuat preview…"
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Ink, Color(0xFF101A31))))
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(46.dp).background(
                    Brush.linearGradient(listOf(Accent, Color(0xFF8B7CFF))),
                    RoundedCornerShape(15.dp)
                ),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.ContentCut, contentDescription = null, tint = Ink)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("CLIPFORGE", fontSize = 21.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
                Text("VIDEO STUDIO  •  ANDROID MVP", color = Muted, fontSize = 10.sp, letterSpacing = 1.2.sp)
            }
            Surface(color = Color(0xFF183A35), shape = CircleShape) {
                Text("BETA", modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp), color = Color(0xFF6EE7B7), fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Ubah video panjang menjadi klip.", fontSize = 26.sp, lineHeight = 32.sp, fontWeight = FontWeight.Bold)
            Text("Pilih video, tentukan bagian, lalu export MP4.", color = Muted, fontSize = 14.sp)
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = Panel),
            shape = RoundedCornerShape(22.dp)
        ) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Movie, tint = Accent, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("PREVIEW VIDEO", fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.sp)
                    Spacer(Modifier.weight(1f))
                    Text(if (durationMs > 0) formatTime(durationMs) else "Belum ada video", color = Muted, fontSize = 11.sp)
                }
                if (videoUri != null) {
                    VideoPreview(uri = videoUri!!, onDuration = { duration ->
                        if (duration > 0 && duration != durationMs) {
                            durationMs = duration
                            if (endMs == 0L || endMs > duration) endMs = duration
                        }
                    })
                } else {
                    Box(
                        Modifier.fillMaxWidth().height(190.dp)
                            .background(Color(0xFF0B1222), RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Movie, tint = Color(0xFF50617F), modifier = Modifier.size(42.dp), contentDescription = null)
                            Text("Preview akan tampil di sini", color = Muted, fontSize = 13.sp)
                        }
                    }
                }
                Button(
                    onClick = { picker.launch(arrayOf("video/*")) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF243754)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.FolderOpen, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (videoUri == null) "Pilih video dari perangkat" else "Ganti video")
                }
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("POTONG VIDEO", fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.sp)
                    Spacer(Modifier.weight(1f))
                    Surface(color = Color(0xFF18314D), shape = CircleShape) {
                        Text("MANUAL", color = Accent, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp))
                    }
                }
                if (durationMs > 0) {
                    Text("Mulai  •  ${formatTime(startMs)}", color = Color.White, fontSize = 13.sp)
                    Slider(
                        value = startMs.toFloat().coerceIn(0f, durationMs.toFloat()),
                        onValueChange = { startMs = it.toLong().coerceAtMost((endMs - 500L).coerceAtLeast(0L)) },
                        valueRange = 0f..durationMs.toFloat(),
                        colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent)
                    )
                    Text("Selesai  •  ${formatTime(endMs)}", color = Color.White, fontSize = 13.sp)
                    Slider(
                        value = endMs.toFloat().coerceIn(0f, durationMs.toFloat()),
                        onValueChange = { endMs = it.toLong().coerceAtLeast(startMs + 500L).coerceAtMost(durationMs) },
                        valueRange = 0f..durationMs.toFloat(),
                        colors = SliderDefaults.colors(thumbColor = Color(0xFF9D8CFF), activeTrackColor = Color(0xFF9D8CFF))
                    )
                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Durasi klip", color = Muted, fontSize = 12.sp)
                        Text(formatTime((endMs - startMs).coerceAtLeast(0L)), color = Accent, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Text("Geser slider untuk memilih titik awal dan akhir klip.", color = Muted, fontSize = 11.sp)
                } else {
                    Text("Pilih video untuk mengaktifkan kontrol pemotongan.", color = Muted, fontSize = 13.sp)
                }
                Button(
                    enabled = videoUri != null && durationMs > 0 && !exporting &&
                        ClipRangeValidator.isValid(startMs, endMs, durationMs),
                    onClick = {
                        exporting = true
                        exportedUri = null
                        onExport(videoUri!!, startMs, endMs,
                            { message -> status = message },
                            { uri -> exportedUri = uri; exporting = false }
                        )
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Ink),
                    shape = RoundedCornerShape(15.dp)
                ) {
                    if (exporting) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = Ink)
                        Spacer(Modifier.width(10.dp))
                        Text("Sedang memproses…", fontWeight = FontWeight.Bold)
                    } else {
                        Icon(Icons.Default.SaveAlt, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Potong & Export MP4", fontWeight = FontWeight.Bold)
                    }
                }
                if (exporting) LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Accent)
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF111B2D)), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("STATUS PROYEK", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text(status, color = Color.White, fontSize = 13.sp)
                if (exportedUri != null) {
                    Text("Lokasi: Movies/ClipForge AI", color = Color(0xFF6EE7B7), fontSize = 12.sp)
                }
            }
        }

        Text("CLIPFORGE AI  •  MVP 0.1.0", color = Color(0xFF61718D), fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun VideoPreview(uri: Uri, onDuration: (Long) -> Unit) {
    val context = LocalContext.current
    val player = remember(uri) { ExoPlayer.Builder(context).build() }

    DisposableEffect(player, uri) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY && player.duration > 0) {
                    onDuration(player.duration)
                }
            }
        }
        player.addListener(listener)
        player.setMediaItem(MediaItem.fromUri(uri))
        player.prepare()
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }

    AndroidView(
        factory = { viewContext ->
            PlayerView(viewContext).apply {
                this.player = player
                useController = true
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    (viewContext.resources.displayMetrics.density * 205).toInt()
                )
            }
        },
        update = { it.player = player },
        modifier = Modifier.fillMaxWidth().height(205.dp)
    )
}

private fun formatTime(milliseconds: Long): String {
    val totalSeconds = (milliseconds / 1000L).coerceAtLeast(0L)
    val hours = totalSeconds / 3600L
    val minutes = (totalSeconds % 3600L) / 60L
    val seconds = totalSeconds % 60L
    return if (hours > 0) String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
    else String.format(Locale.US, "%02d:%02d", minutes, seconds)
}
