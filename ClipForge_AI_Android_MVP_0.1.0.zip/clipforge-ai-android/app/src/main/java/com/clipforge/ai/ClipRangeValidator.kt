package com.clipforge.ai

/**
 * Keeps the selected clip range inside the source duration.
 * End time is exclusive, matching Media3 clipping semantics.
 */
object ClipRangeValidator {
    fun isValid(startMs: Long, endMs: Long, durationMs: Long): Boolean {
        return durationMs > 0L &&
            startMs >= 0L &&
            endMs > startMs &&
            endMs <= durationMs
    }

    fun clampStart(candidateMs: Long, endMs: Long): Long =
        candidateMs.coerceAtLeast(0L).coerceAtMost((endMs - 500L).coerceAtLeast(0L))

    fun clampEnd(candidateMs: Long, startMs: Long, durationMs: Long): Long =
        candidateMs.coerceAtLeast(startMs + 500L).coerceAtMost(durationMs)
}
