# ClipForge AI — Android MVP

ClipForge AI is an Android-first video clipping app. This first scaffold implements:
- Local video selection through Android's Storage Access Framework.
- Video preview using AndroidX Media3 ExoPlayer.
- Manual start/end selection.
- MP4 export using AndroidX Media3 Transformer.
- Saving exported clips to `Movies/ClipForge AI` through MediaStore.

## Current scope

This is **MVP 0.1.0**, not the complete product. It does not yet include:
- YouTube downloading (and it must not bypass YouTube restrictions).
- AI highlight detection.
- Automatic subtitles.
- Multi-clip batch editing.
- Website client or cloud backend.

For YouTube, the planned safe workflow is embedded playback plus timestamp/bookmark links. MP4 export should only operate on local files or sources that explicitly permit downloading and processing.

## Requirements

- Android Studio with JDK 17.
- Android SDK Platform 35.
- Gradle 8.9+ (Android Gradle Plugin 8.7.3).
- Android device/emulator running Android 10 (API 29) or newer.

## Open and run

1. Extract this ZIP.
2. Open the `clipforge-ai-android` folder in Android Studio.
3. Allow Gradle sync and dependency downloads.
4. Connect an Android device or start an emulator.
5. Press **Run**.

The project currently includes Gradle build files but not the Gradle wrapper JAR. Android Studio can import the project and configure Gradle; if your environment requires a wrapper, generate it from the project root using the Gradle installation available in Android Studio.

## Use

1. Tap **Pilih video dari perangkat**.
2. Choose a video file.
3. Wait for the preview and duration to load.
4. Adjust the start and end sliders.
5. Tap **Potong & Export MP4**.
6. Find the output in `Movies/ClipForge AI`.

## Architecture

- UI: Kotlin + Jetpack Compose + Material 3.
- Playback: AndroidX Media3 ExoPlayer.
- Export: AndroidX Media3 Transformer.
- Storage: Android Storage Access Framework + MediaStore.
- Validation: small pure Kotlin range validator with unit tests.

## Known limitations / next engineering tasks

- Verify compilation against the exact Media3 1.5.1 dependency APIs in Android Studio.
- Add export cancellation and robust progress polling.
- Add thumbnail timeline and numeric time entry.
- Add multiple clip segments and project persistence.
- Add instrumentation tests on physical devices and a range of codecs.
- Add error classification for unsupported codecs/container formats.
- Add localization and accessibility labels.
- Consider updating dependency versions after checking current stable releases.

## Verification status

Source scaffold and static package checks are generated. A Gradle/Android build has **not** been run in this environment, so APK generation and runtime behavior remain unverified until Android Studio builds and tests the project.
