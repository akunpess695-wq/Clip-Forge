package com.clipforge.ai

import android.net.Uri
import android.util.Size
import androidx.media3.common.MediaItem
import androidx.media3.common.OverlaySettings
import androidx.media3.common.VideoCompositorSettings
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Crop
import androidx.media3.effect.Presentation
import androidx.media3.common.StaticOverlaySettings
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects

/** First-pass Media3 GPU composition: two synchronized video streams, one audio stream. */
@OptIn(UnstableApi::class)
object GamingSplitExporter {
    const val OUTPUT_WIDTH = 720
    const val OUTPUT_HEIGHT = 1280

    fun composition(
        gameplayUri: Uri,
        facecamUri: Uri,
        singleVideo: Boolean,
        facecamCrop: NormalizedCrop,
        gameplayCrop: NormalizedCrop,
        startMs: Long,
        endMs: Long
    ): Composition {
        require(startMs >= 0 && endMs > startMs)
        val faceUri = if (singleVideo) gameplayUri else facecamUri
        fun item(uri: Uri): MediaItem = MediaItem.Builder().setUri(uri)
            .setClippingConfiguration(MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(startMs).setEndPositionMs(endMs).build()).build()

        fun videoEffects(crop: NormalizedCrop, height: Int) = Effects(
            emptyList(),
            listOf(
                // Crop uses GL coordinates: left/right [-1,1], bottom/top [-1,1].
                Crop(
                    2f * crop.left - 1f,
                    2f * (crop.left + crop.width) - 1f,
                    1f - 2f * (crop.top + crop.height),
                    1f - 2f * crop.top
                ),
                Presentation.createForWidthAndHeight(
                    OUTPUT_WIDTH, height, Presentation.LAYOUT_SCALE_TO_FIT
                )
            )
        )
        val face = EditedMediaItem.Builder(item(faceUri))
            .setRemoveAudio(true)
            .setEffects(videoEffects(facecamCrop, OUTPUT_HEIGHT * 40 / 100))
            .build()
        val game = EditedMediaItem.Builder(item(gameplayUri))
            .setEffects(videoEffects(gameplayCrop, OUTPUT_HEIGHT * 60 / 100))
            .build()
        return Composition.Builder(
            EditedMediaItemSequence(listOf(face)),
            EditedMediaItemSequence(listOf(game))
        ).setVideoCompositorSettings(object : VideoCompositorSettings {
            override fun getOutputSize(inputSizes: List<Size>): Size = Size(OUTPUT_WIDTH, OUTPUT_HEIGHT)

            override fun getOverlaySettings(inputId: Int, presentationTimeUs: Long): OverlaySettings =
                StaticOverlaySettings.Builder()
                    .setScale(1f, 1f)
                    .setOverlayFrameAnchor(0f, 0f)
                    // Center of upper 40% = +0.6, lower 60% = -0.4 in NDC.
                    .setBackgroundFrameAnchor(0f, if (inputId == 0) 0.6f else -0.4f)
                    .build()
        }).build()
    }
}
