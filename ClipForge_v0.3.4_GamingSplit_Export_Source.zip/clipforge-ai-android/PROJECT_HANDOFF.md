# PROJECT_HANDOFF — ClipForge AI Studio v0.3.4

## Tujuan dan konfigurasi
Android Kotlin/Compose minSdk 29, compileSdk 35, Media3 1.5.1. Gaming Split 9:16: facecam atas 40%, gameplay bawah 60%. Mode satu video auto-detect + crop manual/pinch; mode dua video tetap ada. Subtitle otomatis OFF, Smart Highlight heuristik audio ON.

## Perubahan v0.3.4 (ekspor)
- `GamingSplitExporter.kt`: komposisi Media3 dua sequence sinkron dengan `Crop`, `Presentation`, `VideoCompositorSettings` dan `StaticOverlaySettings` untuk posisi atas/bawah. Audio hanya dari gameplay agar tidak menggandakan suara pada satu-video.
- `MainActivity.kt`: mengaktifkan tombol ekspor saat Gaming Split, memanggil komposisi sesuai crop yang dipilih, menyimpan MP4 melalui MediaStore dengan `IS_PENDING` dan membersihkan entri bila gagal.
- `app/build.gradle.kts`: versionCode 5, versionName 0.3.4, applicationId tetap com.clipforge.ai.

## Status yang harus dibedakan
**Ini implementasi awal renderer, BELUM diverifikasi melalui Gradle/Android atau tes HP.** Tidak boleh menjanjikan MP4 berhasil sebelum GitHub Actions `:app:assembleDebug` dan pengujian perangkat lulus. `Presentation.LAYOUT_SCALE_TO_FIT` dapat menyebabkan letterbox pada crop dengan rasio yang tidak sama dengan slot; hasil belum dijamin pixel-perfect dengan preview. Ekspor dua video mengambil audio gameplay saja dan memotong rentang waktu sama; sinkronisasi offset belum tersedia. Auto Cut multiple ranges belum digabung dengan Gaming Split.

## Langkah verifikasi berikutnya (WAJIB)
1. GitHub Actions: `./gradlew :app:testDebugUnitTest :app:assembleDebug --stacktrace` (atau `gradle` jika wrapper tidak tersedia).
2. Perbaiki error API Media3 berdasarkan compiler bila ada. Jangan tebak atau klaim PASS tanpa build.
3. Install APK di HP, uji 1 video portrait + facecam overlay, pinch crop, ekspor, putar MP4 di galeri; pastikan video vertikal, suara sekali, durasi dan dua panel tepat.
4. Uji mode dua video, tanpa audio, source portrait/landscape, durasi pendek, pembatalan dan ruang disk rendah.
5. Pastikan sertifikat signing sama dengan APK lama sebelum update tanpa uninstall. Debug keystore dari runner GitHub bisa berubah.

## Referensi proyek
Source `app/src/main/java/com/clipforge/ai/`; UI `MainActivity.kt`, crop `SingleVideoCrop.kt`, gesture `CropGestureMath.kt`, AI awal `SingleVideoFacecamDetector.kt`, export `GamingSplitExporter.kt`. Simpan source asli tanpa modifikasi destruktif.
