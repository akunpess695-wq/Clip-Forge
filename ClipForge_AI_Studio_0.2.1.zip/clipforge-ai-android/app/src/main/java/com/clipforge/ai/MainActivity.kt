package com.clipforge.ai

import android.content.ContentValues
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.media3.transformer.Composition
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File
import java.io.FileInputStream
import java.util.Locale

private val Night = Color(0xFF080D1B)
private val Panel = Color(0xFF121C33)
private val Panel2 = Color(0xFF192642)
private val Blue = Color(0xFF4B8DFF)
private val Violet = Color(0xFF9A70FF)
private val Muted = Color(0xFF9BAAC7)
private val White = Color(0xFFF4F7FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8, 13, 27)
        window.navigationBarColor = android.graphics.Color.rgb(8, 13, 27)
        setContent { ClipForgeApp() }
    }
}

@Composable
private fun ClipForgeApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var videoName by remember { mutableStateOf("Belum ada video") }
    var durationMs by remember { mutableLongStateOf(0L) }
    var startMs by remember { mutableLongStateOf(0L) }
    var endMs by remember { mutableLongStateOf(0L) }
    var status by remember { mutableStateOf("Pilih video untuk mulai membuat klip.") }
    var exporting by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            videoUri = uri
            try {
                val retriever = MediaMetadataRetriever()
                retriever.setDataSource(context, uri)
                durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                retriever.release()
                startMs = 0L
                endMs = durationMs
                videoName = uri.lastPathSegment?.substringAfterLast('/')?.take(32) ?: "Video dipilih"
                status = "Video siap diedit. Atur rentang klip, lalu export."
            } catch (_: Exception) {
                durationMs = 0L
                endMs = 0L
                status = "Video dipilih, tetapi durasinya tidak dapat dibaca."
            }
        }
    }

    val player = remember(videoUri) {
        videoUri?.let {
            ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(it))
                prepare()
                playWhenReady = false
                addListener(object : Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
                })
            }
        }
    }
    DisposableEffect(player) { onDispose { player?.release() } }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Blue, secondary = Violet, background = Night,
            surface = Panel, onPrimary = Color.White, onBackground = White,
            onSurface = White
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Night) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).background(
                    Brush.verticalGradient(listOf(Color(0xFF0B1226), Night, Color(0xFF101A31)))
                ).padding(horizontal = 18.dp)
            ) {
                Spacer(Modifier.height(18.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(54.dp).clip(RoundedCornerShape(17.dp))
                            .background(Brush.linearGradient(listOf(Blue, Violet))),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(painterResource(R.drawable.ic_clipforge_logo), contentDescription = "ClipForge logo", modifier = Modifier.fillMaxSize())
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("CLIPFORGE", color = White, fontSize = 20.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
                        Text("VIDEO STUDIO  •  ANDROID", color = Muted, fontSize = 10.sp, letterSpacing = 1.8.sp)
                    }
                    Box(
                        Modifier.clip(CircleShape).background(Color(0xFF153D3A)).padding(horizontal = 14.dp, vertical = 9.dp)
                    ) { Text("BETA", color = Color(0xFF71E0BF), fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                }

                Spacer(Modifier.height(26.dp))
                Text("Edit video.\nBuat momen jadi klip.", color = White, fontSize = 29.sp, lineHeight = 34.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(8.dp))
                Text("Pilih footage, tentukan momen terbaik, lalu export.", color = Muted, fontSize = 14.sp)

                Spacer(Modifier.height(22.dp))
                StudioCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.VideoLibrary, null, tint = Blue)
                        Spacer(Modifier.width(9.dp))
                        Text("VIDEO PREVIEW", color = White, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Spacer(Modifier.weight(1f))
                        Text(if (videoUri == null) "NO MEDIA" else "MEDIA READY", color = if (videoUri == null) Muted else Color(0xFF71E0BF), fontSize = 10.sp)
                    }
                    Spacer(Modifier.height(14.dp))
                    Box(
                        Modifier.fillMaxWidth().height(205.dp).clip(RoundedCornerShape(18.dp))
                            .background(Color(0xFF070C18)).border(1.dp, Color(0xFF263657), RoundedCornerShape(18.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (player != null) {
                            AndroidView(
                                modifier = Modifier.fillMaxSize(),
                                factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } },
                                update = { it.player = player }
                            )
                        } else {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    Modifier.size(62.dp).clip(CircleShape)
                                        .background(Brush.linearGradient(listOf(Color(0xFF203D70), Color(0xFF38265F)))),
                                    contentAlignment = Alignment.Center
                                ) { Icon(Icons.Default.PlayArrow, null, tint = White, modifier = Modifier.size(34.dp)) }
                                Spacer(Modifier.height(12.dp))
                                Text("Your next clip starts here", color = White, fontWeight = FontWeight.SemiBold)
                                Text("MP4 • MOV • M4V", color = Muted, fontSize = 11.sp)
                            }
                        }
                    }
                    Spacer(Modifier.height(13.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(videoName, color = White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(if (durationMs > 0) "${formatTime(durationMs)} total duration" else "Belum ada media", color = Muted, fontSize = 10.sp)
                        }
                        Button(
                            onClick = { picker.launch("video/*") },
                            colors = ButtonDefaults.buttonColors(containerColor = Blue),
                            shape = RoundedCornerShape(13.dp),
                            contentPadding = PaddingValues(horizontal = 15.dp, vertical = 11.dp)
                        ) {
                            Icon(Icons.Default.FolderOpen, null, modifier = Modifier.size(17.dp))
                            Spacer(Modifier.width(7.dp))
                            Text("Import video", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))
                StudioCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("CLIP CONTROLS", color = White, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Text("Atur awal dan akhir klip", color = Muted, fontSize = 11.sp)
                        }
                        Surface(color = Color(0xFF1A3157), shape = CircleShape) {
                            Text("MANUAL", Modifier.padding(horizontal = 13.dp, vertical = 7.dp), color = Blue, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.height(13.dp))
                    if (durationMs > 0L) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("START  ${formatTime(startMs)}", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            Text("END  ${formatTime(endMs)}", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Slider(
                            value = startMs.toFloat(),
                            onValueChange = { startMs = it.toLong().coerceIn(0L, (endMs - 1000L).coerceAtLeast(0L)) },
                            valueRange = 0f..durationMs.toFloat(),
                            colors = SliderDefaults.colors(thumbColor = Blue, activeTrackColor = Blue, inactiveTrackColor = Panel2)
                        )
                        Slider(
                            value = endMs.toFloat(),
                            onValueChange = { endMs = it.toLong().coerceIn((startMs + 1000L).coerceAtMost(durationMs), durationMs) },
                            valueRange = 0f..durationMs.toFloat(),
                            colors = SliderDefaults.colors(thumbColor = Violet, activeTrackColor = Violet, inactiveTrackColor = Panel2)
                        )
                        Text("Durasi klip: ${formatTime((endMs - startMs).coerceAtLeast(0L))}", color = White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    } else {
                        Text("Import video untuk mengaktifkan kontrol pemotongan.", color = Muted, fontSize = 13.sp)
                    }
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val source = videoUri ?: return@Button
                            if (ClipRangeValidator.validate(startMs, endMs, durationMs) == null) {
                                status = "Rentang klip tidak valid. Pilih durasi minimal 1 detik."
                                return@Button
                            }
                            exporting = true
                            status = "Menyiapkan export MP4…"
                            val output = File(context.cacheDir, "clipforge_${System.currentTimeMillis()}.mp4")
                            val clippedItem = MediaItem.Builder()
                                .setUri(source)
                                .setClippingConfiguration(
                                    MediaItem.ClippingConfiguration.Builder()
                                        .setStartPositionMs(startMs)
                                        .setEndPositionMs(endMs)
                                        .build()
                                ).build()
                            val transformer = Transformer.Builder(context).addListener(object : Transformer.Listener {
                                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                                    try {
                                        val values = ContentValues().apply {
                                            put(MediaStore.Video.Media.DISPLAY_NAME, "ClipForge_${System.currentTimeMillis()}.mp4")
                                            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                                            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ClipForge AI")
                                        }
                                        val dest = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                                            ?: error("Tidak dapat membuat file output.")
                                        context.contentResolver.openOutputStream(dest)?.use { out ->
                                            FileInputStream(output).use { input -> input.copyTo(out) }
                                        } ?: error("Tidak dapat membuka output.")
                                        output.delete()
                                        exporting = false
                                        status = "Export selesai. Video tersimpan di Movies/ClipForge AI."
                                    } catch (e: Exception) {
                                        exporting = false
                                        status = "Gagal menyimpan hasil: ${e.localizedMessage}"
                                    }
                                }
                                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                                    exporting = false
                                    status = "Export gagal: ${exportException.localizedMessage ?: "Kesalahan media"}"
                                    output.delete()
                                }
                            }).build()
                            try {
                                transformer.start(clippedItem, output.absolutePath)
                            } catch (e: Exception) {
                                exporting = false
                                status = "Tidak dapat memulai export: ${e.localizedMessage}"
                                output.delete()
                            }
                        },
                        enabled = videoUri != null && !exporting,
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = RoundedCornerShape(15.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Blue,
                            disabledContainerColor = Color(0xFF29344A),
                            contentColor = Color.White,
                            disabledContentColor = Muted
                        )
                    ) {
                        if (exporting) CircularProgressIndicator(Modifier.size(19.dp), color = White, strokeWidth = 2.dp)
                        else Icon(Icons.Default.SaveAlt, null)
                        Spacer(Modifier.width(9.dp))
                        Text(if (exporting) "Exporting…" else "Export clip as MP4", fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(Modifier.height(15.dp))
                StudioCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AutoAwesome, null, tint = Violet)
                        Spacer(Modifier.width(8.dp))
                        Text("PROJECT STATUS", color = White, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(status, color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
                }
                Spacer(Modifier.height(20.dp))
            }
        }
    }
}

@Composable
private fun StudioCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(23.dp))
            .background(Brush.linearGradient(listOf(Panel, Color(0xFF101A30))))
            .border(1.dp, Color(0xFF243453), RoundedCornerShape(23.dp))
            .padding(17.dp),
        content = content
    )
}

private fun formatTime(ms: Long): String {
    val total = (ms / 1000L).coerceAtLeast(0L)
    return String.format(Locale.US, "%02d:%02d", total / 60L, total % 60L)
}
