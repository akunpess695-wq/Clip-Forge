# ClipForge v0.4.0 — GitHub Actions Media3 compile fix

## Evidence
User-supplied GitHub Actions archive `logs_114135919177.zip` reports seven Kotlin errors, all in `GamingSplitExporter.kt`: unresolved `VideoCompositorSettings` and `StaticOverlaySettings`, mismatched compositor type, and invalid overrides.

## Changes
- Use `androidx.media3.common.VideoCompositorSettings` (already present).
- Correct `OverlaySettings` and `StaticOverlaySettings` imports to `androidx.media3.common` for the Media3 API used by this project.
- Keep `androidx.media3:media3-transformer:1.5.1`.
- Increase versionCode to 7, versionName to 0.4.0.

## Verification and limitations
- Source inspection and ZIP CRC checks performed.
- No complete Android Gradle build run in this environment (Gradle/Android SDK unavailable).
- Export behavior on device is UNVERIFIED; runtime compositing, audio and save to MediaStore must be tested.
- Re-run GitHub Actions. If compiler still fails, supply entire new logs archive.
- For APK update without uninstall, use same applicationId and signing certificate as installed APK.

## Product goals
Single-video facecam auto detect with manual drag/pinch; Gaming Split facecam 40% / gameplay 60%; subtitle off; audio-based Smart Highlight on; export 9:16 MP4 to Movies/ClipForge AI.

## v0.4.0 — Layout templates
- `LayoutTemplate.kt`: data-driven layouts (layers in draw order, 720x1280 canvas): FACE_TOP_40 (default), FACE_TOP_50, FACE_BOTTOM_40, PIP_TOP_RIGHT, PIP_TOP_LEFT.
- `GamingSplitExporter.composition(..., layout, ...)` builds one sequence per layer; overlay anchor comes from the layer rect. Layers use LAYOUT_SCALE_TO_FIT_WITH_CROP (no black bars).
- UI: template radio list with schematic thumbnails in Template Editor. The two crop-preview panels and the two-video "PREVIEW LAYOUT" box still show the 40/60 stack regardless of template (UNVERIFIED/TODO: make them template-aware).
- UNVERIFIED on device: PIP templates (overlay size/position at 264x264), audio source with PIP (gameplay is input 0 there), save to MediaStore.

## Backlog
Planned, not implemented: auto caption from audio, URL video import/detection, per-platform output size presets. Details and open questions in `docs/BACKLOG.md`.

## v0.4.1 — Platform size presets
- `OutputFormat.kt`: canvases 9:16 (720x1280), 4:5 (720x900), 1:1 (720x720), 16:9 (1280x720). `PlatformPreset`: TikTok, IG Reels/Story, YouTube Shorts, Threads (9:16); IG Feed, Facebook/LinkedIn Feed (4:5); X square (1:1); X landscape, YouTube landscape (16:9).
- `LayoutTemplate.layers(format)`: split templates stack top/bottom on portrait/square, side by side on 16:9; PiP scales with the short side. 9:16 geometry is identical to v0.4.0.
- `GamingSplitExporter.composition(..., layout, format, ...)` takes the canvas from the format.
- UI: horizontal platform chips above the template list; thumbnails follow the chosen ratio.
- Scope: Gaming Split export only. Not verified: Gradle build, on-device export for 4:5, 1:1, 16:9.

## v0.4.2 — Creator Pro UI merged onto v0.4.1 code
- Root cause of the failing "CreatorPro v0.3.8" candidate (ChatGPT): its exporter was the old v0.3.7 code (`androidx.media3.effect.StaticOverlaySettings` does not exist in Media3 1.5.1; `android.util.Size` is not the type `VideoCompositorSettings` uses). Its changes were UI-only, so the compile error was never touched.
- Fix: kept all code from v0.4.1 (Media3 1.5.1 API fixes: `OverlaySettings.Builder()`, `androidx.media3.common.util.Size`; fill-with-crop; layout templates; platform presets) and applied the Creator Pro UI diff (palette, 3-step wording, collapsible "Atur layout" and "Smart Auto Cut" panels, Gaming Split on by default) via `patch`; no rejected hunks.
- The "Atur layout" button label is now dynamic (template + ratio) instead of hard-coded "40:60".
- UI badge: "CREATOR PRO • v0.4.2". versionCode 13, versionName 0.4.2.
- UNVERIFIED: Gradle compile and on-device behavior (no SDK here). v0.4.1 had not been confirmed compiling by the owner before this merge; if the build fails, send the full log.
