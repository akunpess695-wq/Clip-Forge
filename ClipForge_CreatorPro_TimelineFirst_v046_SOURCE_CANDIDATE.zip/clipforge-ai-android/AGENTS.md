# ClipForge development guidance

This is a ClipForge-specific entry point, not the upstream Superpowers contributor policy.

- Read `antislop.md` before UI work. Session mode is DURING unless the owner changes it.
- Read `DESIGN.md` for the current visual direction; unresolved decisions require owner approval.
- Preserve working Android import, playback, trimming and MP4 export flows.
- Prefer small, testable Kotlin changes. Do not describe a feature as functional without testing it.
- The offline silence engine only produces suggestions; never delete or edit original footage.
- Obtain approval before sending footage/audio to a cloud provider. Do not embed provider secrets in an APK.
- For review use specialist lenses: Android/Compose, media processing, AI, UI/accessibility, and code quality.
- Before shipping, run tests/build and document what was actually verified on-device.
- Every delivery that creates or changes files must include an updated handoff `.md` (`ClipForge_HANDOFF_vXXX_YYYYMMDD.md`): changes, evidence, verified vs unverified, limitations, next steps. Planned work lives in `docs/BACKLOG.md`.
