package com.clipforge.ai

import kotlin.math.roundToInt

enum class LayerSource { FACECAM, GAMEPLAY }

/** One rectangle on the output canvas (top-left origin, pixels). */
data class LayoutLayer(val source: LayerSource, val x: Int, val y: Int, val width: Int, val height: Int) {
    /** Center in Media3 NDC: x/y in [-1, 1], y up. */
    fun anchorX(canvasWidth: Int): Float = 2f * (x + width / 2f) / canvasWidth - 1f
    fun anchorY(canvasHeight: Int): Float = 1f - 2f * (y + height / 2f) / canvasHeight
}

private fun even(v: Float): Int = (v.roundToInt() / 2) * 2

/**
 * Export layouts. [layers] returns rectangles in DRAW ORDER: first = background (input 0), later = on top.
 * Split templates stack top/bottom on portrait/square canvases and sit side by side on landscape (16:9).
 * Every layer is "fill + center crop" into its rectangle.
 */
enum class LayoutTemplate(val label: String, val description: String) {
    FACE_TOP_40("Split 40/60 · Facecam utama", "Facecam 40% (atas / kiri), gameplay 60%"),
    FACE_TOP_50("Split 50/50", "Facecam dan gameplay sama besar"),
    FACE_BOTTOM_40("Split 60/40 · Gameplay utama", "Gameplay 60% (atas / kiri), facecam 40%"),
    PIP_TOP_RIGHT("Gameplay penuh · Facecam kanan atas", "Facecam kecil di pojok kanan atas"),
    PIP_TOP_LEFT("Gameplay penuh · Facecam kiri atas", "Facecam kecil di pojok kiri atas");

    fun layers(format: OutputFormat): List<LayoutLayer> {
        val w = format.width
        val h = format.height
        return when (this) {
            FACE_TOP_40 -> split(format, 0.40f, faceFirst = true)
            FACE_TOP_50 -> split(format, 0.50f, faceFirst = true)
            FACE_BOTTOM_40 -> split(format, 0.40f, faceFirst = false)
            PIP_TOP_RIGHT, PIP_TOP_LEFT -> {
                val side = even(0.3667f * minOf(w, h))
                val margin = even(minOf(w, h) / 30f)
                // Portrait 9:16 keeps clear of the platform top UI; other ratios use the plain margin.
                val top = if (format == OutputFormat.RATIO_9_16) 96 else margin
                val x = if (this == PIP_TOP_RIGHT) w - margin - side else margin
                listOf(
                    LayoutLayer(LayerSource.GAMEPLAY, 0, 0, w, h),
                    LayoutLayer(LayerSource.FACECAM, x, top, side, side)
                )
            }
        }
    }

    fun layer(format: OutputFormat, source: LayerSource): LayoutLayer = layers(format).first { it.source == source }

    private fun split(format: OutputFormat, faceFraction: Float, faceFirst: Boolean): List<LayoutLayer> {
        val w = format.width
        val h = format.height
        val face: LayoutLayer
        val game: LayoutLayer
        if (format.isLandscape) {
            val faceW = even(w * faceFraction)
            face = LayoutLayer(LayerSource.FACECAM, if (faceFirst) 0 else w - faceW, 0, faceW, h)
            game = LayoutLayer(LayerSource.GAMEPLAY, if (faceFirst) faceW else 0, 0, w - faceW, h)
        } else {
            val faceH = even(h * faceFraction)
            face = LayoutLayer(LayerSource.FACECAM, 0, if (faceFirst) 0 else h - faceH, w, faceH)
            game = LayoutLayer(LayerSource.GAMEPLAY, 0, if (faceFirst) faceH else 0, w, h - faceH)
        }
        return if (faceFirst) listOf(face, game) else listOf(game, face)
    }
}
