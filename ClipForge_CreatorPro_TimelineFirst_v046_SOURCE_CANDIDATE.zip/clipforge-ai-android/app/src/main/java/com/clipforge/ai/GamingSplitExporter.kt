package com.clipforge.ai

import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Crop
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.VideoCompositorSettings
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects

/** Media3 GPU composition: two synchronized video streams placed by a [LayoutTemplate], one audio stream. */
@OptIn(UnstableApi::class)
object GamingSplitExporter {
    fun composition(
        gameplayUri: Uri,
        facecamUri: Uri,
        singleVideo: Boolean,
        layout: LayoutTemplate,
        format: OutputFormat,
        facecamCrop: NormalizedCrop,
        gameplayCrop: NormalizedCrop,
        startMs: Long,
        endMs: Long
    ): Composition {
        require(startMs >= 0 && endMs > startMs)
        val faceUri = if (singleVideo) gameplayUri else facecamUri
        fun item(uri: Uri): MediaItem = MediaItem.Builder().setUri(uri)
            .setClippingConfiguration(MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(startMs).setEndPositionMs(endMs).build()).build()

        fun videoEffects(crop: NormalizedCrop, layer: LayoutLayer) = Effects(
            emptyList(),
            listOf(
                // Crop uses GL coordinates: left/right [-1,1], bottom/top [-1,1].
                Crop(
                    2f * crop.left - 1f,
                    2f * (crop.left + crop.width) - 1f,
                    1f - 2f * (crop.top + crop.height),
                    1f - 2f * crop.top
                ),
                // Fill the rectangle (center crop), no black bars.
                Presentation.createForWidthAndHeight(
                    layer.width, layer.height, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP
                )
            )
        )

        // One sequence per layer, in the template's draw order (index == compositor inputId).
        val layers = layout.layers(format)
        val sequences = layers.map { layer ->
            val edited = when (layer.source) {
                LayerSource.FACECAM -> EditedMediaItem.Builder(item(faceUri))
                    .setRemoveAudio(true)
                    .setEffects(videoEffects(facecamCrop, layer))
                    .build()
                LayerSource.GAMEPLAY -> EditedMediaItem.Builder(item(gameplayUri))
                    .setEffects(videoEffects(gameplayCrop, layer))
                    .build()
            }
            EditedMediaItemSequence(listOf(edited))
        }
        return Composition.Builder(sequences).setVideoCompositorSettings(object : VideoCompositorSettings {
            override fun getOutputSize(inputSizes: List<Size>): Size = Size(format.width, format.height)

            override fun getOverlaySettings(inputId: Int, presentationTimeUs: Long): OverlaySettings {
                val layer = layers[inputId.coerceIn(0, layers.lastIndex)]
                return OverlaySettings.Builder()
                    .setScale(1f, 1f)
                    .setOverlayFrameAnchor(0f, 0f)
                    .setBackgroundFrameAnchor(layer.anchorX(format.width), layer.anchorY(format.height))
                    .build()
            }
        }).build()
    }
}
