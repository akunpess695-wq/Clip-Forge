package com.clipforge.ai

/** Export canvas. Width/height are even (H.264 friendly). Short side is 720 px. */
enum class OutputFormat(val label: String, val width: Int, val height: Int) {
    RATIO_9_16("9:16", 720, 1280),
    RATIO_4_5("4:5", 720, 900),
    RATIO_1_1("1:1", 720, 720),
    RATIO_16_9("16:9", 1280, 720);

    val isLandscape: Boolean get() = width > height
    val sizeLabel: String get() = "${width}x$height"
}

/**
 * Platform shortcuts -> canvas ratio. Ratios come from third-party 2026 spec guides (not official platform docs)
 * and should be re-verified before release. Durations / file size limits are intentionally NOT encoded.
 */
enum class PlatformPreset(val label: String, val format: OutputFormat) {
    TIKTOK("TikTok", OutputFormat.RATIO_9_16),
    INSTAGRAM_REELS("Instagram Reels/Story", OutputFormat.RATIO_9_16),
    YOUTUBE_SHORTS("YouTube Shorts", OutputFormat.RATIO_9_16),
    THREADS("Threads", OutputFormat.RATIO_9_16),
    INSTAGRAM_FEED("Instagram Feed", OutputFormat.RATIO_4_5),
    FACEBOOK_LINKEDIN_FEED("Facebook/LinkedIn Feed", OutputFormat.RATIO_4_5),
    X_SQUARE("X · Persegi", OutputFormat.RATIO_1_1),
    X_LANDSCAPE("X · Landscape", OutputFormat.RATIO_16_9),
    YOUTUBE_LANDSCAPE("YouTube Landscape", OutputFormat.RATIO_16_9)
}
