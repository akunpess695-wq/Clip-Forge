package com.clipforge.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class OutputFormatTest {
    @Test fun sizesAreEvenAndMatchRatio() {
        assertEquals(720 to 1280, OutputFormat.RATIO_9_16.let { it.width to it.height })
        assertEquals(720 to 900, OutputFormat.RATIO_4_5.let { it.width to it.height })
        assertEquals(720 to 720, OutputFormat.RATIO_1_1.let { it.width to it.height })
        assertEquals(1280 to 720, OutputFormat.RATIO_16_9.let { it.width to it.height })
        for (f in OutputFormat.values()) assertTrue(f.name, f.width % 2 == 0 && f.height % 2 == 0)
    }

    @Test fun onlySixteenNineIsLandscape() {
        assertEquals(listOf(OutputFormat.RATIO_16_9), OutputFormat.values().filter { it.isLandscape })
    }

    @Test fun shortVideoPlatformsUseVertical() {
        for (p in listOf(PlatformPreset.TIKTOK, PlatformPreset.INSTAGRAM_REELS, PlatformPreset.YOUTUBE_SHORTS, PlatformPreset.THREADS))
            assertEquals(p.name, OutputFormat.RATIO_9_16, p.format)
        assertEquals(OutputFormat.RATIO_4_5, PlatformPreset.INSTAGRAM_FEED.format)
    }
}
