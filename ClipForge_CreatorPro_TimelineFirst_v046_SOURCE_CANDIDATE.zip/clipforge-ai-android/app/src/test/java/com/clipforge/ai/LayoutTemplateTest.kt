package com.clipforge.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LayoutTemplateTest {
    @Test fun everyTemplateInEveryFormatHasOneFaceAndOneGameplayInsideCanvas() {
        for (t in LayoutTemplate.values()) for (f in OutputFormat.values()) {
            val name = "${t.name}/${f.name}"
            val layers = t.layers(f)
            assertEquals(name, 2, layers.size)
            assertEquals(name, 1, layers.count { it.source == LayerSource.FACECAM })
            assertEquals(name, 1, layers.count { it.source == LayerSource.GAMEPLAY })
            for (l in layers) {
                assertTrue(name, l.x >= 0 && l.y >= 0 && l.width > 0 && l.height > 0)
                assertTrue(name, l.x + l.width <= f.width && l.y + l.height <= f.height)
                assertTrue(name, l.width % 2 == 0 && l.height % 2 == 0)
            }
        }
    }

    @Test fun defaultTemplateOn9x16KeepsOriginal40_60Layout() {
        val f = OutputFormat.RATIO_9_16
        val face = LayoutTemplate.FACE_TOP_40.layer(f, LayerSource.FACECAM)
        val game = LayoutTemplate.FACE_TOP_40.layer(f, LayerSource.GAMEPLAY)
        assertEquals(512, face.height)
        assertEquals(768, game.height)
        assertEquals(0f, face.anchorX(f.width), 0.0001f)
        assertEquals(0.6f, face.anchorY(f.height), 0.0001f)
        assertEquals(-0.4f, game.anchorY(f.height), 0.0001f)
    }

    @Test fun splitTemplatesCoverWholeCanvasWithoutGapOrOverlap() {
        for (t in listOf(LayoutTemplate.FACE_TOP_40, LayoutTemplate.FACE_TOP_50, LayoutTemplate.FACE_BOTTOM_40)) {
            for (f in OutputFormat.values()) {
                val layers = t.layers(f)
                val area = layers.sumOf { it.width * it.height }
                assertEquals("${t.name}/${f.name}", f.width * f.height, area)
            }
        }
    }

    @Test fun splitStacksOnPortraitAndSquareButSitsSideBySideOnLandscape() {
        for (f in listOf(OutputFormat.RATIO_9_16, OutputFormat.RATIO_4_5, OutputFormat.RATIO_1_1)) {
            for (l in LayoutTemplate.FACE_TOP_40.layers(f)) assertEquals(f.width, l.width)
        }
        val land = OutputFormat.RATIO_16_9
        for (l in LayoutTemplate.FACE_TOP_40.layers(land)) assertEquals(land.height, l.height)
        assertEquals(0, LayoutTemplate.FACE_TOP_40.layer(land, LayerSource.FACECAM).x)
        assertEquals(0, LayoutTemplate.FACE_BOTTOM_40.layer(land, LayerSource.GAMEPLAY).x)
    }

    @Test fun pipTemplatesUseGameplayAsBackgroundAndFaceOnTop() {
        for (t in listOf(LayoutTemplate.PIP_TOP_RIGHT, LayoutTemplate.PIP_TOP_LEFT)) for (f in OutputFormat.values()) {
            val layers = t.layers(f)
            assertEquals(LayerSource.GAMEPLAY, layers.first().source)
            assertEquals(f.height, layers.first().height)
            assertEquals(f.width, layers.first().width)
            assertEquals(LayerSource.FACECAM, layers.last().source)
        }
    }

    @Test fun pipOn9x16KeepsOriginalGeometry() {
        val face = LayoutTemplate.PIP_TOP_RIGHT.layer(OutputFormat.RATIO_9_16, LayerSource.FACECAM)
        assertEquals(264, face.width)
        assertEquals(96, face.y)
        assertTrue(face.x + face.width < 720)
    }
}
