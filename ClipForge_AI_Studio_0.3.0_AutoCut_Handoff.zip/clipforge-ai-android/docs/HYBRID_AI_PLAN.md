# Hybrid AI implementation plan

## Implemented in this package
- `SilenceSuggestionEngine`: pure Kotlin conversion of timestamped audio RMS windows into candidate silent intervals.
- Unit tests for sustained silence, short silence, missing windows, and invalid ordering.
- No media is uploaded, deleted, or automatically edited.

## Not yet implemented
- Android audio decoder and RMS extraction from imported video.
- UI button, progress/error states, timeline suggestions, accept/reject review.
- Applying multiple accepted ranges to Media3 Transformer.
- Cloud AI integration, authentication, privacy consent, provider selection.

## Next milestone
1. Decode an audio track locally via Android MediaExtractor/MediaCodec, calculate time-aligned RMS windows off the main thread.
2. Add analysis states and reviewable suggestions in Compose.
3. Implement non-destructive acceptance and multi-segment export.
4. Validate on representative Android 10+ devices and real footage.

The engine is a signal-processing heuristic, not a trained AI model. No claim of working Auto Cut is made yet.
