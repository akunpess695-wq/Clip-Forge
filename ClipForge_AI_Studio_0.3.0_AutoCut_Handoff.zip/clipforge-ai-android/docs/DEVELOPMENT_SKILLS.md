# ClipForge development workflow — five-source guidance

The user provided JRHagents, Superpowers, Caveman, Anti-Slop, and Agency Agents App as development references. These are not automatically installed Android dependencies or ChatGPT Plugins.

1. **Coordinator (JRHagents):** define scope, separate planning from execution, and record evidence.
2. **Engineering (Superpowers):** inspect existing code, write a failing test when practical, implement a focused change, and verify.
3. **Quality (Anti-Slop DURING):** prioritize functioning UI, consistent design, accessibility, and honest feature labels.
4. **Communication (Caveman):** use concise explanations only when useful; never replace engineering rigor with a persona.
5. **Roles (Agency Agents App):** separate builder and reviewer responsibilities; do not execute third-party hooks or adapters by default.

## Current milestone

- `SilenceSuggestionEngine` consumes time-stamped dBFS windows.
- `AudioLevelCalculator` now computes those windows from decoded signed PCM16 samples.
- Android media extraction and decoding are **not connected yet**.
- The Analyze Silence button and suggestion-review UI are **not implemented yet**.
- No cloud API or credential is configured.

## Next acceptance criteria

1. Decode selected video's audio to PCM on a background thread, with cancellation and no audio-track handling.
2. Stream level windows to avoid storing a full recording in memory.
3. Show silence ranges with explicit accept/reject controls.
4. Keep source video untouched; never silently export a destructive edit.
5. Run Android build and device tests before calling the feature ready.
