package com.clipforge.ai

/** Pure planning logic: rejected suggestions are never removed. */
data class KeepRange(val startMs: Long, val endMs: Long)

object AutoCutPlanner {
    fun plan(durationMs: Long, suggestions: List<SilenceSuggestion>, approved: Set<Int>, minimumKeepMs: Long = 250L): List<KeepRange> {
        require(durationMs > 0L && minimumKeepMs > 0L)
        val cuts = approved.map { index ->
            require(index in suggestions.indices)
            suggestions[index]
        }.sortedBy { it.startMs }
        var cursor = 0L
        val keep = mutableListOf<KeepRange>()
        cuts.forEach { cut ->
            require(cut.startMs >= 0L && cut.endMs <= durationMs && cut.endMs > cut.startMs)
            require(cut.startMs >= cursor) { "Overlapping approved cuts" }
            if (cut.startMs - cursor >= minimumKeepMs) keep += KeepRange(cursor, cut.startMs)
            cursor = cut.endMs
        }
        if (durationMs - cursor >= minimumKeepMs) keep += KeepRange(cursor, durationMs)
        return keep
    }
}
