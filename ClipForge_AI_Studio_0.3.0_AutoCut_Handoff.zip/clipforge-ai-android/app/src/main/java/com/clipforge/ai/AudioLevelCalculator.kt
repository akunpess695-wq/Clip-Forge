package com.clipforge.ai

import kotlin.math.log10
import kotlin.math.sqrt

/** Converts decoded signed 16-bit PCM into reviewable level windows; no AI service required. */
class AudioLevelCalculator(private val windowMs: Long = 100L) {
    init { require(windowMs > 0L) }

    fun fromPcm16(samples: ShortArray, sampleRateHz: Int, channels: Int = 1): List<AudioLevelWindow> {
        require(sampleRateHz > 0 && channels > 0)
        require(samples.size % channels == 0) { "PCM must contain complete frames" }
        if (samples.isEmpty()) return emptyList()
        val frames = samples.size / channels
        val framesPerWindow = ((sampleRateHz.toLong() * windowMs) / 1000L).coerceAtLeast(1L)
        val result = mutableListOf<AudioLevelWindow>()
        var firstFrame = 0L
        while (firstFrame < frames.toLong()) {
            val lastFrame = (firstFrame + framesPerWindow).coerceAtMost(frames.toLong())
            var squared = 0.0
            var count = 0L
            for (frame in firstFrame until lastFrame) {
                for (channel in 0 until channels) {
                    val amplitude = samples[(frame * channels + channel).toInt()].toDouble() / 32768.0
                    squared += amplitude * amplitude
                    count++
                }
            }
            val rms = sqrt(squared / count)
            val dbfs = if (rms == 0.0) Double.NEGATIVE_INFINITY else 20.0 * log10(rms)
            val startMs = firstFrame * 1000L / sampleRateHz
            val endMs = lastFrame * 1000L / sampleRateHz
            if (endMs > startMs) result += AudioLevelWindow(startMs, endMs, dbfs)
            firstFrame = lastFrame
        }
        return result
    }
}
