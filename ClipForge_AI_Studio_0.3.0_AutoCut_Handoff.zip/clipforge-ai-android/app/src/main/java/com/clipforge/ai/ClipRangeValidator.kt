package com.clipforge.ai

data class ClipRange(val startMs: Long, val endMs: Long) {
    val durationMs: Long get() = endMs - startMs
}

object ClipRangeValidator {
    fun validate(startMs: Long, endMs: Long, mediaDurationMs: Long): ClipRange? {
        if (mediaDurationMs <= 0L) return null
        if (startMs < 0L || endMs > mediaDurationMs) return null
        if (startMs >= endMs) return null
        if (endMs - startMs < 1_000L) return null
        return ClipRange(startMs, endMs)
    }
}
