package com.clipforge.ai

import kotlin.math.max

/** Audio measurements are computed elsewhere; this class never edits the source video. */
data class AudioLevelWindow(val startMs: Long, val endMs: Long, val rmsDbfs: Double)
data class SilenceSuggestion(val startMs: Long, val endMs: Long)

object SilenceSuggestionEngine {
    /** Returns reviewable silent ranges. Input windows must be chronological and non-overlapping. */
    fun suggest(
        windows: List<AudioLevelWindow>,
        thresholdDbfs: Double = -40.0,
        minimumSilenceMs: Long = 700L,
        mergeGapMs: Long = 150L
    ): List<SilenceSuggestion> {
        require(thresholdDbfs.isFinite())
        require(minimumSilenceMs > 0 && mergeGapMs >= 0)
        if (windows.isEmpty()) return emptyList()
        var previousEnd = 0L
        windows.forEach {
            require(it.startMs >= previousEnd && it.endMs > it.startMs)
            require(it.rmsDbfs.isFinite() || it.rmsDbfs == Double.NEGATIVE_INFINITY)
            previousEnd = it.endMs
        }
        val candidates = mutableListOf<SilenceSuggestion>()
        var start: Long? = null
        var end = 0L
        fun flush() {
            val s = start
            if (s != null && end - s >= minimumSilenceMs) candidates += SilenceSuggestion(s, end)
            start = null
        }
        windows.forEach { window ->
            if (window.rmsDbfs <= thresholdDbfs) {
                if (start == null) start = window.startMs
                else if (window.startMs > end) flush().also { start = window.startMs }
                end = window.endMs
            } else flush()
        }
        flush()
        val merged = mutableListOf<SilenceSuggestion>()
        candidates.forEach { next ->
            val last = merged.lastOrNull()
            if (last != null && next.startMs - last.endMs <= mergeGapMs) {
                merged[merged.lastIndex] = last.copy(endMs = max(last.endMs, next.endMs))
            } else merged += next
        }
        return merged
    }
}
