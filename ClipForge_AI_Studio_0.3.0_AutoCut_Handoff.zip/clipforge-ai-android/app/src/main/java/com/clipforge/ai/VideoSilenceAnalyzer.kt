package com.clipforge.ai

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder
import kotlin.math.log10
import kotlin.math.sqrt

/** Decodes the selected video's audio locally. Never changes the original media. */
object VideoSilenceAnalyzer {
    fun analyze(context: Context, uri: Uri, windowMs: Long = 100L): List<SilenceSuggestion> {
        val extractor = MediaExtractor()
        var decoder: MediaCodec? = null
        try {
            context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
                extractor.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            } ?: error("Video tidak dapat dibuka")
            val track = (0 until extractor.trackCount).firstOrNull {
                extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            } ?: error("Video tidak memiliki trek audio")
            extractor.selectTrack(track)
            val format = extractor.getTrackFormat(track)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: error("Format audio tidak dikenal")
            decoder = MediaCodec.createDecoderByType(mime)
            decoder.configure(format, null, null, 0)
            decoder.start()
            val info = MediaCodec.BufferInfo()
            val windows = mutableListOf<AudioLevelWindow>()
            var sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var framesPerWindow = (sampleRate.toLong() * windowMs / 1000).coerceAtLeast(1)
            var sum = 0.0
            var samplesInWindow = 0L
            var framesProcessed = 0L
            var windowStartFrame = 0L
            var inputDone = false
            var outputDone = false
            var idleCount = 0
            while (!outputDone) {
                if (Thread.currentThread().isInterrupted) error("Analisis dibatalkan")
                if (!inputDone) {
                    val index = decoder.dequeueInputBuffer(10_000)
                    if (index >= 0) {
                        val buffer = decoder.getInputBuffer(index) ?: error("Buffer input tidak tersedia")
                        buffer.clear()
                        val size = extractor.readSampleData(buffer, 0)
                        if (size < 0) {
                            decoder.queueInputBuffer(index, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            decoder.queueInputBuffer(index, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                when (val index = decoder.dequeueOutputBuffer(info, 10_000)) {
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val decoded = decoder.outputFormat
                        require(!decoded.containsKey(MediaFormat.KEY_PCM_ENCODING) ||
                            decoded.getInteger(MediaFormat.KEY_PCM_ENCODING) == android.media.AudioFormat.ENCODING_PCM_16BIT) {
                            "Format PCM decoder tidak didukung"
                        }
                        sampleRate = decoded.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        channels = decoded.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        framesPerWindow = (sampleRate.toLong() * windowMs / 1000).coerceAtLeast(1)
                    }
                    in 0..Int.MAX_VALUE -> {
                        idleCount = 0
                        if (info.size > 0) {
                            val buffer = decoder.getOutputBuffer(index) ?: error("Buffer output tidak tersedia")
                            buffer.position(info.offset)
                            buffer.limit(info.offset + info.size)
                            val pcm = buffer.slice().order(ByteOrder.nativeOrder()).asShortBuffer()
                            val frames = pcm.remaining() / channels
                            repeat(frames) {
                                repeat(channels) {
                                    val value = pcm.get().toDouble() / 32768.0
                                    sum += value * value
                                }
                                samplesInWindow += channels
                                framesProcessed++
                                if (framesProcessed - windowStartFrame >= framesPerWindow) {
                                    val db = if (sum == 0.0) Double.NEGATIVE_INFINITY else 20 * log10(sqrt(sum / samplesInWindow))
                                    windows += AudioLevelWindow(windowStartFrame * 1000 / sampleRate, framesProcessed * 1000 / sampleRate, db)
                                    windowStartFrame = framesProcessed
                                    sum = 0.0
                                    samplesInWindow = 0
                                }
                            }
                        }
                        outputDone = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        decoder.releaseOutputBuffer(index, false)
                    }
                    else -> {
                        idleCount++
                        if (idleCount > 300) error("Decoder audio tidak merespons")
                    }
                }
            }
            if (samplesInWindow > 0) {
                val db = if (sum == 0.0) Double.NEGATIVE_INFINITY else 20 * log10(sqrt(sum / samplesInWindow))
                val start = windowStartFrame * 1000 / sampleRate
                val end = framesProcessed * 1000 / sampleRate
                if (end > start) windows += AudioLevelWindow(start, end, db)
            }
            return SilenceSuggestionEngine.suggest(windows)
        } finally {
            try { decoder?.stop() } catch (_: Exception) { }
            decoder?.release()
            extractor.release()
        }
    }
}
