package com.clipforge.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ClipRangeValidatorTest {
    @Test fun acceptsValidRange() {
        assertEquals(ClipRange(1_000L, 5_000L), ClipRangeValidator.validate(1_000L, 5_000L, 10_000L))
    }

    @Test fun rejectsRangeOutsideDuration() {
        assertNull(ClipRangeValidator.validate(1_000L, 11_000L, 10_000L))
    }

    @Test fun rejectsEndBeforeStart() {
        assertNull(ClipRangeValidator.validate(5_000L, 4_000L, 10_000L))
    }

    @Test fun rejectsClipShorterThanOneSecond() {
        assertNull(ClipRangeValidator.validate(1_000L, 1_500L, 10_000L))
    }
}
