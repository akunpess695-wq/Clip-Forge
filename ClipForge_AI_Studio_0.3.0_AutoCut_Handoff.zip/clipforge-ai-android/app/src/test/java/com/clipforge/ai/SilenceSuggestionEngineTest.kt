package com.clipforge.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class SilenceSuggestionEngineTest {
    @Test fun detectsSustainedSilence() {
        val windows = listOf(
            AudioLevelWindow(0, 400, -12.0),
            AudioLevelWindow(400, 800, -48.0),
            AudioLevelWindow(800, 1200, -50.0),
            AudioLevelWindow(1200, 1600, -15.0)
        )
        assertEquals(listOf(SilenceSuggestion(400, 1200)), SilenceSuggestionEngine.suggest(windows))
    }

    @Test fun ignoresShortSilence() {
        assertEquals(emptyList<SilenceSuggestion>(), SilenceSuggestionEngine.suggest(listOf(AudioLevelWindow(0, 500, -60.0))))
    }

    @Test fun doesNotTreatGapsAsMeasuredSilence() {
        val windows = listOf(AudioLevelWindow(0, 400, -60.0), AudioLevelWindow(900, 1300, -60.0))
        assertEquals(emptyList<SilenceSuggestion>(), SilenceSuggestionEngine.suggest(windows))
    }

    @Test fun rejectsUnsortedWindows() {
        assertThrows(IllegalArgumentException::class.java) {
            SilenceSuggestionEngine.suggest(listOf(AudioLevelWindow(100, 200, -50.0), AudioLevelWindow(0, 100, -50.0)))
        }
    }
}
