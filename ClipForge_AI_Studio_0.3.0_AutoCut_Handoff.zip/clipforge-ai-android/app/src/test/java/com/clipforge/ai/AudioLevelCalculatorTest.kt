package com.clipforge.ai

import org.junit.Assert.*
import org.junit.Test

class AudioLevelCalculatorTest {
    @Test fun silenceIsNegativeInfinity() {
        val windows = AudioLevelCalculator().fromPcm16(ShortArray(1600), 16000)
        assertEquals(1, windows.size)
        assertEquals(Double.NEGATIVE_INFINITY, windows[0].rmsDbfs, 0.0)
        assertEquals(100L, windows[0].endMs)
    }

    @Test fun loudSignalIsNotSilent() {
        val windows = AudioLevelCalculator().fromPcm16(ShortArray(1600) { 16384 }, 16000)
        assertTrue(windows.single().rmsDbfs > -7.0)
        assertTrue(windows.single().rmsDbfs < -5.0)
    }

    @Test fun stereoFramesUseFrameDuration() {
        val windows = AudioLevelCalculator().fromPcm16(ShortArray(3200), 16000, 2)
        assertEquals(100L, windows.single().endMs)
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsIncompleteFrames() {
        AudioLevelCalculator().fromPcm16(shortArrayOf(1, 2, 3), 16000, 2)
    }
}
