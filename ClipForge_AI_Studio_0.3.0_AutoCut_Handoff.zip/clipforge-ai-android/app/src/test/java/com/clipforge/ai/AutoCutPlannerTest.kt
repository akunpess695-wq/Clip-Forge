package com.clipforge.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class AutoCutPlannerTest {
    @Test fun noApprovalsPreserveWholeVideo() {
        assertEquals(listOf(KeepRange(0, 5000)), AutoCutPlanner.plan(5000, listOf(SilenceSuggestion(1000, 2000)), emptySet()))
    }
    @Test fun approvedSilencesBecomeGaps() {
        assertEquals(listOf(KeepRange(0, 1000), KeepRange(2000, 4000), KeepRange(4500, 6000)),
            AutoCutPlanner.plan(6000, listOf(SilenceSuggestion(1000, 2000), SilenceSuggestion(4000, 4500)), setOf(0, 1)))
    }
    @Test fun invalidApprovalIsRejected() {
        assertThrows(IllegalArgumentException::class.java) { AutoCutPlanner.plan(5000, emptyList(), setOf(0)) }
    }
}
