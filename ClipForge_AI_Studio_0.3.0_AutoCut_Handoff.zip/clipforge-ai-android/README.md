# ClipForge AI — Studio Edition 0.2.0

Android-native Kotlin + Jetpack Compose prototype.

## Visual refresh
- Dark navy studio surface with electric-blue and violet accents.
- Redesigned import/preview and clip-controls cards.
- Custom abstract waveform/play launcher artwork in vector XML.
- Updated app name and Android launcher icon resources.

## MVP functionality
- Import a local video through Android's system picker.
- Preview selected video with Media3 ExoPlayer.
- Select start/end trim points.
- Export the selected range to MP4 in `Movies/ClipForge AI` using Media3 Transformer.

## Build
Requires JDK 17, Android SDK platform 35, Build Tools 35.0.0, and Gradle 8.9.

```bash
gradle testDebugUnitTest assembleDebug
```

The GitHub Actions workflow is supplied separately as `build.yml`.
It extracts the source ZIP on the GitHub runner; the ZIP does not need to be extracted on the phone.

## Verification status
This source package has been assembled and structurally checked. It has **not** been compiled in this environment. Treat the first GitHub Actions run as the compile verification; fix any compiler/API issues reported there before relying on the APK.

## Scope note
This MVP exports local videos selected through Android's picker. YouTube URLs are not downloaded; YouTube support must use compliant playback/timestamp workflows unless the source explicitly permits downloading and processing.
