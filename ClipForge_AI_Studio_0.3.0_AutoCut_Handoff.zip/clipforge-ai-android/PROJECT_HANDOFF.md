# ClipForge AI Studio — Project Handoff

**Tanggal:** 2026-11-05  
**Status:** source prototype v0.3.0, NOT a verified Android APK.  
**Purpose:** enable another AI account/developer to resume without relying on chat history.

## 1. Goal and product decisions

Build a practical Android video editor with **hybrid AI**: editing and basic silence analysis run offline; optional online AI can later provide transcription and highlight selection. The immediate priority is **Smart Auto Cut with explicit review and approval**, not autonomous deletion. Never modify the source video. UX must avoid generic AI aesthetics (see `DESIGN.md` and `antislop.md`). User language is Indonesian.

## 2. Current source and structure

This archive contains the Android project at `clipforge-ai-android/`. Kotlin + Jetpack Compose; Media3 ExoPlayer preview; Media3 Transformer MP4 export; minimum Android API 29. See `app/build.gradle.kts` for exact versions. The project contains no cloud AI credentials or active cloud integration.

Important files:
- `app/src/main/java/com/clipforge/ai/MainActivity.kt`: Compose UI, video import/preview, manual trim, offline analysis, suggestion approval, export.
- `VideoSilenceAnalyzer.kt`: decode video audio on Android and generate silence suggestions.
- `AudioLevelCalculator.kt`: PCM16 RMS/dBFS.
- `SilenceSuggestionEngine.kt`: convert level windows into candidate silent intervals.
- `AutoCutPlanner.kt`: **new** pure Kotlin keep-range planner for approved silent intervals.
- `app/src/test/java/com/clipforge/ai/AutoCutPlannerTest.kt`: **new** planner unit tests.
- `docs/HYBRID_AI_PLAN.md`, `docs/DEVELOPMENT_SKILLS.md`, `AGENTS.md`, `DESIGN.md`, `antislop.md`: project guidance.

## 3. What changed in this handoff revision

1. Added `AutoCutPlanner.plan(durationMs, suggestions, approved)` to produce ordered video intervals to **keep**, leaving unapproved silence untouched.
2. Added checkboxes for approving each detected silent interval. Tapping an interval still seeks preview.
3. Added an opt-in `Gunakan Smart Auto Cut saat export` checkbox, which becomes available after approval.
4. In auto-cut mode, Media3 Transformer receives a `Composition` built from a sequence of clipped `EditedMediaItem` objects, intended to join the retained intervals into one MP4. In manual mode, original single-range export remains.
5. Reset approvals when the source video changes or analysis reruns.

**Known limitation:** Android compilation and actual Media3 sequence export have **not** been tested. The exact Media3 1.5.1 API signatures and device support must be verified with Gradle and an emulator/phone. No assertion of working APK should be made yet.

## 4. Verification actually performed

- `kotlinc SilenceSuggestionEngine.kt AutoCutPlanner.kt -d /tmp/clipforge-planner.jar` **PASS**.
- MainActivity braces balanced (a basic syntax heuristic only, not compilation).
- ZIP archive validation performed when packaging (see report).
- JUnit tests **written but not executed** (Android Gradle environment unavailable here).
- Full Android Gradle build, instrumentation tests, decoder performance and MP4 export: **NOT RUN**.

## 5. Highest-priority next actions

1. Open this Android project in Android Studio with Android SDK / Gradle. Run `./gradlew testDebugUnitTest assembleDebug` (if wrapper missing, create one with a compatible Gradle installation; do not assume it exists).
2. Fix any Media3 1.5.1 API errors in `EditedMediaItemSequence`, `Composition.Builder` and `Transformer.start` based on the actual installed API.
3. Verify a video with audio, a video without audio, variable frame rate, stereo/multichannel audio, and a long recording. Ensure analyzer resource release and cancellation are safe.
4. Test manual trim regression, no-approved-cuts behavior, overlapping/adjacent cuts, clips shorter than 250 ms, empty keep-range plan, and whether the stitched output has audio/video sync.
5. Move UI state and export orchestration into ViewModel/service after functionality is validated; ensure callbacks update Compose state on main thread and handle lifecycle/cancellation.
6. Consider reviewing export clipping when users select ranges shorter than 1 second; current manual validator still enforces >=1 s before auto-cut branch.
7. Improve review UI with keep/remove timeline and total resulting duration, export progress and errors, and explicit privacy notice before future cloud uploads.
8. Only then add cloud AI via secure backend/proxy, consent, and provider-neutral interface; never embed secrets in APK.

## 6. Quality / collaboration instructions

Use JRHagents as planning/orchestration inspiration, Superpowers for incremental implementation/tests, Anti-Slop DURING for design/code quality, Agency Agents for specialist reviews, and Caveman only when useful for clear communication. These external repositories are **not** installed as Android dependencies, and this ZIP does **not** bundle them. The earlier combined agent ZIP is a separate artifact. Inspect `AGENTS.md` and `antislop.md` before modifications. Avoid claims of passing Android builds without actual logs.

## 7. Prompt to paste into another AI

> Continue ClipForge AI Studio from the attached ZIP. First read `PROJECT_HANDOFF.md`, `AGENTS.md`, `DESIGN.md`, `docs/HYBRID_AI_PLAN.md`, and the Kotlin source. Preserve current features. Verify and fix the Smart Auto Cut approve/reject + Media3 composition export path with actual Gradle tests. Do not claim APK builds passed unless executed. Work incrementally, produce updated source ZIP, changelog, and a refreshed handoff MD. Keep offline editing functional and cloud AI optional.
