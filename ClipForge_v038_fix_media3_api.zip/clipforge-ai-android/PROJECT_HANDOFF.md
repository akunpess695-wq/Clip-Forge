# ClipForge v0.3.8 — GitHub Actions Media3 compile fix

## Evidence
User-supplied GitHub Actions archive `logs_114135919177.zip` reports seven Kotlin errors, all in `GamingSplitExporter.kt`: unresolved `VideoCompositorSettings` and `StaticOverlaySettings`, mismatched compositor type, and invalid overrides.

## Changes
- Use `androidx.media3.common.VideoCompositorSettings` (already present).
- Correct `OverlaySettings` and `StaticOverlaySettings` imports to `androidx.media3.common` for the Media3 API used by this project.
- Keep `androidx.media3:media3-transformer:1.5.1`.
- Increase versionCode to 7, versionName to 0.3.8.

## Verification and limitations
- Source inspection and ZIP CRC checks performed.
- No complete Android Gradle build run in this environment (Gradle/Android SDK unavailable).
- Export behavior on device is UNVERIFIED; runtime compositing, audio and save to MediaStore must be tested.
- Re-run GitHub Actions. If compiler still fails, supply entire new logs archive.
- For APK update without uninstall, use same applicationId and signing certificate as installed APK.

## Product goals
Single-video facecam auto detect with manual drag/pinch; Gaming Split facecam 40% / gameplay 60%; subtitle off; audio-based Smart Highlight on; export 9:16 MP4 to Movies/ClipForge AI.
