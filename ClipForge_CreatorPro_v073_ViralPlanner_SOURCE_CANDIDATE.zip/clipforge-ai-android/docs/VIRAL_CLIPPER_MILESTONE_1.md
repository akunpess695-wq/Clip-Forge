# Viral Clipper — milestone 1

Pure Kotlin planner for pre-analyzed timestamped moments. Produces ranked non-overlapping 30–60-second candidate ranges, without changing videos. Score is heuristic, not a prediction of virality.

Not implemented: URL ingestion, download, transcription of long videos, visual event analysis, editor integration, preview, batch export, cloud consent and API authentication.

Next: validate Android build and unit tests; implement permitted video intake, timed analysis, review UI and batch MP4 export. Never embed API keys in APK.
