# ClipForge backlog (NOT IMPLEMENTED — notes only)

Status: updated for v0.7.2. Item 1 now has an offline implementation candidate; see `OFFLINE_SUBTITLES.md` for limits and verification. Item 3 was implemented in v0.4.1. Item 2 remains unimplemented.

## 1. Auto caption from audio
v0.7.2: offline Indonesian Whisper Tiny implementation candidate. See OFFLINE_SUBTITLES.md. Includes model download, cancellation, 60-second clip transcription, text correction, SRT saving and burn-in. Pending: live subtitle overlay preview, cue timing edits, long clips, project persistence, and subtitle/Smart Auto Cut timing remapping. The historical options below are superseded by this offline decision for the Redmi Note 12 Pro 5G target.

v0.7.2 decision: Indonesian offline transcription with Whisper Tiny multilingual, selected after the owner supplied Redmi Note 12 Pro 5G as the target phone. A 60-second range limit bounds memory. Download, cancellation, text correction, SRT saving and composition-level burn-in are implemented in source. No audio is uploaded. Timing editing, live subtitle preview, longer ranges, saved projects and subtitle/Smart Auto Cut remapping remain pending. Historical options below are retained for context, not current blockers.

Goal: generate subtitles from the clip's audio and burn them into the export.

Open decisions (owner must choose):
- Offline on-device vs cloud. AGENTS.md requires owner approval before sending footage/audio to a cloud provider, and no provider secrets inside the APK.
- Languages: Bahasa Indonesia is mandatory; English optional.

Candidate approaches (UNVERIFIED, to research):
- A. Bundled offline model (e.g. Whisper-family via whisper.cpp or sherpa-onnx). Pros: offline/private. Cons: APK size or model download (tens to hundreds of MB), slow on mid-range phones, Indonesian accuracy depends on model size.
- B. Android platform speech recognition. Cons: designed for microphone input; file/audio-source input support and offline language packs vary by Android version and device. Must test.
- C. Cloud ASR through our own backend proxy (key stays server-side). Needs consent UI, cost, internet.

Rendering (UNVERIFIED): timed text burned in via Media3 overlay effects per cue (text overlay), style presets later. Subtitle is currently OFF by product goal; make it a toggle.
Also needed: caption editing screen (fix wrong words), timing offset relative to clip start/end, safe area so text avoids platform UI.
Reference: ClipperStudio sells auto caption (ID + EN) as a paid cloud feature.

## 2. Video detection / import via URL
The request is ambiguous. Clarify with owner which one is meant:
- 2a. Direct file URL (e.g. link to .mp4): download then use the normal pipeline. Feasible in-app; needs INTERNET permission, size/format validation, progress, cancel.
- 2b. Page links (YouTube, TikTok, etc.): needs extracting the media stream. Risks: platform Terms of Service and copyright, links break often, usually needs a server-side extractor (not realistic on-device). Needs an owner/legal decision before any work.
- 2c. "Detection" could also mean auto-detecting the facecam/gameplay layout of a downloaded video (already partly exists via FaceDetector).
Reference: ClipperStudio accepts YouTube/TikTok links server-side.

## 3. Output size presets per platform — IMPLEMENTED in v0.4.1 (compile/device UNVERIFIED)
See `OutputFormat.kt`, `LayoutTemplate.layers(format)`. Remaining: presets are only used by the Gaming Split export; standard editor export is unchanged (original framing). Ratios come from third-party guides, re-verify against official platform docs before release. Original notes:
Goal: choose export aspect ratio/size for Instagram, X, Threads, TikTok, YouTube Shorts, Facebook, LinkedIn, or custom.
Facts to VERIFY before implementing (platform specs change; do a fresh lookup): recommended ratio, max resolution, max duration, bitrate per platform.
Working assumption only: 9:16 (TikTok, Reels, Shorts), 4:5 and 1:1 (feeds), 16:9 (X, YouTube, LinkedIn).
Code impact (current state):
- `GamingSplitExporter.OUTPUT_WIDTH/HEIGHT` are fixed 720x1280 and `LayoutLayer` rectangles are in pixels. Needs canvas size as a parameter and layouts defined in normalized fractions per aspect ratio.
- 1:1 and 16:9 need different split arrangements (side-by-side for 16:9, not top/bottom). Each LayoutTemplate would need per-ratio variants or a rule.
- `GamingSplitTemplate` already has aspectWidth/aspectHeight; unify with LayoutTemplate.
- Resolution choice (720p vs 1080p) affects export time/memory on phones; test.
- UI: preset picker (platform name -> ratio/resolution), plus custom.

## 4. Carry-over TODOs from v0.4.0
- Crop preview panels and two-video "PREVIEW LAYOUT" box still show 40/60 regardless of template.
- PiP templates (264x264 facecam) untested on device; check audio source (gameplay is input 0 in PiP).
- Facecam tracking: sample faces over time and move the crop smoothly (currently one static crop from one frame).
- More templates: round facecam, blurred background with centered gameplay, big facecam + small gameplay (need extra Media3 effects; higher risk).
- Verify v0.3.9 fill-with-crop result on device (no black bars; facecam framing).

## Process rule (from owner)
Every time files are delivered, also deliver an up-to-date handoff `.md` (name: `ClipForge_HANDOFF_vXXX_YYYYMMDD.md`) with: changes, evidence, what was verified vs not, limitations, next steps.
