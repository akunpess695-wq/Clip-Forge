# Offline subtitles v0.7.2

Target: Redmi Note 12 Pro 5G, ARM64 Android 10+. Device performance and transcription accuracy have not been measured.

## Use
1. Import a video and choose a 1 to 60 second range in **Potong**.
2. Open **Subtitle** and choose **Unduh model (78 MB)**. Internet is used only for this explicit model download; no footage or audio is uploaded.
3. Choose **Buat subtitle klip**. Recognition language is Indonesian. Keep ClipForge open during processing.
4. Review the text. Each **Putar** button seeks the original video to the cue. Text fields update the cues; blank text omits that cue from export.
5. Enable **Sertakan subtitle pada ekspor** to burn text into the MP4. Both single-video and two-video Gaming Split use the main video's audio, matching the existing export audio source.
6. Optionally save SRT using the Android document picker. SRT times start at zero for the current trim range.

Subtitles are rendered after the Gaming Split composition, so they are not cropped with the facecam. The normal editor also uses a composition-level overlay. The existing live video preview does not display the final overlay; inspect the exported video for placement and timing. The style is white bold text on a dark backing, above the lower edge, with width constrained to the output canvas.

## Limits and recovery
- A full transcript requires choosing a range of at most 60 seconds. Longer videos can still be imported, edited, and exported with subtitles disabled.
- Tiny multilingual is a starting point for a phone, not an accuracy guarantee. Music, game sounds, quiet speech, and overlapping speakers can cause wrong or invented words. Review the transcript.
- Text can be edited; cue timing editing and live overlay preview are future work.
- Smart Auto Cut plus enabled subtitles in the normal editor is blocked with an explanation. Disable Auto Cut or subtitles. Timing remapping across multiple kept ranges is not implemented.
- Expanding the trim outside the transcribed range is blocked when subtitles are enabled. Generate again or disable subtitles. Narrower trims clip and rebase cues.
- Subtitles are in-memory editing state. Changing video clears them. Activity recreation resets the editor, and transcripts are not a saved project; save SRT before leaving.
- Cancellation is cooperative. Native model initialization may need to finish before cancellation takes effect. It does not immediately unload an active native computation.
- Interrupted or invalid downloads are discarded. SHA-256 and exact length are checked before installation; integrity is checked again before inference. Use **Unduh ulang model** if corrupt.
- Audio is decoded from presentation timestamps, downmixed to mono and averaged into 16 kHz bins. PCM16 and PCM float are supported. Inputs below 16 kHz are rejected with an explanation. This simple resampling needs accuracy testing on real phone recordings.
- Local model storage: app-private `files/models/ggml-tiny.bin`. Removing app data removes the model.
- ARM64 APK only in this candidate. No background service or microphone permission.

## Build and dependencies
- Existing AGP 8.7.3, Kotlin 2.0.21, Media3 1.5.1.
- NDK 27.2.12479018, CMake 3.22.1, C++17, four Whisper CPU threads, GPU disabled.
- whisper.cpp v1.7.6 source archive pinned by SHA-256 `166140e9a6d8a36f787a2bd77f8f44dd64874f12dd8359ff7c1f4f9acb86202e`. CMake downloads it at build time; it is not bundled in the source ZIP.
- Model: `ggerganov/whisper.cpp/ggml-tiny.bin`, multilingual, 77,691,713 bytes, SHA-256 `be07e048e1e599ad46341c8d2a135645097a538221678b7acdd1b1919c6e1b21`. An upstream change with different bytes is rejected.
- Runtime and model MIT notices are included in APK assets under `licenses/`.
- CI explicitly installs platform 35, build tools, NDK, and CMake. Preserve the existing signing key to update installed APKs.

## Required device acceptance checks
- Download over Wi-Fi, cancel midway, retry; airplane mode transcription after a successful download.
- Indonesian speech, silence, music, unsupported audio, and a video with no audio.
- Trim starting at 10 seconds; verify words at the matching times in SRT and exported MP4.
- Shorten and expand trim after transcription; verify export protection.
- Text correction, blank cue, long cue, SRT picker cancellation, export with subtitles off.
- Single-video and two-video split, portrait/square/landscape, normal editor.
- Start detection, change video, and repeat detection: stale results must not alter the new request.
- Screen rotation, app switching, cancellation during decode/inference, and light/dark panel appearance.
- Install an update signed by the same existing keystore without removing app data.

## Sources inspected
- https://github.com/ggml-org/whisper.cpp/tree/v1.7.6
- https://huggingface.co/api/models/ggerganov/whisper.cpp/tree/main?recursive=false
- https://github.com/androidx/media/tree/1.5.1/libraries/effect
- https://github.com/androidx/media/blob/1.5.1/libraries/transformer/src/main/java/androidx/media3/transformer/Composition.java
- https://www.mi.co.id/id/product/redmi-note-12-pro-5g/specs/
