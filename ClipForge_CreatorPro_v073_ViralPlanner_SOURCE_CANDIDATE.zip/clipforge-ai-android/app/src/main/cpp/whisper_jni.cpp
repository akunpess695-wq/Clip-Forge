#include <jni.h>
#include <whisper.h>
#include <atomic>
#include <memory>
#include <vector>
#include <cstring>

struct Job { std::atomic<bool> cancelled{false}; };
static bool aborted(void * data) { return static_cast<Job *>(data)->cancelled.load(); }
static void fail(JNIEnv * env, const char * message) {
    env->ThrowNew(env->FindClass("java/lang/IllegalStateException"), message);
}
extern "C" JNIEXPORT jlong JNICALL
Java_com_clipforge_ai_WhisperNative_createJob(JNIEnv * env, jobject) {
    try { return reinterpret_cast<jlong>(new Job()); }
    catch (...) { fail(env, "Tidak cukup memori untuk subtitle."); return 0; }
}
extern "C" JNIEXPORT void JNICALL
Java_com_clipforge_ai_WhisperNative_cancelJob(JNIEnv *, jobject, jlong job) {
    reinterpret_cast<Job *>(job)->cancelled.store(true);
}
extern "C" JNIEXPORT void JNICALL
Java_com_clipforge_ai_WhisperNative_freeJob(JNIEnv *, jobject, jlong job) { delete reinterpret_cast<Job *>(job); }

extern "C" JNIEXPORT jobjectArray JNICALL
Java_com_clipforge_ai_WhisperNative_transcribe(JNIEnv * env, jobject, jlong handle, jstring path, jfloatArray input) {
    try {
        auto * job = reinterpret_cast<Job *>(handle);
        if (!job || aborted(job)) { fail(env, "Proses dibatalkan."); return nullptr; }
        const int size = env->GetArrayLength(input);
        if (size < 16000 || size > 960000) { fail(env, "Rentang audio tidak valid."); return nullptr; }
        std::vector<float> samples(size);
        env->GetFloatArrayRegion(input, 0, size, samples.data());
        if (env->ExceptionCheck()) return nullptr;
        const char * file = env->GetStringUTFChars(path, nullptr);
        if (!file) return nullptr;
        auto config = whisper_context_default_params();
        config.use_gpu = false;
        std::unique_ptr<whisper_context, decltype(&whisper_free)> ctx(
            whisper_init_from_file_with_params(file, config), whisper_free);
        env->ReleaseStringUTFChars(path, file);
        if (!ctx) { fail(env, "Model tidak dapat dimuat."); return nullptr; }
        auto p = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
        p.n_threads = 4;
        p.language = "id";
        p.translate = false;
        p.no_context = true;
        p.print_realtime = false;
        p.print_progress = false;
        p.print_timestamps = false;
        p.print_special = false;
        p.token_timestamps = true;
        p.max_len = 42;
        p.split_on_word = true;
        p.abort_callback = aborted;
        p.abort_callback_user_data = job;
        if (aborted(job) || whisper_full(ctx.get(), p, samples.data(), size) != 0) {
            fail(env, "Transkripsi gagal atau dibatalkan."); return nullptr;
        }
        jclass cue = env->FindClass("com/clipforge/ai/SubtitleCue");
        jmethodID ctor = env->GetMethodID(cue, "<init>", "(JJLjava/lang/String;)V");
        jclass stringClass = env->FindClass("java/lang/String");
        jmethodID stringCtor = env->GetMethodID(stringClass, "<init>", "([BLjava/lang/String;)V");
        jstring charset = env->NewStringUTF("UTF-8");
        const int n = whisper_full_n_segments(ctx.get());
        jobjectArray result = env->NewObjectArray(n, cue, nullptr);
        for (int i = 0; i < n && !env->ExceptionCheck(); ++i) {
            const char * text = whisper_full_get_segment_text(ctx.get(), i);
            jbyteArray bytes = env->NewByteArray(std::strlen(text));
            env->SetByteArrayRegion(bytes, 0, std::strlen(text), reinterpret_cast<const jbyte *>(text));
            auto str = env->NewObject(stringClass, stringCtor, bytes, charset);
            auto item = env->NewObject(cue, ctor,
                static_cast<jlong>(whisper_full_get_segment_t0(ctx.get(), i) * 10),
                static_cast<jlong>(whisper_full_get_segment_t1(ctx.get(), i) * 10), str);
            env->SetObjectArrayElement(result, i, item);
            env->DeleteLocalRef(bytes); env->DeleteLocalRef(str); env->DeleteLocalRef(item);
        }
        return result;
    } catch (...) { fail(env, "Mesin subtitle gagal. Coba klip lebih pendek."); return nullptr; }
}
