package com.clipforge.ai

import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun SubtitlePanel(model: SubtitleViewModel, uri: Uri?, startMs: Long, endMs: Long, locked: Boolean,
    textColor: Color, onSave: () -> Unit, onSeek: (Long) -> Unit) {
    Text("Bahasa Indonesia • Offline", color = textColor)
    Text(model.note, color = textColor, style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(8.dp))
    if (model.busy) {
        LinearProgressIndicator(Modifier.fillMaxWidth())
        TextButton(onClick = model::cancel) { Text("Batalkan") }
    } else {
        if (!model.modelReady) Button(onClick = model::download, enabled = !locked) { Text("Unduh model (78 MB)") }
        else {
            Button(onClick = { uri?.let { model.generate(it, startMs, endMs) } }, enabled = uri != null && !locked) {
                Text(if (model.cues.isEmpty()) "Buat subtitle klip" else "Buat ulang subtitle")
            }
            TextButton(onClick = model::download, enabled = !locked) { Text("Unduh ulang model") }
        }
    }
    if (model.cues.isNotEmpty()) {
        Row(Modifier.fillMaxWidth()) {
            Checkbox(checked = model.enabled, onCheckedChange = { model.enabled = it }, enabled = !locked && !model.busy)
            Text("Sertakan subtitle pada ekspor", modifier = Modifier.weight(1f).padding(top = 12.dp), color = textColor)
        }
        TextButton(onClick = onSave, enabled = !locked && !model.busy) { Text("Simpan subtitle SRT") }
        Text("Koreksi teks di bawah. Tombol Putar menuju waktu subtitle. Posisi akhir terlihat pada hasil ekspor.", color = textColor, style = MaterialTheme.typography.bodySmall)
        model.cues.forEachIndexed { index, cue ->
            TextButton(onClick = { onSeek(cue.startMs) }, enabled = !locked) {
                Text("${index + 1}. ${cue.startMs / 1000}s – ${cue.endMs / 1000}s · Putar")
            }
            OutlinedTextField(value = cue.text, onValueChange = { model.edit(index, it.take(240)) },
                enabled = !locked && !model.busy, label = { Text("Teks subtitle ${index + 1}") },
                modifier = Modifier.fillMaxWidth(), minLines = 1, maxLines = 4,
                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = textColor, unfocusedTextColor = textColor))
        }
    }
}
