package com.clipforge.ai

import java.util.Locale

/** Times are milliseconds on the original video's timeline. */
data class SubtitleCue(val startMs: Long, val endMs: Long, val text: String)

object SubtitleTimeline {
    fun trim(cues: List<SubtitleCue>, startMs: Long, endMs: Long): List<SubtitleCue> =
        cues.mapNotNull { cue ->
            val a = maxOf(cue.startMs, startMs)
            val b = minOf(cue.endMs, endMs)
            if (b <= a || cue.text.isBlank()) null else SubtitleCue(a - startMs, b - startMs, cue.text.trim())
        }.sortedBy { it.startMs }

    fun textAt(cues: List<SubtitleCue>, timeMs: Long): String =
        cues.firstOrNull { timeMs >= it.startMs && timeMs < it.endMs }?.text.orEmpty()

    fun srt(cues: List<SubtitleCue>): String = cues.mapIndexed { i, cue ->
        "${i + 1}\n${stamp(cue.startMs)} --> ${stamp(cue.endMs)}\n${cue.text.replace(Regex("[\\r\\n]+"), " ")}\n"
    }.joinToString("\n")

    private fun stamp(ms: Long): String = String.format(Locale.ROOT, "%02d:%02d:%02d,%03d",
        ms / 3_600_000, ms / 60_000 % 60, ms / 1000 % 60, ms % 1000)
}
