package com.clipforge.ai

import android.app.Application
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.CancellationException
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class SubtitleViewModel(app: Application) : AndroidViewModel(app) {
    var cues by mutableStateOf<List<SubtitleCue>>(emptyList()); private set
    var enabled by mutableStateOf(false)
    var busy by mutableStateOf(false); private set
    var note by mutableStateOf("Unduh model sekali (78 MB). Audio diproses di HP."); private set
    var modelReady by mutableStateOf(modelFile().isFile); private set
    var source: Uri? = null; private set
    var rangeStart = 0L; private set
    var rangeEnd = 0L; private set
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val cancelled = AtomicBoolean(false)
    private var generation = 0
    private var cleared = false
    private var nativeJob = 0L
    private val lock = Any()

    private fun modelFile() = File(getApplication<Application>().filesDir, "models/ggml-tiny.bin")
    private fun checkCancelled() { if (cancelled.get()) throw CancellationException() }
    fun reset(uri: Uri?) {
        if (source == uri) return
        cancel()
        generation++
        source = uri
        cues = emptyList()
        enabled = false
        rangeStart = 0
        rangeEnd = 0
    }
    fun edit(index: Int, text: String) { cues = cues.mapIndexed { i, cue -> if (i == index) cue.copy(text = text) else cue } }
    fun cancel() {
        cancelled.set(true)
        synchronized(lock) { if (nativeJob != 0L) WhisperNative.cancelJob(nativeJob) }
        if (busy) note = "Membatalkan proses…"
    }
    private fun work(action: (Int) -> Unit) {
        if (busy) return
        busy = true
        cancelled.set(false)
        val token = generation
        executor.execute {
            try { action(token) }
            catch (_: CancellationException) { publish(token) { note = "Proses dibatalkan." } }
            catch (e: Exception) {
                val message = if (cancelled.get()) "Proses dibatalkan." else "Gagal: ${e.localizedMessage ?: "proses tidak berhasil"}"
                publish(token) { note = message }
            }
            catch (_: LinkageError) { publish(token) { note = "Mesin subtitle tidak tersedia. Pasang APK arm64 hasil build terbaru." } }
            finally { main.post { if (!cleared) { busy = false; modelReady = modelFile().isFile } } }
        }
    }
    private fun publish(token: Int, action: () -> Unit) { main.post { if (!cleared && token == generation) action() } }
    fun download() = work { token ->
        val target = modelFile()
        target.parentFile!!.mkdirs()
        val temp = File(target.parentFile, "tiny.download")
        val connection = URL("https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-tiny.bin").openConnection() as HttpURLConnection
        connection.connectTimeout = 20_000
        connection.readTimeout = 20_000
        try {
            require(connection.responseCode == 200) { "Unduhan model: HTTP ${connection.responseCode}" }
            val digest = MessageDigest.getInstance("SHA-256")
            var total = 0L
            var lastPercent = -1
            connection.inputStream.use { input -> temp.outputStream().use { output ->
                val bytes = ByteArray(64 * 1024)
                while (true) {
                    checkCancelled()
                    val count = input.read(bytes)
                    if (count < 0) break
                    total += count
                    require(total <= 77_691_713L) { "Ukuran model tidak sesuai." }
                    output.write(bytes, 0, count)
                    digest.update(bytes, 0, count)
                    val percent = (total * 100 / 77_691_713L).toInt()
                    if (percent != lastPercent) { lastPercent = percent; publish(token) { note = "Mengunduh model: $percent%" } }
                }
            } }
            checkCancelled()
            require(total == 77_691_713L && digest.digest().joinToString("") { "%02x".format(it) } == MODEL_SHA256) { "Verifikasi model gagal. Coba unduh lagi." }
            require(temp.renameTo(target)) { "Model tidak dapat disimpan." }
            publish(token) { modelReady = true; note = "Model siap. Pilih klip 1 sampai 60 detik, lalu buat subtitle." }
        } finally { connection.disconnect(); temp.delete() }
    }
    fun generate(uri: Uri, startMs: Long, endMs: Long) {
        if (busy) return
        if (endMs - startMs !in 1000L..60_000L) { note = "Pilih rentang 1 sampai 60 detik melalui Potong."; return }
        if (!modelFile().isFile) { modelReady = false; note = "Unduh model terlebih dahulu."; return }
        source = uri
        work { token ->
            publish(token) { note = "Membaca audio klip…" }
            val samples = SubtitleAudioDecoder.decode(getApplication(), uri, startMs, endMs, ::checkCancelled)
            checkCancelled()
            // Recheck file integrity before passing downloaded bytes to the native parser.
            val digest = MessageDigest.getInstance("SHA-256")
            modelFile().inputStream().use { input ->
                val bytes = ByteArray(64 * 1024)
                while (true) { checkCancelled(); val n = input.read(bytes); if (n < 0) break; digest.update(bytes, 0, n) }
            }
            require(digest.digest().joinToString("") { "%02x".format(it) } == MODEL_SHA256) { "Model rusak. Unduh ulang model." }
            publish(token) { note = "Mengenali ucapan Bahasa Indonesia…" }
            val job = synchronized(lock) { checkCancelled(); WhisperNative.createJob().also { nativeJob = it } }
            try {
                val result = WhisperNative.transcribe(job, modelFile().absolutePath, samples)
                checkCancelled()
                val cleaned = SubtitleTimeline.trim(result.toList(), 0, endMs - startMs)
                    .map { it.copy(startMs = it.startMs + startMs, endMs = it.endMs + startMs) }
                publish(token) {
                    cues = cleaned; rangeStart = startMs; rangeEnd = endMs
                    enabled = cues.isNotEmpty()
                    note = if (cues.isEmpty()) "Tidak ada ucapan terdeteksi." else "${cues.size} subtitle dibuat. Periksa dan koreksi teks sebelum ekspor."
                }
            } finally { synchronized(lock) { nativeJob = 0L; WhisperNative.freeJob(job) } }
        }
    }
    override fun onCleared() {
        cleared = true
        cancel()
        executor.shutdown()
        super.onCleared()
    }
    companion object { private const val MODEL_SHA256 = "be07e048e1e599ad46341c8d2a135645097a538221678b7acdd1b1919c6e1b21" }
}
