package com.clipforge.ai

/** Ranks pre-analyzed moments without modifying the source video. */
data class ViralMoment(val startMs: Long, val endMs: Long, val transcript: String, val energy: Double = 0.0)
data class ViralClip(val startMs: Long, val endMs: Long, val score: Int)

object ViralClipPlanner {
    private val hooks = listOf("ternyata", "kenapa", "rahasia", "jangan", "gila", "serius", "why", "secret", "never", "wait")
    fun rank(durationMs: Long, moments: List<ViralMoment>, maxClips: Int = 5,
             minClipMs: Long = 30_000L, maxClipMs: Long = 60_000L): List<ViralClip> {
        require(durationMs > 0 && maxClips > 0 && minClipMs > 0 && maxClipMs >= minClipMs)
        if (durationMs < minClipMs) return emptyList()
        val length = minOf(durationMs, maxClipMs)
        val candidates = moments.mapNotNull { m ->
            if (m.startMs < 0 || m.endMs <= m.startMs || m.endMs > durationMs || !m.energy.isFinite()) return@mapNotNull null
            val center = m.startMs + (m.endMs - m.startMs) / 2
            val start = (center - length / 2).coerceIn(0L, durationMs - length)
            val words = m.transcript.lowercase().split(Regex("[^\\p{L}]+"))
            val hookCount = hooks.count { it in words }
            val score = (20 + hookCount.coerceAtMost(3) * 15 + m.energy.coerceIn(0.0, 1.0) * 35 +
                (if (m.transcript.length >= 40) 10 else 0)).toInt().coerceIn(0, 100)
            ViralClip(start, start + length, score)
        }.sortedWith(compareByDescending<ViralClip> { it.score }.thenBy { it.startMs })
        val selected = mutableListOf<ViralClip>()
        for (candidate in candidates) {
            if (selected.none { candidate.startMs < it.endMs && it.startMs < candidate.endMs }) {
                selected += candidate
                if (selected.size == maxClips) break
            }
        }
        return selected
    }
}
