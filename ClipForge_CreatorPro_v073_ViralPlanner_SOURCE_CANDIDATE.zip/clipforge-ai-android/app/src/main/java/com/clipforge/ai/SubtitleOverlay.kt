package com.clipforge.ai

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.transformer.Effects

@OptIn(UnstableApi::class)
class SubtitleOverlay(private val cues: List<SubtitleCue>) : BitmapOverlay() {
    private var width = 640
    private var fontSize = 28f
    private var lastText: String? = null
    private var bitmap: Bitmap? = null
    override fun configure(videoSize: Size) {
        super.configure(videoSize)
        width = (videoSize.width * 0.86f).toInt().coerceAtLeast(1)
        fontSize = minOf(videoSize.width, videoSize.height) * 0.045f
        lastText = null
    }
    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val text = SubtitleTimeline.textAt(cues, presentationTimeUs / 1000)
        if (text == lastText && bitmap != null) return bitmap!!
        lastText = text
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = fontSize
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        val padding = (fontSize * 0.4f).toInt().coerceAtLeast(2)
        val layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, (width - 2 * padding).coerceAtLeast(1))
            .setAlignment(Layout.Alignment.ALIGN_CENTER).setIncludePad(true).build()
        val next = Bitmap.createBitmap(width, (layout.height + 2 * padding).coerceAtLeast(1), Bitmap.Config.ARGB_8888)
        if (text.isNotEmpty()) {
            val canvas = Canvas(next)
            canvas.drawColor(0xD9000000.toInt())
            canvas.translate(padding.toFloat(), padding.toFloat())
            layout.draw(canvas)
        }
        bitmap?.recycle()
        bitmap = next
        return next
    }
    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings = OverlaySettings.Builder()
        .setOverlayFrameAnchor(0f, -1f).setBackgroundFrameAnchor(0f, -0.72f).build()
    override fun release() { super.release(); bitmap?.recycle(); bitmap = null }
    companion object {
        fun effects(cues: List<SubtitleCue>): Effects = Effects(emptyList(),
            if (cues.isEmpty()) emptyList() else listOf(OverlayEffect(listOf(SubtitleOverlay(cues)))))
    }
}
