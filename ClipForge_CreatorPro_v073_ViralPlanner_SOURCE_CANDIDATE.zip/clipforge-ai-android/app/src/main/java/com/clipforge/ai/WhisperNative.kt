package com.clipforge.ai

internal object WhisperNative {
    init { System.loadLibrary("clipforge_whisper") }
    external fun createJob(): Long
    external fun cancelJob(job: Long)
    external fun freeJob(job: Long)
    external fun transcribe(job: Long, path: String, samples: FloatArray): Array<SubtitleCue>
}
