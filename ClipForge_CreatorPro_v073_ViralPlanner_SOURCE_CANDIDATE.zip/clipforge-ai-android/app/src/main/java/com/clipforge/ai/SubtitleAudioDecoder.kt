package com.clipforge.ai

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder

/** Bounded 16 kHz mono buffer, placed by audio presentation timestamps, including gaps. */
object SubtitleAudioDecoder {
    fun decode(context: Context, uri: Uri, startMs: Long, endMs: Long, check: () -> Unit): FloatArray {
        require(startMs >= 0 && endMs - startMs in 1000L..60_000L) { "Pilih klip 1 sampai 60 detik." }
        val samples = FloatArray(((endMs - startMs) * 16).toInt())
        val sums = DoubleArray(samples.size)
        val counts = IntArray(samples.size)
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        var foundSamples = false
        try {
            extractor.setDataSource(context, uri, null)
            val track = (0 until extractor.trackCount).firstOrNull {
                extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            } ?: error("Video tidak memiliki audio.")
            extractor.selectTrack(track)
            extractor.seekTo(startMs * 1000, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            val format = extractor.getTrackFormat(track)
            val decoder = MediaCodec.createDecoderByType(format.getString(MediaFormat.KEY_MIME)!!)
            codec = decoder
            decoder.configure(format, null, null, 0)
            decoder.start()
            var rate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var encoding = AudioFormat.ENCODING_PCM_16BIT
            var inputDone = false
            var done = false
            var idle = 0
            val info = MediaCodec.BufferInfo()
            while (!done) {
                check()
                if (!inputDone) {
                    val index = decoder.dequeueInputBuffer(10_000)
                    if (index >= 0) {
                        val buffer = decoder.getInputBuffer(index)!!
                        buffer.clear()
                        val pts = extractor.sampleTime
                        val size = if (pts < 0 || pts >= endMs * 1000) -1 else extractor.readSampleData(buffer, 0)
                        if (size < 0) {
                            decoder.queueInputBuffer(index, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            decoder.queueInputBuffer(index, 0, size, pts, 0)
                            extractor.advance()
                        }
                    }
                }
                when (val index = decoder.dequeueOutputBuffer(info, 10_000)) {
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val f = decoder.outputFormat
                        rate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        encoding = if (f.containsKey(MediaFormat.KEY_PCM_ENCODING)) f.getInteger(MediaFormat.KEY_PCM_ENCODING) else AudioFormat.ENCODING_PCM_16BIT
                        require(rate >= 16000 && channels > 0) { "Audio minimal 16 kHz diperlukan." }
                        require(encoding == AudioFormat.ENCODING_PCM_16BIT || encoding == AudioFormat.ENCODING_PCM_FLOAT) { "Format PCM tidak didukung." }
                    }
                    in 0..Int.MAX_VALUE -> {
                        idle = 0
                        try {
                            val b = decoder.getOutputBuffer(index)!!
                            b.position(info.offset)
                            b.limit(info.offset + info.size)
                            b.order(ByteOrder.nativeOrder())
                            val bytes = if (encoding == AudioFormat.ENCODING_PCM_FLOAT) 4 else 2
                            val frames = info.size / bytes / channels
                            repeat(frames) { frame ->
                                var mono = 0.0
                                repeat(channels) { mono += if (bytes == 4) b.float.toDouble() else b.short.toDouble() / 32768.0 }
                                val timeUs = info.presentationTimeUs + frame.toLong() * 1_000_000 / rate - startMs * 1000
                                if (timeUs >= 0) {
                                    val dst = (timeUs * 16000 / 1_000_000).toInt()
                                    if (dst in samples.indices) {
                                        sums[dst] += mono / channels
                                        counts[dst]++
                                        foundSamples = true
                                    }
                                }
                            }
                            done = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        } finally { decoder.releaseOutputBuffer(index, false) }
                    }
                    else -> { if (++idle > 500) error("Decoder audio tidak merespons.") }
                }
            }
            require(foundSamples) { "Tidak ada audio pada rentang yang dipilih." }
            for (i in samples.indices) if (counts[i] > 0) samples[i] = (sums[i] / counts[i]).toFloat().coerceIn(-1f, 1f)
            return samples
        } finally {
            runCatching { codec?.stop() }
            codec?.release()
            extractor.release()
        }
    }
}
