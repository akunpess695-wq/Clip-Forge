package com.clipforge.ai
import org.junit.Assert.*
import org.junit.Test
class ViralClipPlannerTest {
    @Test fun shortVideoReturnsNoClips() = assertTrue(ViralClipPlanner.rank(20_000, emptyList()).isEmpty())
    @Test fun selectsNonOverlappingClips() {
        val result = ViralClipPlanner.rank(150_000, listOf(
            ViralMoment(10_000, 15_000, "kenapa ternyata", 0.8),
            ViralMoment(20_000, 25_000, "rahasia", 0.9),
            ViralMoment(90_000, 95_000, "serius", 0.7)))
        assertEquals(2, result.size)
        assertTrue(result.all { it.endMs - it.startMs in 30_000L..60_000L })
        assertTrue(result[0].endMs <= result[1].startMs || result[1].endMs <= result[0].startMs)
    }
    @Test fun invalidMomentsIgnored() {
        val result = ViralClipPlanner.rank(90_000, listOf(
            ViralMoment(-1, 10_000, "why"), ViralMoment(20_000, 21_000, "never", Double.NaN),
            ViralMoment(45_000, 50_000, "why", 99.0)))
        assertEquals(1, result.size)
        assertTrue(result[0].score in 0..100)
    }
    @Test(expected = IllegalArgumentException::class) fun invalidRangeRejected() {
        ViralClipPlanner.rank(90_000, emptyList(), minClipMs = 60_000, maxClipMs = 30_000)
    }
}
