package com.clipforge.ai

import org.junit.Assert.*
import org.junit.Test

class SubtitleTimelineTest {
    @Test fun clipsBoundariesAndRebasesNonzeroTrim() {
        val cues = listOf(SubtitleCue(9000, 11000, " awal "), SubtitleCue(12000, 14000, "akhir"), SubtitleCue(14000, 15000, "luar"))
        assertEquals(listOf(SubtitleCue(0, 1000, "awal"), SubtitleCue(2000, 3000, "akhir")), SubtitleTimeline.trim(cues, 10000, 13000))
    }
    @Test fun blankEditsAndOutsideCuesAreOmitted() {
        assertTrue(SubtitleTimeline.trim(listOf(SubtitleCue(0, 1000, "x"), SubtitleCue(1000, 2000, "  ")), 1000, 2000).isEmpty())
    }
    @Test fun endBoundaryIsExclusive() {
        val cues = listOf(SubtitleCue(10, 20, "a"), SubtitleCue(20, 30, "b"))
        assertEquals("", SubtitleTimeline.textAt(cues, 9))
        assertEquals("a", SubtitleTimeline.textAt(cues, 10))
        assertEquals("b", SubtitleTimeline.textAt(cues, 20))
        assertEquals("", SubtitleTimeline.textAt(cues, 30))
    }
    @Test fun srtHasMillisecondsAndNoAccidentalBlankCueBreaks() {
        assertEquals("1\n01:02:03,004 --> 01:02:04,005\nhalo dunia\n",
            SubtitleTimeline.srt(listOf(SubtitleCue(3723004, 3724005, "halo\n\ndunia"))))
    }
}
