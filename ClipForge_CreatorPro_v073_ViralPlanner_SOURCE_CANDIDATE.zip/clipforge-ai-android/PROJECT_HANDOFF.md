# ClipForge v0.4.0 — GitHub Actions Media3 compile fix

## Evidence
User-supplied GitHub Actions archive `logs_114135919177.zip` reports seven Kotlin errors, all in `GamingSplitExporter.kt`: unresolved `VideoCompositorSettings` and `StaticOverlaySettings`, mismatched compositor type, and invalid overrides.

## Changes
- Use `androidx.media3.common.VideoCompositorSettings` (already present).
- Correct `OverlaySettings` and `StaticOverlaySettings` imports to `androidx.media3.common` for the Media3 API used by this project.
- Keep `androidx.media3:media3-transformer:1.5.1`.
- Increase versionCode to 7, versionName to 0.4.0.

## Verification and limitations
- Source inspection and ZIP CRC checks performed.
- No complete Android Gradle build run in this environment (Gradle/Android SDK unavailable).
- Export behavior on device is UNVERIFIED; runtime compositing, audio and save to MediaStore must be tested.
- Re-run GitHub Actions. If compiler still fails, supply entire new logs archive.
- For APK update without uninstall, use same applicationId and signing certificate as installed APK.

## Product goals
Single-video facecam auto detect with manual drag/pinch; Gaming Split facecam 40% / gameplay 60%; subtitle off; audio-based Smart Highlight on; export 9:16 MP4 to Movies/ClipForge AI.

## v0.4.0 — Layout templates
- `LayoutTemplate.kt`: data-driven layouts (layers in draw order, 720x1280 canvas): FACE_TOP_40 (default), FACE_TOP_50, FACE_BOTTOM_40, PIP_TOP_RIGHT, PIP_TOP_LEFT.
- `GamingSplitExporter.composition(..., layout, ...)` builds one sequence per layer; overlay anchor comes from the layer rect. Layers use LAYOUT_SCALE_TO_FIT_WITH_CROP (no black bars).
- UI: template radio list with schematic thumbnails in Template Editor. The two crop-preview panels and the two-video "PREVIEW LAYOUT" box still show the 40/60 stack regardless of template (UNVERIFIED/TODO: make them template-aware).
- UNVERIFIED on device: PIP templates (overlay size/position at 264x264), audio source with PIP (gameplay is input 0 there), save to MediaStore.

## Backlog
Planned, not implemented: auto caption from audio, URL video import/detection, per-platform output size presets. Details and open questions in `docs/BACKLOG.md`.

## v0.4.1 — Platform size presets
- `OutputFormat.kt`: canvases 9:16 (720x1280), 4:5 (720x900), 1:1 (720x720), 16:9 (1280x720). `PlatformPreset`: TikTok, IG Reels/Story, YouTube Shorts, Threads (9:16); IG Feed, Facebook/LinkedIn Feed (4:5); X square (1:1); X landscape, YouTube landscape (16:9).
- `LayoutTemplate.layers(format)`: split templates stack top/bottom on portrait/square, side by side on 16:9; PiP scales with the short side. 9:16 geometry is identical to v0.4.0.
- `GamingSplitExporter.composition(..., layout, format, ...)` takes the canvas from the format.
- UI: horizontal platform chips above the template list; thumbnails follow the chosen ratio.
- Scope: Gaming Split export only. Not verified: Gradle build, on-device export for 4:5, 1:1, 16:9.

## v0.4.2 — Creator Pro UI merged onto v0.4.1 code
- Root cause of the failing "CreatorPro v0.3.8" candidate (ChatGPT): its exporter was the old v0.3.7 code (`androidx.media3.effect.StaticOverlaySettings` does not exist in Media3 1.5.1; `android.util.Size` is not the type `VideoCompositorSettings` uses). Its changes were UI-only, so the compile error was never touched.
- Fix: kept all code from v0.4.1 (Media3 1.5.1 API fixes: `OverlaySettings.Builder()`, `androidx.media3.common.util.Size`; fill-with-crop; layout templates; platform presets) and applied the Creator Pro UI diff (palette, 3-step wording, collapsible "Atur layout" and "Smart Auto Cut" panels, Gaming Split on by default) via `patch`; no rejected hunks.
- The "Atur layout" button label is now dynamic (template + ratio) instead of hard-coded "40:60".
- UI badge: "CREATOR PRO • v0.4.2". versionCode 13, versionName 0.4.2.
- UNVERIFIED: Gradle compile and on-device behavior (no SDK here). v0.4.1 had not been confirmed compiling by the owner before this merge; if the build fails, send the full log.

## v0.5.1 — Thread-safe preview frame sampling (candidate, NOT built/tested)
- Root-cause hypothesis (unconfirmed on device): v0.4.7–0.5.0 read `player.currentPosition` inside `withContext(Dispatchers.IO)`. ExoPlayer must be used from its application thread (main); Media3 1.5.1 throws on wrong-thread access by default, and the generic catch turned that into "frame extraction failed". Evidence: v0.5.0 screenshot shows the fallback warning while playback/timeline run.
- Fix: the sampling loop now reads the player on the main dispatcher; only MediaMetadataRetriever work runs on IO. Frame size is derived from real video width/height/rotation (long side ≤1280, aspect kept) instead of forcing 720x1280. Per-iteration failure no longer kills the loop; 3 consecutive null frames mark failure.
- Diagnostics: the on-screen fallback warning now appends the exception class/message (or "decoder tidak mengembalikan frame"). If the split preview still does not appear, send a screenshot of that line.
- versionCode 22, versionName 0.5.1, badge "CREATOR PRO · v0.5.1". applicationId unchanged. No changes to GamingSplitExporter.kt / export pipeline.
- NOT verified: Gradle compile, unit tests, device run. Static brace/paren balance check only.
- Install conflict seen 2026-11-06 20:26 ("paket ini bentrok dengan paket yang sudah ada") for app-debug.apk 0.5.0: same applicationId but different signing certificate than the installed build. Needs a persistent keystore (GitHub Actions secrets); no workflow file is included in this ZIP.

## v0.6.0 — Live cropped split preview (candidate, NOT built/tested)
- Evidence (user screen recording 2026-11-06 20:44, 13.8 s): the v0.5.x split preview rendered but updated only 3 times (≈4.8 s, 8.6 s, 12.4 s) while the timeline ran. Cause: `MediaMetadataRetriever.getScaledFrameAtTime(..., OPTION_CLOSEST_SYNC)` returns keyframes only (~3.8 s GOP in that clip). The same recording also shows the default facecam crop (top-right) landing on the wrong area; the face is bottom-right.
- Change: removed periodic frame sampling. Single-video Gaming Split preview now uses two ExoPlayers on the same file: the main player (audio/controls/timeline) renders the gameplay panel; a second muted player renders the facecam panel. Each renders into a `TextureView` sized/offset by `CropViewport.compute(...)` so only its crop is visible (center-crop, aspect preserved). A main-thread loop (150 ms playing / 100 ms paused) mirrors playWhenReady and re-seeks the second player when drift >250 ms (playing) or >40 ms (paused), and reads the real video size from `Player.videoSize`.
- Templates handled in preview: FACE_TOP_40/50, FACE_BOTTOM_40, PIP_TOP_LEFT/RIGHT, platform aspect ratio. Two-video mode still uses its existing separate preview boxes.
- While fullscreen is open, the inline preview is not composed (only one view owns the player's video surface); it re-attaches on close.
- New: `CropViewport.kt` (pure math) + `CropViewportTest.kt`. versionCode 23, versionName 0.6.0, badge v0.6.0. No change to GamingSplitExporter.kt / export; applicationId unchanged.
- NOT verified: Gradle compile (e.g. `onRelease` in AndroidView, `BoxWithConstraints` early return, `Player.videoSize`), unit tests, on-device smoothness, A/V drift of the second player, double-decoder load on the user's phone, fullscreen surface hand-off, preview/export parity.
- Known issues (unchanged): default facecam crop is top-right (`NormalizedCrop.DEFAULT_FACECAM`) — Auto Detect not run automatically; gameplay crop is the full frame so the facecam also shows in the bottom panel; inline preview box is 225 dp high, so the 9:16 area is small; signing/install conflict (see v0.5.1); no `.github` workflow in the ZIP.

## v0.7.0 — CapCut-style tool dock (candidate, NOT built/tested)
- User feedback (2026-11-06 20:57 screenshot): the v0.6.0 live crop preview works ("berhasil"). Request: menus such as Layout must not live in a page that scrolls down; tapping a feature should open it, referencing CapCut (bottom icon toolbar → tool opens → back).
- Editor screen restructured in `MainActivity.kt`: the old tab row (Potong/Layout/Auto Cut), the "Layout ▾" dropdown and the vertically scrolling panel column were replaced by a dock below the timeline: a horizontally scrollable icon toolbar (Potong, Layout, Format, Facecam, Auto Cut). Tapping a tool replaces the toolbar with a compact panel (max 280 dp) with a back arrow (also the system Back button via `BackHandler`) and a ✓. State: `activeTool`.
- Panels: Potong (range slider); Layout (Gaming Split / Video Biasa chips + horizontal template cards with thumbnails); Format (platform preset chips); Facecam (Satu/Dua video chips, Auto Detect, facecam/gameplay crop sliders in compact rows; two-video mode keeps picker, mini facecam preview and Play/Pause both); Auto Cut (analysis, Smart Highlight, suggestions — same logic as before).
- The preview is now `weight(1f)` (min 160 dp) instead of a fixed 225 dp, so it grows when no panel is open and shrinks when one is. The large duplicate "Export Video" card was removed from Potong; the top-bar Ekspor button remains. Status text shows above the dock only while exporting or on errors/completion.
- Removed: the "PREVIEW LAYOUT 9:16" box in two-video mode (replaced by a small facecam preview). Unused state vars (`editorPanel`, `showLayoutSettings`, `showSmartCut`, `showAdvancedCrop`) are left declared.
- New helper composables: `ToolItem`, `CropSliderRow`. versionCode 24, versionName 0.7.0, badge v0.7.0. Export pipeline untouched.
- NOT verified: Gradle compile (icons ViewAgenda/AspectRatio/Face, `FilterChip`, `AutoMirrored.ArrowBack`), layout on small screens (dock max height vs preview min height), Back-button behavior, two-video mode.
- Still open from v0.6.0: default facecam crop (top-right) is wrong for the user's clip — in the 20:57 screenshot the top panel again shows a wrong region; run Auto Detect or adjust sliders. Suggested next: auto-run detection on load / bottom-right fallback.

## v0.7.1 — Auto Detect on load + stable signing workflow (candidate, NOT built/tested)
- `MainActivity.kt`: `runFacecamDetect(uri)` runs automatically after a video loads (single-video mode) and from the Auto Detect button; stale results are dropped if the video changed.
- `app/build.gradle.kts`: versionCode 25 / 0.7.1; debug build type signs with env keystore (`CLIPFORGE_KEYSTORE_PATH` etc.) when present.
- New `.github/workflows/build.yml` (prints the source it builds, runs tests + assembleDebug, prints signing SHA-256, uploads APK). Setup: `docs/APK_UPDATE_AND_SIGNING.md`.
- DEFAULT_FACECAM unchanged. Export pipeline untouched. NOT verified: Gradle compile, tests, device, workflow run, in-place update.
- Full detail: `ClipForge_HANDOFF_v071_20261106.md`.


## v0.7.2 offline subtitles
See ClipForge_HANDOFF_v072_20261106.md and docs/OFFLINE_SUBTITLES.md. Android build and 42 unit tests passed. Real-device tests are pending.
