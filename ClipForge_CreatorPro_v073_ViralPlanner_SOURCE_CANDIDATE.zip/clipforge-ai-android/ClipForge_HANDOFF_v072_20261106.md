# ClipForge Creator Pro v0.7.2, offline subtitles
Date: 2026-11-06
Status: BUILD VERIFIED / DEVICE TEST PENDING. This is a test candidate, not a device-validated release.
Baseline: v0.7.1 AutoDetectSigning source supplied by the owner.
Target phone: Redmi Note 12 Pro 5G. Offline mode was inferred from the owner's phone reply and stated in the conversation.

## Delivered
- ClipForge_v072_arm64_TEST.apk: package com.clipforge.ai, versionCode 26, versionName 0.7.2, minSdk 29, ARM64 only.
- ClipForge_CreatorPro_v072_OfflineSubtitles_SOURCE_CANDIDATE.zip: source, tests, CI workflow, third-party notices and this handoff.
- ClipForge_HANDOFF_v072_20261106.md.

## Features implemented
- Subtitle tool in the existing editor dock, Indonesian offline transcription using whisper.cpp v1.7.6 and multilingual Whisper Tiny.
- Explicit one-time model download (77,691,713 bytes, about 78 MB), progress, cancellation, exact length and SHA-256 validation, atomic final installation.
- Audio extraction from the chosen 1 to 60 second clip, PCM16/float downmix and timestamp-aware conversion to 16 kHz mono.
- Four CPU threads, bounded audio memory, JNI context released after every transcription. No audio or video upload.
- Correctable cue text, seek-to-cue buttons, optional SRT saving through the system picker.
- Optional subtitle burn-in after full Gaming Split composition, and in normal editor export. Cues are clipped and rebased for nonzero trim starts.
- Export protection for uncovered trim ranges and unsupported Smart Auto Cut/subtitle combinations.

## Fixes
- Facecam detection request generations prevent stale results from changing the active request's busy state or crop, including repeated requests for the same URI.
- New videos reset default facecam and gameplay crops rather than inheriting old manual crops when detection finds no face.
- CI signing secrets pass through environment variables rather than direct shell-source interpolation.
- A configured but missing keystore or incomplete signing environment now fails the build, rather than silently falling back to a different key.
- CI explicitly installs native toolchain dependencies.

## Evidence
| Check | Result |
|---|---|
| Gradle 8.9, JDK 17, AGP 8.7.3, Kotlin 2.0.21 | testDebugUnitTest assembleDebug BUILD SUCCESSFUL, 57 seconds, 43 tasks executed |
| Android Gradle JUnit XML | 42 tests, 0 failures, 0 errors, 0 skipped |
| Subtitle regression tests | 4 tests cover nonzero trim, clipped boundaries, blank cues, end-exclusive lookup and SRT milliseconds |
| Android native engine | CMake/NDK build passed for arm64-v8a; JNI library present in APK |
| APK metadata | aapt reports versionName 0.7.2, versionCode 26, package com.clipforge.ai |
| APK signature | apksigner verify passed, v2 signature |
| Device run / microphone / real-video transcript | NOT RUN; no phone/emulator attached |
| Subtitle accuracy, export sync, live UI appearance | NOT VERIFIED ON DEVICE |
| In-place update over owner's installed app | NOT VERIFIED; owner's old keystore was not supplied |

Build warnings are deprecations and pre-existing ineffective @OptIn annotations for Java Media3 UnstableApi. Compilation completed without errors. The earlier build of baseline integration is not used as evidence for this final APK; final output metadata and native contents were inspected separately.

APK SHA-256: b8e2022693f1faa0e18d3b9415efea4c28351dedb76f0494007c6f92bc2eb238
Signer SHA-256: c4fea69ac0eb558478d84fb9fecbfa25629cb2456764771d886cdd4628b9242d

## Installation and signing
The provided APK uses this environment's Android debug certificate. It may conflict with the installed APK if the certificates differ. To retain the installed app and its data, build the source with the original signing keystore via the existing CI secrets. Do not assume this APK can update the owner's current install. Do not uninstall without backing up anything important.

## Limits
- Tiny model accuracy is unmeasured on Indonesian gaming audio. Review all text; music and overlapping voices can cause wrong or invented words.
- One transcription covers at most 60 seconds; longer input videos still work when a shorter range is selected.
- No live overlay preview or cue timing editor yet; text edits and cue-seek controls are available. Inspect final placement in the exported MP4.
- Smart Auto Cut with subtitles in normal editor is blocked, not silently mis-timed.
- Subtitle text is in-memory state. Changing video or restarting/recreating the editor clears it. Save SRT before leaving.
- Cancellation during native initialization can take time. No background service; keep the app open.
- Audio sample rates below 16 kHz are rejected. Resampling and real-world audio formats require device testing.
- Two-video mode transcribes the main/gameplay source, matching the existing exported audio, not the secondary facecam audio.
- No claim of unchanged preview/export parity: subtitle burn-in is new and needs real-device verification.

## UI review evidence
Existing navy/light editor themes and dock layout are retained; the new panel uses native Compose buttons, checkbox, labeled text fields and the existing scroll container. Existing provisional design dials remain Energy 2 / Rhythm 2 / Motion 1. The subtitle icon identifies the text tool; no new decorative assets or redesign.
- Static PASS: empty, loading, cancellation, error and populated states have explicit code paths; controls are wired to model download, transcription, cancel, text edits, SRT picker, cue seek and export toggle.
- Static PASS: the compiler verifies the new panel and all integrations.
- Runtime review PENDING: tap-through, keyboard handling, light/dark contrast, small-screen fit, rotation and accessibility have not been observed on a device. No visual delivery gate PASS is claimed.

## Next steps
1. Install a build signed appropriately for the owner's phone.
2. Test an Indonesian speech clip of 10 to 20 seconds, then a trim starting at 10 seconds; compare SRT and MP4 timings.
3. Test model download cancellation/retry and airplane-mode transcription after download.
4. Check text correction, long/blank cues, each output format, single/two-video modes and subtitle-off export.
5. Test stale facecam results by rapidly switching videos and requesting detection again.
6. Run the detailed device checklist in docs/OFFLINE_SUBTITLES.md before calling this release production-ready.
